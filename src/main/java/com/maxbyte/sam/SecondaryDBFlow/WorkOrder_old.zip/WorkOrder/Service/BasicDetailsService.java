package com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Service;

import com.maxbyte.sam.SecondaryDBFlow.Response.ResponseModel;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.APIRequest.AddBasicDetailsRequest;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Entity.BasicDetails;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Repository.BasicDetailsRepository;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Specification.BasicDetailsSpecificationBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class BasicDetailsService {
    @Autowired
    private BasicDetailsRepository basicDetailsRepository;


    public ResponseModel<List<BasicDetails>> list(String workOrderNumber) {
        try {
            BasicDetailsSpecificationBuilder builder = new BasicDetailsSpecificationBuilder();
            if(workOrderNumber!=null)builder.with("workOrderNumber",":",workOrderNumber);

            List<BasicDetails> results = basicDetailsRepository.findAll(builder.build());
            return new ResponseModel<>(true, "Records found",results);

        }catch (Exception e){
            return new ResponseModel<>(false, "Records not found",null);
        }
    }
    public ResponseModel<BasicDetails> addOrUpdateBasicDetails(AddBasicDetailsRequest data) {
        try {
            if(data.getWorkOrderNumber()!=null) {
                List<BasicDetails> listData = basicDetailsRepository.findAll();

                BasicDetails basicDetails = new BasicDetails();

                var tempWONumber = "";

                if (listData.isEmpty()) {
                    tempWONumber ="WO"+1;
                    basicDetails.setWorkOrderNumber(tempWONumber);

                } else {
                    tempWONumber = "WO"+(listData.get(listData.size() - 1).getId() + 1);
                    basicDetails.setWorkOrderNumber(tempWONumber);
                }

                basicDetails.setAssetGroupId(data.getAssetGroupId());
                basicDetails.setAssetGroup(data.getAssetGroup());
                basicDetails.setStartDate(data.getStartDate());
                basicDetails.setAssetNumber(data.getAssetNumber());
                basicDetails.setAssetId(data.getAssetId());
                basicDetails.setAssetNumber(data.getAssetNumber());
                basicDetails.setWipAccountingClass(data.getWipAccountingClass());
                basicDetails.setDepartment(data.getDepartment());
                basicDetails.setDepartmentId(data.getDepartmentId());
                basicDetails.setDepartmentDescription(data.getDepartmentDescription());
                basicDetails.setOrganizationId(data.getOrganizationId());
                basicDetails.setOrganizationCode(data.getOrganizationCode());
                basicDetails.setStartDate(data.getStartDate());
                basicDetails.setCompletionDate(data.getCompletionDate());
                basicDetails.setDuration(data.getDuration());
                basicDetails.setCreatedOn(LocalDateTime.now());
                basicDetails.setRequestNumber(data.getRequestNumber());
                basicDetails.setPlanner(data.getPlanner());
                basicDetails.setWorkOrderType(data.getWorkOrderType());
                basicDetails.setShutdownType(data.getShutdownType());
                basicDetails.setFirm(data.getFirm());
                basicDetails.setStatus(data.getStatus());
                basicDetails.setPriority(data.getPriority());
                basicDetails.setBasicDescription(data.getDescription());


                basicDetailsRepository.save(basicDetails);

                return new ResponseModel<>(true, "Added Successfully ", basicDetails);
            }else {
                BasicDetails basicDetails= basicDetailsRepository.findByWorkOrderNumber(data.getWorkOrderNumber());
                if(basicDetails!=null) {

                    basicDetails.setAssetGroupId(data.getAssetGroupId());
                    basicDetails.setAssetGroup(data.getAssetGroup());
                    basicDetails.setStartDate(data.getStartDate());
                    basicDetails.setAssetNumber(data.getAssetNumber());
                    basicDetails.setAssetId(data.getAssetId());
                    basicDetails.setAssetNumber(data.getAssetNumber());
                    basicDetails.setWipAccountingClass(data.getWipAccountingClass());
                    basicDetails.setDepartment(data.getDepartment());
                    basicDetails.setDepartmentId(data.getDepartmentId());
                    basicDetails.setDepartmentDescription(data.getDepartmentDescription());
                    basicDetails.setOrganizationId(data.getOrganizationId());
                    basicDetails.setOrganizationCode(data.getOrganizationCode());
                    basicDetails.setStartDate(data.getStartDate());
                    basicDetails.setCompletionDate(data.getCompletionDate());
                    basicDetails.setDuration(data.getDuration());
                    basicDetails.setRequestNumber(data.getRequestNumber());
                    basicDetails.setPlanner(data.getPlanner());
                    basicDetails.setWorkOrderType(data.getWorkOrderType());
                    basicDetails.setShutdownType(data.getShutdownType());
                    basicDetails.setFirm(data.getFirm());
                    basicDetails.setStatus(data.getStatus());
                    basicDetails.setPriority(data.getPriority());
                    basicDetails.setBasicDescription(data.getDescription());

                    basicDetailsRepository.save(basicDetails);

                    return new ResponseModel<>(true, "Updated Successfully ", basicDetails);
                }else {
                    return new ResponseModel<>(false, "Work order number not found", null);
                }
            }
        } catch (Exception e) {
            return new ResponseModel(false,"Failed to Add",null);
        }
    }

/*
    public ResponseModel<BasicDetails> updateBasicDetails(Integer workOrderNumber,AddBasicDetailsRequest data) {
        try {

            BasicDetails basicDetails= basicDetailsRepository.findByWorkOrderNumber(workOrderNumber);
            if(basicDetails!=null) {

                basicDetails.setAssetGroupId(data.getAssetGroupId());
                basicDetails.setAssetGroup(data.getAssetGroup());
                basicDetails.setCreatedBy(data.getCreatedBy());
                basicDetails.setCreatedById(data.getCreatedById());
                basicDetails.setStartDate(data.getStartDate());
                basicDetails.setAssetNumber(data.getAssetNumber());
                basicDetails.setAssetId(data.getAssetId());
                basicDetails.setAssetNumber(data.getAssetNumber());
                basicDetails.setWipAccountingClass(data.getWipAccountingClass());
                basicDetails.setDepartment(data.getDepartment());
                basicDetails.setDepartmentId(data.getDepartmentId());
                basicDetails.setDepartmentDescription(data.getDepartmentDescription());
                basicDetails.setOrganizationId(data.getOrganizationId());
                basicDetails.setOrganizationCode(data.getOrganizationCode());
                basicDetails.setStartDate(data.getStartDate());
                basicDetails.setCompletionDate(data.getCompletionDate());
                basicDetails.setDuration(data.getDuration());

                basicDetailsRepository.save(basicDetails);

                return new ResponseModel<>(true, "Updated Successfully ", basicDetails);
            } else {
                    return new ResponseModel<>(false, "Record not found", null);
                }
        } catch (Exception e) {
            return new ResponseModel(false,"Failed to Add",null);
        }
    }
*/

}
