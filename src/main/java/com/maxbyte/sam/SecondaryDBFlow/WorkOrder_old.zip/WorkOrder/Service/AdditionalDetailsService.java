package com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Service;

import com.maxbyte.sam.SecondaryDBFlow.Response.ResponseModel;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.APIRequest.AddAdditionalDetailsRequest;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Entity.AdditionalDetails;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Repository.AdditionalDetailsRepository;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Specification.AdditionalDetailsSpecificationBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;


@Service
public class AdditionalDetailsService {
    @Autowired
    private AdditionalDetailsRepository additionalDetailsRepository;


    public ResponseModel<List<AdditionalDetails>> list(String workOrderNumber) {
        try {
            AdditionalDetailsSpecificationBuilder builder = new AdditionalDetailsSpecificationBuilder();
            if(workOrderNumber!=null)builder.with("workOrderNumber",":",workOrderNumber);

            List<AdditionalDetails> results = additionalDetailsRepository.findAll(builder.build());
            return new ResponseModel<>(true, "Records found",results);

        }catch (Exception e){
            return new ResponseModel<>(false, "Records not found",null);
        }
    }

    public ResponseModel<AdditionalDetails> addOrUpdateAdditionalDetails(AddAdditionalDetailsRequest data) {
        try {
            AdditionalDetails additionalDetails = additionalDetailsRepository.findByWorkOrderNumber(data.getWorkOrderNumber());

            if (additionalDetails != null) {
                additionalDetails.setWorkOrderNumber(data.getWorkOrderNumber());
                additionalDetails.setRebuildParent(data.getRebuildParent());
                additionalDetails.setActivityType(data.getActivityType());
                additionalDetails.setActivityCause(data.getActivityCause());
                additionalDetails.setActivitySource(data.getActivitySource());
                additionalDetails.setShutdownPlan(data.getShutdownPlan());
                additionalDetails.setShutdownPlanName(data.getShutdownPlanName());
                additionalDetails.setSamNumber(data.getSamNumber());
                additionalDetails.setSamStatus(data.getSamStatus());
                additionalDetails.setMaterialIssue(data.isMaterialIssue());
                additionalDetails.setPlanned(data.isPlanned());
                additionalDetails.setWarrantyActive(data.isWarrantyActive());
                additionalDetails.setWarrantyStatus(data.getWarrantyStatus());
                additionalDetails.setWarrantyExpirationDate(data.getWarrantyExpirationDate());
                additionalDetails.setTagOutRequired(data.isTagOutRequired());
                additionalDetails.setNotificationRequired(data.isNotificationRequired());
                additionalDetails.setSafetyPermitRequired(data.isSafetyPermitRequired());
                additionalDetails.setContext(data.getContext());
                additionalDetails.setInformDepartment(data.getInformDepartment());
                additionalDetails.setCreatedOn(LocalDateTime.now());

                additionalDetailsRepository.save(additionalDetails);

                return new ResponseModel<>(true, "Updated Successfully ", additionalDetails);
            } else /*if (data.getWorkOrderNumber() != 0)*/ {
                additionalDetails = new AdditionalDetails();
                additionalDetails.setWorkOrderNumber(data.getWorkOrderNumber());
                additionalDetails.setRebuildParent(data.getRebuildParent());
                additionalDetails.setActivityType(data.getActivityType());
                additionalDetails.setActivityCause(data.getActivityCause());
                additionalDetails.setActivitySource(data.getActivitySource());
                additionalDetails.setShutdownPlan(data.getShutdownPlan());
                additionalDetails.setShutdownPlanName(data.getShutdownPlanName());
                additionalDetails.setSamNumber(data.getSamNumber());
                additionalDetails.setSamStatus(data.getSamStatus());
                additionalDetails.setMaterialIssue(data.isMaterialIssue());
                additionalDetails.setPlanned(data.isPlanned());
                additionalDetails.setWarrantyActive(data.isWarrantyActive());
                additionalDetails.setWarrantyStatus(data.getWarrantyStatus());
                additionalDetails.setWarrantyExpirationDate(data.getWarrantyExpirationDate());
                additionalDetails.setTagOutRequired(data.isTagOutRequired());
                additionalDetails.setNotificationRequired(data.isNotificationRequired());
                additionalDetails.setSafetyPermitRequired(data.isSafetyPermitRequired());
                additionalDetails.setContext(data.getContext());
                additionalDetails.setInformDepartment(data.getInformDepartment());
                additionalDetails.setCreatedOn(LocalDateTime.now());

                additionalDetailsRepository.save(additionalDetails);

                return new ResponseModel<>(true, "Added Successfully ", additionalDetails);
            } /*else {
                return new ResponseModel<>(false, "Work order number not found", null);
            }*/
        } catch (Exception e) {
            return new ResponseModel<>(false, "Failed to Add/Update", null);
        }
    }

}
