package com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.*;

import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Getter
public class BasicDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    private String workOrderNumber;
    private Integer assetId;
    private String assetNumber;
    private Integer assetGroupId;
    private String assetGroup;
    private Integer departmentId;
    private String department;
    private String departmentDescription;
    private Integer organizationId;
    private String organizationCode;
    private String assetActivity;
    private String wipAccountingClass;
    private LocalDateTime startDate;
    private LocalDateTime completionDate;
    private String duration;
    private Integer requestNumber;
    private String planner;
    private String workOrderType;
    private String shutdownType;
    private String firm;
    private String status;
    private String priority;
    private String basicDescription;
    private LocalDateTime createdOn;
}
