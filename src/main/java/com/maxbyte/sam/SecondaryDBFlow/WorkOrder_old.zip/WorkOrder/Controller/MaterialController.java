package com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Controller;

import com.maxbyte.sam.SecondaryDBFlow.Response.ResponseModel;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.APIRequest.AddMaterialRequest;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Entity.Material;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Service.MaterialService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/workOrder/material")
public class MaterialController {
    @Autowired
    private MaterialService materialService;

    @GetMapping("/materialList")
    public ResponseModel<List<Material>> list(@RequestParam(required = false) String workOrderNumber){
        return materialService.list(workOrderNumber);
    }
    @PostMapping("/addOrUpdateMaterial")
    public ResponseModel<String> addMaterial(@RequestBody AddMaterialRequest addMaterialRequest){
        return materialService.addMaterial(addMaterialRequest);
    }
}
