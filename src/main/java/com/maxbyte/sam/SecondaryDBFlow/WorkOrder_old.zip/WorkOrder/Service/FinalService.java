package com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maxbyte.sam.SecondaryDBFlow.Response.ResponseModel;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.APIRequest.AddMasterWorkOrderRequest;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.APIRequest.WorkOrderResponse;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Entity.*;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Repository.*;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.util.List;


@Service
public class FinalService {
    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private BasicDetailsRepository basicDetailsRepository;
    @Autowired
    private AdditionalDetailsRepository additionalDetailsRepository;
    @Autowired
    private OperationRepository operationRepository;
    @Autowired
    private OperationChildRepository operationChildRepository;
    @Autowired
    private MaterialRepository materialRepository;
    @Autowired
    private MaterialChildRepository materialChildRepository;
    @Autowired
    private WorkClearanceRepository workClearanceRepository;
    @Autowired
    private WorkClearanceChildRepository workClearanceChildRepository;
    @Autowired
    private WorkPermitRepository workPermitRepository;
    @Autowired
    private WorkPermitChildRepository workPermitChildRepository;



    public ResponseEntity<ResponseModel<String>> addWorkOrder(@Valid @RequestBody AddMasterWorkOrderRequest data) {
        try {
            String url = "http://192.168.5.154:8000/api/masterWorkOrder/addMasterWorkOrder";

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
//            headers.set("Authorization",AUTH_TOKEN );
            headers.set("Authorization",data.getAuthToken());

            HttpEntity<AddMasterWorkOrderRequest> entity = new HttpEntity<>(data, headers);

            ResponseEntity<String> responseEntity = restTemplate.postForEntity(url, entity, String.class);

            if (responseEntity.getStatusCode() == HttpStatus.OK) {
                String response = responseEntity.getBody();

                if (!response.isEmpty()) {
                    ObjectMapper objectMapper = new ObjectMapper();
                    System.out.println("response"+response);
                    WorkOrderResponse masterWorkOrder = objectMapper.readValue(response, WorkOrderResponse.class);

                    System.out.println("masterWorkOrder"+masterWorkOrder.getData());
                    if (masterWorkOrder != null) {

                        BasicDetails basicDetails = basicDetailsRepository.findByWorkOrderNumber(data.getWorkOrderNumber());
                        System.out.println("basicDetails"+basicDetails);
                        AdditionalDetails additionalDetails=additionalDetailsRepository.findByWorkOrderNumber(data.getWorkOrderNumber());
                        List<Operation> operationList= operationRepository.findByWorkOrderNumber(data.getWorkOrderNumber());
                        List<Material> materialList=materialRepository.findByWorkOrderNumber(data.getWorkOrderNumber());
                        List<WorkClearance> workClearanceList= workClearanceRepository.findByWorkOrderNumber(data.getWorkOrderNumber());
                        List<WorkPermit> workPermitList=workPermitRepository.findByWorkOrderNumber(data.getWorkOrderNumber());
                        if (basicDetails != null || additionalDetails!=null || operationList!=null || materialList!=null || workPermitList!=null) {

                            if (basicDetails != null) {
                                basicDetails.setWorkOrderNumber(masterWorkOrder.getData());
                                basicDetailsRepository.save(basicDetails);
                            }

                            if (additionalDetails != null) {
                                additionalDetails.setWorkOrderNumber(masterWorkOrder.getData());
                                additionalDetailsRepository.save(additionalDetails);
                            }

                            if (operationList != null && !operationList.isEmpty()) {
                                Operation operation = operationList.getFirst();

                                operation.setWorkOrderNumber(masterWorkOrder.getData());
                                operationRepository.save(operation);

                                for (OperationChild operationChild : operation.getOperationList()) {
                                    operationChild.setWorkOrderNumber(masterWorkOrder.getData());
                                    operationChildRepository.save(operationChild);
                                }
                            }

                            if (materialList != null && !materialList.isEmpty()) {
                                Material material = materialList.getFirst();

                                material.setWorkOrderNumber(masterWorkOrder.getData());
                                materialRepository.save(material);

                                for (MaterialChild materialChild : material.getMaterialList()) {
                                    materialChild.setWorkOrderNumber(masterWorkOrder.getData());
                                    materialChildRepository.save(materialChild);
                                }
                            }

                            if (workClearanceList != null && !workClearanceList.isEmpty()) {
                                WorkClearance workClearance = workClearanceList.getFirst();

                                workClearance.setWorkOrderNumber(masterWorkOrder.getData());
                                workClearanceRepository.save(workClearance);

                                for (WorkClearanceChild workClearanceChild : workClearance.getWorkClearanceList()) {
                                    workClearanceChild.setWorkOrderNumber(masterWorkOrder.getData());
                                    workClearanceChildRepository.save(workClearanceChild);
                                }
                            }

                            if (workPermitList != null && !workPermitList.isEmpty()) {
                                WorkPermit workPermit = workPermitList.getFirst();

                                workPermit.setWorkOrderNumber(masterWorkOrder.getData());
                                workPermitRepository.save(workPermit);

                                for (WorkPermitChild workPermitChild : workPermit.getWorkPermitList()) {
                                    workPermitChild.setWorkOrderNumber(masterWorkOrder.getData());
                                    workPermitChildRepository.save(workPermitChild);
                                }
                            }


                            return ResponseEntity.ok(new ResponseModel<>(true, "Added Successfully", masterWorkOrder.getData()));
                        } else {
                            return ResponseEntity.ok(new ResponseModel<>(false, "workOrderNumber not found", null));
                        }
                    }else {
                        // Handle case where response data is null
                        return ResponseEntity.ok(new ResponseModel<>(false, "Failed to add work Order to Oracle", null));
                    }
                } else {
                    // Return unauthorized response if the response is empty
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                            .body(new ResponseModel<>(false, "Login failed: Empty response from the server.", null));
                }
            } else {
                // Handle non-OK status code from Oracle service
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(new ResponseModel<>(false, "Failed to connect to the server.", null));
            }
        } catch (HttpStatusCodeException ex) {
            // Handle HTTP status code exceptions
            return ResponseEntity.status(ex.getStatusCode())
                    .body(new ResponseModel<>(false, "HTTP Error: " + ex.getStatusCode().toString(), null));
        } catch (JsonProcessingException e) {
            // Handle JSON processing exceptions
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseModel<>(false, "Error processing the response.", null));
        } catch (Exception e) {
            // Handle other unexpected exceptions
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseModel<>(false, "Unexpected error occurred.", null));
        }
    }

}
