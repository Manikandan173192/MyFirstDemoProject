package com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Specification;

import com.maxbyte.sam.SecondaryDBFlow.Helper.GenericSpecificationBuilder;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Entity.BasicDetails;

public class BasicDetailsSpecificationBuilder extends GenericSpecificationBuilder<BasicDetails> {

}
