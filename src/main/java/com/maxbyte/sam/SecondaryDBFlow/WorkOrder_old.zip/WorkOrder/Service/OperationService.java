package com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Service;

import com.maxbyte.sam.SecondaryDBFlow.Response.ResponseModel;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.APIRequest.AddOperationRequest;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Entity.Operation;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Entity.OperationChild;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Repository.OperationRepository;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Repository.OperationChildRepository;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Specification.OperationSpecificationBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class OperationService {
    @Autowired
    private OperationChildRepository operationChildRepository;
    @Autowired
    private OperationRepository operationRepository;

    public ResponseModel<List<Operation>> list(String workOrderNumber) {
        try {

            OperationSpecificationBuilder builder=new OperationSpecificationBuilder();
            if(workOrderNumber!=null)builder.with("workOrderNumber",":",workOrderNumber);

            List<Operation> results = operationRepository.findAll(builder.build());
            return new ResponseModel<>(true, "Records found",results);

        }catch (Exception e){
            return new ResponseModel<>(false, "Records not found",null);
        }
    }

    public ResponseModel<String> addOperation(AddOperationRequest addOperationRequest) {
        try {
            List<Operation> operationOneList = operationRepository.findByWorkOrderNumber(addOperationRequest.getWorkOrderNumber());
            var actionApi = 0;
            if(!operationOneList.isEmpty()) {
                operationOneList.getFirst().setWorkOrderNumber(addOperationRequest.getWorkOrderNumber());
                operationRepository.save(operationOneList.getFirst());

                var addedTableList = operationChildRepository.findByWorkOrderNumber(operationOneList.getFirst().getWorkOrderNumber());
                if (!addedTableList.isEmpty()) {
                    for (OperationChild items : addedTableList) {
                        if (items.getWorkOrderNumber().equals(operationOneList.getFirst().getWorkOrderNumber())) {
                            operationChildRepository.deleteById(items.getId());
                        }
                    }
                }
                for (OperationChild items : addOperationRequest.getOperationList()) {
                    var operationTwo = new OperationChild();

                    operationTwo.setWorkOrderNumber(items.getWorkOrderNumber());
                    operationTwo.setOperation(items.getOperation());
                    operationTwo.setDescription(items.getDescription());
                    operationTwo.setResourceSequence(items.getResourceSequence());
                    operationTwo.setResource(items.getResource());
                    operationTwo.setRequired(items.getRequired());
                    operationTwo.setAssignedUnits(items.getAssignedUnits());
                    operationTwo.setEquipment(items.getEquipment());
                    operationTwo.setStartTime(items.getStartTime());
                    operationTwo.setEndTime(items.getEndTime());
                    operationTwo.setDuration(items.getDuration());
                    operationTwo.setCreatedOn(LocalDateTime.now());

                    operationChildRepository.save(operationTwo);

                }
                actionApi = 2;
            }else {
                var operationOne = new Operation();
                    operationOne.setWorkOrderNumber(addOperationRequest.getWorkOrderNumber());
                    operationOne.setOperationList(addOperationRequest.getOperationList());
                operationRepository.save(operationOne);

//                List<OperationOne> operationOneList1 = operationOneRepository.findAll();

                for (OperationChild items : addOperationRequest.getOperationList()) {
                    var operationTwo = new OperationChild();

                    operationTwo.setWorkOrderNumber(addOperationRequest.getWorkOrderNumber());
                    operationTwo.setOperation(items.getOperation());
                    operationTwo.setDescription(items.getDescription());
                    operationTwo.setResourceSequence(items.getResourceSequence());
                    operationTwo.setResource(items.getResource());
                    operationTwo.setRequired(items.getRequired());
                    operationTwo.setAssignedUnits(items.getAssignedUnits());
                    operationTwo.setEquipment(items.getEquipment());
                    operationTwo.setStartTime(items.getStartTime());
                    operationTwo.setEndTime(items.getEndTime());
                    operationTwo.setDuration(items.getDuration());
                    operationTwo.setCreatedOn(LocalDateTime.now());

                    operationChildRepository.save(operationTwo);

                }
                actionApi = 1;
            }

            return new ResponseModel<>(true, actionApi == 1?"Operation Added Successfully":"Operation updated successfully", null);

        } catch (Exception e) {
            return new ResponseModel<>(false, "Failed to add", null);
        }
    }


}
