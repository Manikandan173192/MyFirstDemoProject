package com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Service;

import com.maxbyte.sam.SecondaryDBFlow.Response.ResponseModel;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.APIRequest.AddMaterialRequest;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Entity.Material;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Entity.MaterialChild;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Repository.MaterialRepository;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Repository.MaterialChildRepository;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Specification.MaterialSpecificationBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class MaterialService {

    @Autowired
    private MaterialRepository materialRepository;
    @Autowired
    private MaterialChildRepository materialChildRepository;

    public ResponseModel<List<Material>> list(String workOrderNumber) {
        try {

            MaterialSpecificationBuilder builder=new MaterialSpecificationBuilder();
            if(workOrderNumber!=null)builder.with("workOrderNumber",":",workOrderNumber);

            List<Material> results = materialRepository.findAll(builder.build());
            return new ResponseModel<>(true, "Records found",results);

        }catch (Exception e){
            return new ResponseModel<>(false, "Records not found",null);
        }
    }

    public ResponseModel<String> addMaterial(AddMaterialRequest addMaterialRequest) {
        try {
            List<Material> materialOneList = materialRepository.findByWorkOrderNumber(addMaterialRequest.getWorkOrderNumber());
            var actionApi = 0;
            if(!materialOneList.isEmpty()) {
                materialOneList.getFirst().setWorkOrderNumber(addMaterialRequest.getWorkOrderNumber());
                materialRepository.save(materialOneList.getFirst());

                var addedTableList = materialChildRepository.findByWorkOrderNumber(materialOneList.getFirst().getWorkOrderNumber());
                if (!addedTableList.isEmpty()) {
                    for (MaterialChild items : addedTableList) {
                        if (items.getWorkOrderNumber().equals(materialOneList.getFirst().getWorkOrderNumber())) {
                            materialChildRepository.deleteById(items.getId());
                        }
                    }
                }
                for (MaterialChild items : addMaterialRequest.getMaterialList()) {
                    var materialTwo = new MaterialChild();

                    materialTwo.setWorkOrderNumber(items.getWorkOrderNumber());
                    materialTwo.setOperationId(items.getOperationId());
                    materialTwo.setOperation(items.getOperation());
                    materialTwo.setItemType(items.getItemType());
                    materialTwo.setItem(items.getItem());
                    materialTwo.setItemDescription(items.getItemDescription());
                    materialTwo.setQuantity(items.getQuantity());
                    materialTwo.setUOM(items.getUOM());
                    materialTwo.setDateRequired(items.getDateRequired());
                    materialTwo.setCreatedOn(LocalDateTime.now());

                    materialChildRepository.save(materialTwo);

                }
                actionApi = 2;
            }else {
                var materialOne = new Material();
                materialOne.setWorkOrderNumber(addMaterialRequest.getWorkOrderNumber());
                materialOne.setMaterialList(addMaterialRequest.getMaterialList());
                materialRepository.save(materialOne);


                for (MaterialChild items : addMaterialRequest.getMaterialList()) {
                    var materialTwo = new MaterialChild();

                    materialTwo.setWorkOrderNumber(addMaterialRequest.getWorkOrderNumber());
                    materialTwo.setOperationId(items.getOperationId());
                    materialTwo.setOperation(items.getOperation());
                    materialTwo.setItemType(items.getItemType());
                    materialTwo.setItem(items.getItem());
                    materialTwo.setItemDescription(items.getItemDescription());
                    materialTwo.setQuantity(items.getQuantity());
                    materialTwo.setUOM(items.getUOM());
                    materialTwo.setDateRequired(items.getDateRequired());
                    materialTwo.setCreatedOn(LocalDateTime.now());

                    materialChildRepository.save(materialTwo);

                }
                actionApi = 1;
            }

            return new ResponseModel<>(true, actionApi == 1?"Material Added Successfully":"Material updated successfully", null);

        } catch (Exception e) {
            return new ResponseModel<>(false, "Failed to add", null);
        }
    }


}
