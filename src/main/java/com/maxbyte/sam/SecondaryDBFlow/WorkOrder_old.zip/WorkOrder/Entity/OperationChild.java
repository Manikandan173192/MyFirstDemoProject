package com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class OperationChild {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    private String workOrderNumber;
    private String operation;
    private String description;
    private String resourceSequence;
    private String resource;
    private String required;
    private String assignedUnits;
    private String equipment;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String duration;
    private LocalDateTime createdOn;
}
