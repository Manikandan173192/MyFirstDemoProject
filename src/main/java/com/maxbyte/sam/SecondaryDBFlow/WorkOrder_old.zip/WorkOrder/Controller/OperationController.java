package com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Controller;

import com.maxbyte.sam.SecondaryDBFlow.Response.ResponseModel;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.APIRequest.AddOperationRequest;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Entity.Operation;
import com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Service.OperationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/workOrder/operation")
public class OperationController {
    @Autowired
    private OperationService operationService;

    @GetMapping("/operationList")
    public ResponseModel<List<Operation>> list(@RequestParam(required = false) String workOrderNumber){
        return operationService.list(workOrderNumber);
    }
    @PostMapping("/addOrUpdateOperation")
    public ResponseModel<String> addOperation(@RequestBody AddOperationRequest data){
        return operationService.addOperation(data);
    }
}
