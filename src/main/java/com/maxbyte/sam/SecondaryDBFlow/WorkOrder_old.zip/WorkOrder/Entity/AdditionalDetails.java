package com.maxbyte.sam.SecondaryDBFlow.WorkOrder.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class AdditionalDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    private String workOrderNumber;
    private String rebuildParent;
    private String activityType;
    private String activityCause;
    private String activitySource;
    private String shutdownPlan;
    private String shutdownPlanName;
    private String samNumber;
    private String samStatus;
    private boolean materialIssue;
    private boolean planned;
    private boolean warrantyActive;
    private String warrantyStatus;
    private LocalDateTime warrantyExpirationDate;
    private boolean tagOutRequired;
    private boolean notificationRequired;
    private boolean safetyPermitRequired;
    private String context;
    private String informDepartment;
    private LocalDateTime createdOn;
}
