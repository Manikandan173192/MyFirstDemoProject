package com.maxbyte.sam.SecondaryDBFlow.WorkOrder.APIRequest;

import lombok.*;

import java.time.LocalDateTime;
import java.util.Date;

@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class AddBasicDetailsRequest {
    private Integer assetId;
    private String assetNumber;
    private Integer assetGroupId;
    private String assetGroup;
    private String workOrderNumber;
    private Integer departmentId;
    private String department;
    private String departmentDescription;
    private Integer organizationId;
    private String organizationCode;
    private String assetActivity;
    private String wipAccountingClass;
    private LocalDateTime startDate;
    private LocalDateTime completionDate;
    private String duration;
    private Integer createdById;
    private String createdBy;
    private Integer requestNumber;
    private String planner;
    private String workOrderType;
    private String shutdownType;
    private String firm;
    private String status;
    private String priority;
    private String description;
}
