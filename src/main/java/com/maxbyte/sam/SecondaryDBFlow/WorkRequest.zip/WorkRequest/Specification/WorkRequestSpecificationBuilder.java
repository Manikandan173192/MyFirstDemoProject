package com.maxbyte.sam.SecondaryDBFlow.WorkRequest.Specification;

import com.maxbyte.sam.SecondaryDBFlow.Helper.GenericSpecificationBuilder;
import com.maxbyte.sam.SecondaryDBFlow.WorkRequest.Entity.WorkRequest;

public class WorkRequestSpecificationBuilder extends GenericSpecificationBuilder<WorkRequest> {
}
