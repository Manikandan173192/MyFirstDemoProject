package com.maxbyte.sam.SecondaryDBFlow.WorkRequest.APIRequest;

import lombok.*;

@Data
public class EAMResponse {
    private String p_RETURN_STATUS;
}
