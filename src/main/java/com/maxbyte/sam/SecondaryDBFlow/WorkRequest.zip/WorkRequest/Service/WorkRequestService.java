package com.maxbyte.sam.SecondaryDBFlow.WorkRequest.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.maxbyte.sam.OracleDBFlow.Entity.MasterWorkRequest;
import com.maxbyte.sam.OracleDBFlow.Repository.MasterWorkRequestRepository;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.Asset;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.EmployeeDetails;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Repository.AssetRepository;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Repository.EmployeeDetailsRepository;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.service.CrudService;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.service.EmployeeDetailsService;
import com.maxbyte.sam.SecondaryDBFlow.RCA.Entity.RCA;
import com.maxbyte.sam.SecondaryDBFlow.Response.ResponseModel;
import com.maxbyte.sam.SecondaryDBFlow.WorkRequest.APIRequest.AddWorkRequest1;
import com.maxbyte.sam.SecondaryDBFlow.WorkRequest.APIRequest.FNDUserRequest;
import com.maxbyte.sam.SecondaryDBFlow.WorkRequest.APIRequest.UpdateWorkRequest;
import com.maxbyte.sam.SecondaryDBFlow.WorkRequest.Entity.WorkRequest;
import com.maxbyte.sam.SecondaryDBFlow.WorkRequest.Repository.WorkRequestRepository;
import com.maxbyte.sam.SecondaryDBFlow.WorkRequest.Specification.WorkRequestSpecificationBuilder;
import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.CrudRepository;
import org.springframework.http.*;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;


@Service
public class WorkRequestService extends CrudService<WorkRequest,Integer> {

    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private WorkRequestRepository workRequestRepository;
    @Autowired
    private MasterWorkRequestRepository masterWorkRequestRepository;
    @Value("${pagination.default-page}")
    private int defaultPage;
    @Value("${pagination.default-size}")
    private int defaultSize;
    @Autowired
    EmployeeDetailsRepository employeeDetailsRepository;
    @Autowired
    AssetRepository assetRepository;
    @Override
    public CrudRepository repository() {
        return this.workRequestRepository;
    }
    /*@Autowired
    private MasterWorkRequestRepository masterWorkRequestRepository;

    @Autowired
    private MasterWorkRequestService masterWorkRequestService;*/

    @Autowired
    private RestTemplate restTemplate;


    @Override
    public void validateAdd(WorkRequest data) {
        try{
        }
        catch(Error e){
            throw new Error(e);
        }

    }

    @Override
    public void validateEdit(WorkRequest data) {
        try{
        }
        catch(Error e){
            throw new Error(e);
        }
    }

    @Override
    public void validateDelete(Integer id) {
        try{

        }
        catch(Error e){
            throw new Error(e);
        }
    }


    public ResponseModel<List<WorkRequest>> list(String WRNumber,  String assetNumber, String department, String organizationId, String workRequestStatus, String requestPage) {
try {
    WorkRequestSpecificationBuilder builder = new WorkRequestSpecificationBuilder();
    if (WRNumber != null) builder.with("WORK_REQUEST_NUMBER", ":", WRNumber);
    if (assetNumber != null) builder.with("assetNumber", ":", assetNumber);
    if (department != null) builder.with("department", ":", department);
    if (organizationId != null) builder.with("ORGANIZATION_ID", ":", organizationId);

    var pageRequestCount = 0;

    if(requestPage.matches(".*\\d.*")){
        pageRequestCount = Integer.parseInt(requestPage);
    }else{
        pageRequestCount = 0;
    }

    var list = workRequestRepository.findAll();
    System.out.println(list.getFirst());

    // Create a PageRequest for pagination
    PageRequest pageRequest = PageRequest.of(pageRequestCount, defaultSize, Sort.by("creationDate").descending());
    Page<WorkRequest> results =workRequestRepository.findByWrNumberAndAssetNumberAndDepartmentAndOrganizationIdAndWorkRequestStatus(WRNumber,assetNumber,department,organizationId,workRequestStatus,pageRequest);
    List<WorkRequest> wrlist = workRequestRepository.findAll();
    var totalCount = String.valueOf(wrlist.size());
    var filteredCount = String.valueOf(results.getContent().size());

    //var filteredCount = String.valueOf(results.getContent().size());
    return new ResponseModel<>(true, totalCount + " Records found & " + filteredCount + " Filtered", results.getContent());

}catch (Exception e){
            return new ResponseModel<>(false, "Records not found",null);
        }
    }


//    public ResponseModel<List<WorkRequest>> list(String WRNumber, String assetNumber,String department,String organizationId,String workRequestStatus) {
//        ResponseModel<List<WorkRequest>> response;
//
//        try {
//            Pageable pageable = PageRequest.of(0, 100);
//            Page<WorkRequest> workRequests = workRequestRepository.findByWrNumberAndAssetNumberAndDepartmentAndOrganizationIdAndWorkRequestStatus(WRNumber,assetNumber,department,organizationId,workRequestStatus, pageable);
//
//            List<WorkRequest> workRequestList = workRequests.getContent();
//            if (!workRequestList.isEmpty()) {
//                response = new ResponseModel<>(true, "Employees found.", workRequestList.reversed());
//            } else {
//                response = new ResponseModel<>(true, "No employees found for the given name.", null);
//            }
//        } catch (Exception e) {
//            response = new ResponseModel<>(false, "An error occurred while retrieving the records.", null);
//        }
//
//        return response;
//    }




//    public ResponseModel<List<WorkRequest>> findWorkRequestByDateTime(LocalDateTime from, LocalDateTime to) {
//        try {
//            var dateTimeFilterList = workRequestRepository.findByCreationDateBetween(from, to);
//            return new ResponseModel<>(true, "Records found",dateTimeFilterList);
//
//        }catch (Exception e){
//            return new ResponseModel<>(false, "Records not found",null);
//        }
//    }
    public ResponseModel<List<WorkRequest>> findWorkRequestByDateTime(String orgCode, LocalDateTime from, LocalDateTime to, String requestPage) {
        try {
            //var dateTimeFilterList = rcaRepository.findByOrganizationCodeAndCreatedOnBetween(orgCode, from, to);
            var pageRequestCount = 0;

            if (requestPage.matches(".*\\d.*")) {
                pageRequestCount = Integer.parseInt(requestPage);
            } else {
                pageRequestCount = 0;
            }

            // Create a PageRequest for pagination
            PageRequest pageRequest = PageRequest.of(pageRequestCount, defaultSize, Sort.by("creationDate").descending());
            Page<WorkRequest> results = workRequestRepository.findByOrganizationIdAndCreationDateBetween(orgCode, from, to, pageRequest);
            List<WorkRequest> wrList = workRequestRepository.findAll();
            var totalCount = String.valueOf(wrList.size());
            var filteredCount = String.valueOf(results.getContent().size());
            if (results.isEmpty()) {
                return new ResponseModel<>(false, "No records found", null);
            } else {
                return new ResponseModel<>(true, totalCount + " Records found & " + filteredCount + " Filtered", results.getContent());
            }
        }catch(Exception e){
            return new ResponseModel<>(false, "Records not found", null);
        }
    }


   /* public ResponseModel<WorkRequest> updateWRNumber(String WRNumber){
        try{
            var workRequestNumber = workRequestRepository.findByWRNumber(WRNumber);
            if (workRequestNumber!=null){
                WorkRequest newWorkRequest = new WorkRequest();
                newWorkRequest.setWRNumber(requestNumber);

                newWorkRequest.setP_ASSET_GROUP_ID(data.getP_ASSET_GROUP_ID());
                newWorkRequest.setP_ASSET_NUMBER(data.getP_ASSET_NUMBER());
                newWorkRequest.setP_CREATED_FOR(data.getP_CREATED_FOR());
                newWorkRequest.setP_ORGANIZATION_ID(data.getP_ORGANIZATION_ID());
                newWorkRequest.setP_WORK_REQUEST_PRIORITY_ID(data.getP_WORK_REQUEST_PRIORITY_ID());
                newWorkRequest.setP_OWNING_DEPARTMENT_ID(data.getP_OWNING_DEPARTMENT_ID());
                newWorkRequest.setP_EXPECTED_START_DATE(data.getP_EXPECTED_START_DATE());
                newWorkRequest.setP_EXPECTED_RESOLUTION_DATE(data.getP_EXPECTED_RESOLUTION_DATE());
                newWorkRequest.setP_DESCRIPTION(data.getP_DESCRIPTION());
                newWorkRequest.setP_WORK_REQUEST_TYPE_ID(data.getP_WORK_REQUEST_TYPE_ID());
                newWorkRequest.setP_USER_ID(data.getP_USER_ID());
                newWorkRequest.setP_PHONE_NUMBER(data.getP_PHONE_NUMBER());
                newWorkRequest.setP_E_MAIL(data.getP_E_MAIL());
                newWorkRequest.setP_WORK_CREATEDBY(data.getP_WORK_CREATEDBY());
                newWorkRequest.setP_WORK_ATTACHMENT(data.getP_WORK_ATTACHMENT());

                newWorkRequest.setCreatedOn(LocalDateTime.now());
                workRequestRepository.save(newWorkRequest);

            }
        }catch (){

        }
    }
*/



/*
    public ResponseModel<WorkRequest> addWorkRequest(@Valid @RequestBody AddWorkRequest data) {
        try {
            ResponseModel<MasterWorkRequest> oracleResponse = masterWorkRequestService.addOracleWorkRequest(data);

            if (oracleResponse.isSuccess()) {
                // MasterWorkRequest oracleData = oracleResponse.getData();
                MasterWorkRequest masterWorkRequest = masterWorkRequestRepository.findTopByOrderByIdDesc();

                if (masterWorkRequest != null) {

                    WorkRequest workRequest = new WorkRequest();
                    workRequest.setWRNumber(masterWorkRequest.getWRNumber());
                    workRequest.setWRStatus(masterWorkRequest.getWRStatus());
                    workRequest.setRequested(masterWorkRequest.getRequested());
                    workRequest.setAdditionalDescription(masterWorkRequest.getAdditionalDescription());
                    workRequest.setCreatedBy(masterWorkRequest.getCreatedBy());
                    workRequest.setCreatedById(masterWorkRequest.getCreatedById());
                    workRequest.setPhoneNumber(masterWorkRequest.getPhoneNumber());
                    workRequest.setPriority(masterWorkRequest.getPriority());
                    workRequest.setEmail(masterWorkRequest.getEmail());
                    workRequest.setStartDate(masterWorkRequest.getStartDate());
                    workRequest.setEndDate(masterWorkRequest.getEndDate());
                    workRequest.setWorkRequestType(masterWorkRequest.getWorkRequestType());
                    workRequest.setAssetNumber(masterWorkRequest.getAssetNumber());
                    workRequest.setAssetId(masterWorkRequest.getAssetId());
                    workRequest.setAssetDescription(masterWorkRequest.getAssetDescription());
                    workRequest.setDepartment(masterWorkRequest.getDepartment());
                    workRequest.setDepartmentId(masterWorkRequest.getDepartmentId());
                    workRequest.setOrganizationId(masterWorkRequest.getOrganizationId());
                    workRequest.setOrganizationCode(masterWorkRequest.getOrganizationCode());
                    workRequest.setActive(masterWorkRequest.isActive());
                    workRequest.setCreatedOn(new Date());


                    workRequestRepository.save(workRequest);

                    return new ResponseModel<>(true, "Added Successfully", workRequest);
                } else {
                    return new ResponseModel<>(false, "Failed to Add to Oracle", null);
                }
            } else {
                return new ResponseModel<>(false, "Failed to retrieve data from Oracle", null);
            }
        } catch (Exception e) {
            // Log the exception
            e.printStackTrace();
            return new ResponseModel<>(false, "Failed to Add", null);
        }
    }
*/


   /* public ResponseModel<WorkRequest> addWorkRequest(@Valid @RequestBody AddWorkRequest data) {
        try {
            String url = "http://localhost:8000/api/oracleWorkFlow/addWorkRequests";

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<AddWorkRequest> entity = new HttpEntity<>(data, headers);

            ResponseEntity<String> responseEntity = restTemplate.postForEntity(url, entity, String.class);

            HttpStatusCode statusCode = responseEntity.getStatusCode();
            if (statusCode == HttpStatus.OK) {
                String response = responseEntity.getBody();
                System.out.println("Response from the server: " + response);

                if (!response.isEmpty()) {
                    ObjectMapper objectMapper = new ObjectMapper();

                    MasterWorkRequest masterWorkRequest = objectMapper.readValue(response, MasterWorkRequest.class);

                    //MasterWorkRequest masterWorkRequest = masterWorkRequestRepository.findTopByOrderByIdDesc();

                    if (masterWorkRequest != null) {
                        WorkRequest newWorkRequest = new WorkRequest();
                        newWorkRequest.setWRNumber(masterWorkRequest.getWRNumber());
                        newWorkRequest.setWRStatus(masterWorkRequest.getWRStatus());
                        newWorkRequest.setRequested(masterWorkRequest.getRequested());
                        newWorkRequest.setAdditionalDescription(masterWorkRequest.getAdditionalDescription());
                        newWorkRequest.setCreatedBy(masterWorkRequest.getCreatedBy());
                        newWorkRequest.setCreatedById(masterWorkRequest.getCreatedById());
                        newWorkRequest.setPhoneNumber(masterWorkRequest.getPhoneNumber());
                        newWorkRequest.setPriority(masterWorkRequest.getPriority());
                        newWorkRequest.setEmail(masterWorkRequest.getEmail());
                        newWorkRequest.setStartDate(masterWorkRequest.getStartDate());
                        newWorkRequest.setEndDate(masterWorkRequest.getEndDate());
                        newWorkRequest.setWorkRequestType(masterWorkRequest.getWorkRequestType());
                        newWorkRequest.setAssetNumber(masterWorkRequest.getAssetNumber());
                        newWorkRequest.setAssetId(masterWorkRequest.getAssetId());
                        newWorkRequest.setAssetDescription(masterWorkRequest.getAssetDescription());
                        newWorkRequest.setDepartment(masterWorkRequest.getDepartment());
                        newWorkRequest.setDepartmentId(masterWorkRequest.getDepartmentId());
                        newWorkRequest.setOrganizationId(masterWorkRequest.getOrganizationId());
                        newWorkRequest.setOrganizationCode(masterWorkRequest.getOrganizationCode());
                        newWorkRequest.setActive(masterWorkRequest.isActive());
                        newWorkRequest.setCreatedOn(new Date());

                        workRequestRepository.save(newWorkRequest);

                        return new ResponseModel<>(true, "Added Successfully", newWorkRequest);
                    } else {
                        return new ResponseModel<>(false, "Failed to Add to Oracle", null);
                    }
                } else {
                    return new ResponseModel<>(false, "Failed to retrieve data from Oracle", null);
                }
            }
        } catch (Exception e) {
            // Log the exception
            e.printStackTrace();
        }
        return new ResponseModel<>(false, "Failed to Add", null);
    }*/


   /* public ResponseModel<WorkRequest> updateWorkRequest(Integer WRNumber, AddWorkRequest data) {
        try {
            ResponseModel<MasterWorkRequest> updateResponse = masterWorkRequestService.updateMasterWorkRequest(WRNumber, data);

            if (updateResponse.isSuccess()) {
                MasterWorkRequest masterWorkRequest = masterWorkRequestRepository.findTopByOrderByIdDesc();

                WorkRequest workRequest = workRequestRepository.findByWRNumber(WRNumber);
                if (workRequest != null) {
                    workRequest.setRequested(masterWorkRequest.getRequested());
                    workRequest.setAdditionalDescription(masterWorkRequest.getAdditionalDescription());
                    workRequest.setCreatedBy(masterWorkRequest.getCreatedBy());
                    workRequest.setCreatedById(masterWorkRequest.getCreatedById());
                    workRequest.setPhoneNumber(masterWorkRequest.getPhoneNumber());
                    workRequest.setPriority(masterWorkRequest.getPriority());
                    workRequest.setEmail(masterWorkRequest.getEmail());
                    workRequest.setStartDate(masterWorkRequest.getStartDate());
                    workRequest.setEndDate(masterWorkRequest.getEndDate());
                    workRequest.setWorkRequestType(masterWorkRequest.getWorkRequestType());
                    workRequest.setAssetNumber(masterWorkRequest.getAssetNumber());
                    workRequest.setAssetId(masterWorkRequest.getAssetId());
                    workRequest.setAssetDescription(masterWorkRequest.getAssetDescription());
                    workRequest.setDepartment(masterWorkRequest.getDepartment());
                    workRequest.setDepartmentId(masterWorkRequest.getDepartmentId());
                    workRequest.setOrganizationId(masterWorkRequest.getOrganizationId());
                    workRequest.setOrganizationCode(masterWorkRequest.getOrganizationCode());
                    workRequest.setActive(masterWorkRequest.isActive());

                    workRequestRepository.save(workRequest);

                    return new ResponseModel<>(true, "WorkRequest Updated Successfully", null);
                } else {
                    return new ResponseModel<>(false, "Record not found", null);
                }
            } else {
                return new ResponseModel<>(false, "Failed to retrieve updated data from the other service", null);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseModel<>(false, "Failed to update", null);
        }
    }*/


   /* public ResponseEntity<ResponseModel<WorkRequest>> addWorkRequest(@Valid @RequestBody AddWorkRequest1 data) {
        try {
//            String url = "http://192.168.5.175:8000/api/oracleWorkFlow/addMasterWorkRequests";
            String url = "http://10.36.113.75:9054/soa-infra/resources/PM/XXHIL_EAM_MAXBYTE_WR_CREATE_UPD/WORK_REQUEST_CREATE_SERVICE/WORK_REQUEST_CREATE_RP";


            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
//            headers.set("Authorization",AUTH_TOKEN );
//            headers.set("Authorization",data.getAuthToken());

            // Create Basic Authentication header
//            String authHeader = "Basic " + Base64.getEncoder().encodeToString((data.getUserName() + ":" + data.getPassword()).getBytes());
            // Set the Basic Authentication header
//            headers.set("Authorization", authHeader);

            // Create an HttpEntity with the request data and headers
            HttpEntity<AddWorkRequest1> entity = new HttpEntity<>(data, headers);
            System.out.println("entity:"+entity);

            // Send the POST request to the remote API service
            ResponseEntity<String> responseEntity = restTemplate.postForEntity(url, entity, String.class);
            System.out.println("responseEntity"+responseEntity);

            // Check if the response from the remote service is successful
            if (responseEntity.getStatusCode() == HttpStatus.OK) {
                String response = responseEntity.getBody();

                if (!response.isEmpty()) {
                    ObjectMapper objectMapper = new ObjectMapper();
                    objectMapper.registerModule(new JavaTimeModule());

                    // Deserialize the JSON response to MasterWorkRequest object
//                    WorkRequestResponse masterWorkRequest = objectMapper.readValue(response, WorkRequestResponse.class);
                    WorkRequestRequest masterWorkRequest = objectMapper.readValue(response, WorkRequestRequest.class);

                    // Check if the request was successful
                    if (masterWorkRequest != null) {
                        // Create a new WorkRequest object and populate it with data from the response
                        WorkRequest newWorkRequest = new WorkRequest();
//                        newWorkRequest.setWRNumber(masterWorkRequest.getData().getWRNumber());
                        newWorkRequest.setWRNumber(masterWorkRequest.getP_WORK_REQUEST_NUMBER().getNil());
                        *//*newWorkRequest.setAssetGroupId(masterWorkRequest.getData().getPAssetGroupId());
                        newWorkRequest.setAssetNumber(masterWorkRequest.getData().getPAssetNumber());
                        newWorkRequest.setOrganizationId(masterWorkRequest.getData().getPOrganizationId());
                        newWorkRequest.setWorkRequestPriorityId(masterWorkRequest.getData().getPWorkRequestPriorityId());
                        newWorkRequest.setOwningDepartmentId(masterWorkRequest.getData().getPOwningDepartmentId());
                        newWorkRequest.setExpectedStartDate(masterWorkRequest.getData().getPExpectedStartDate());
                        newWorkRequest.setExpectedResolutionDate(masterWorkRequest.getData().getPExpectedResolutionDate());
                        newWorkRequest.setDescription(masterWorkRequest.getData().getPDescription());
                        newWorkRequest.setWorkRequestTypeId(masterWorkRequest.getData().getPWorkRequestTypeId());
                        newWorkRequest.setCreatedFor(masterWorkRequest.getData().getPCreatedFor());
                        newWorkRequest.setUserId(masterWorkRequest.getData().getPUserId());
                        newWorkRequest.setPhoneNumber(masterWorkRequest.getData().getPPhoneNumber());
                        newWorkRequest.setEmail(masterWorkRequest.getData().getPEmail());*//*

                        newWorkRequest.setAssetGroupId(data.getASSET_GROUP_ID());
                        newWorkRequest.setAssetNumber(data.getASSET_NUMBER());
                        newWorkRequest.setCreatedFor(data.getCREATED_FOR());
                        newWorkRequest.setOrganizationId(data.getORGANIZATION_ID());
                        newWorkRequest.setWorkRequestPriorityId(data.getWORK_REQUEST_PRIORITY_ID());
                        newWorkRequest.setOwningDepartmentId(data.getOWNING_DEPARTMENT_ID());
                        newWorkRequest.setExpectedStartDate(data.getEXPECTED_START_DATE());
                        newWorkRequest.setExpectedResolutionDate(data.getEXPECTED_RESOLUTION_DATE());
                        newWorkRequest.setDescription(data.getDESCRIPTION());
                        newWorkRequest.setWorkRequestTypeId(data.getWORK_REQUEST_TYPE_ID());
                        newWorkRequest.setUserId(data.getUSER_ID());
                        newWorkRequest.setPhoneNumber(data.getPHONE_NUMBER());
                        newWorkRequest.setEmail(data.getE_MAIL());
                        newWorkRequest.setWorkCreatedBy(data.getWORK_CREATEDBY());
                        newWorkRequest.setWorkAttachment(data.getWORK_ATTACHMENT());


                       *//* newWorkRequest.setWRStatus(masterWorkRequest.getData().getWRStatus());
                        newWorkRequest.setRequested(masterWorkRequest.getData().getRequested());
                        newWorkRequest.setAdditionalDescription(masterWorkRequest.getData().getAdditionalDescription());
                        newWorkRequest.setCreatedBy(masterWorkRequest.getData().getCreatedBy());
                        newWorkRequest.setCreatedById(masterWorkRequest.getData().getCreatedById());
                        newWorkRequest.setPhoneNumber(masterWorkRequest.getData().getPhoneNumber());
                        newWorkRequest.setPriority(masterWorkRequest.getData().getPriority());
                        newWorkRequest.setEmail(masterWorkRequest.getData().getEmail());
                        newWorkRequest.setStartDate(masterWorkRequest.getData().getStartDate());
                        newWorkRequest.setEndDate(masterWorkRequest.getData().getEndDate());
                        newWorkRequest.setWorkRequestType(masterWorkRequest.getData().getWorkRequestType());
                        newWorkRequest.setAssetNumber(masterWorkRequest.getData().getAssetNumber());
                        newWorkRequest.setAssetId(masterWorkRequest.getData().getAssetId());
                        newWorkRequest.setAssetDescription(masterWorkRequest.getData().getAssetDescription());
                        newWorkRequest.setDepartment(masterWorkRequest.getData().getDepartment());
                        newWorkRequest.setDepartmentId(masterWorkRequest.getData().getDepartmentId());
                        newWorkRequest.setOrganizationId(masterWorkRequest.getData().getOrganizationId());
                        newWorkRequest.setOrganizationCode(masterWorkRequest.getData().getOrganizationCode());
                        newWorkRequest.setActive(masterWorkRequest.getData().isActive());*//*
                        newWorkRequest.setCreatedOn(LocalDateTime.now());

                        // Save the newWorkRequest to the local database
                        workRequestRepository.save(newWorkRequest);

                        // Return success response with the newly added WorkRequest
                        return ResponseEntity.ok(new ResponseModel<>(true, "Added Successfully", newWorkRequest));
                    } else {
                        // Handle case where response data is null
                        return ResponseEntity.ok(new ResponseModel<>(false, "Failed to add work request to Oracle", null));
                    }
                } else {
                    // Return unauthorized response if the response is empty
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                            .body(new ResponseModel<>(false, "Login failed: Empty response from the server.", null));
                }
            } else {
                // Handle non-OK status code from Oracle service
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(new ResponseModel<>(false, "Failed to connect to the server.", null));
            }
        } catch (HttpStatusCodeException ex) {
            // Handle HTTP status code exceptions
            return ResponseEntity.status(ex.getStatusCode())
                    .body(new ResponseModel<>(false, "HTTP Error: " + ex.getStatusCode().toString(), null));
        } catch (JsonProcessingException e) {
            // Handle JSON processing exceptions
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseModel<>(false, "Error processing the response.", null));
        } catch (Exception e) {
            // Handle other unexpected exceptions
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseModel<>(false, "Unexpected error occurred.", null));
        }
    }*/



/*
    public ResponseEntity<ResponseModel<WorkRequest>> updateWorkRequest(@PathVariable String wrNumber, @Valid @RequestBody AddWorkRequest1 data) {
        try {
            String url = "http://192.168.5.175:8000/api/oracleWorkFlow/updateMasterWorkRequest/" + wrNumber;

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
//            headers.set("Authorization", AUTH_TOKEN);
            headers.set("Authorization", data.getAuthToken());

            // Create an HttpEntity with the request data and headers
            HttpEntity<AddWorkRequest1> entity = new HttpEntity<>(data, headers);

            // Send the POST request to the remote API service
            var responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity, WorkRequestResponse.class);

            // Check if the response from the remote service is successful
            if (responseEntity.getStatusCode() == HttpStatus.OK) {
                WorkRequestResponse masterWorkRequest = responseEntity.getBody();

                // Check if the request was successful and data is not null
                if (masterWorkRequest != null && masterWorkRequest.getData() != null) {
                    // Fetch existing WorkRequest from the repository
                    WorkRequest updatedWorkRequest = workRequestRepository.findByWRNumber(wrNumber);
                    if (updatedWorkRequest != null) {
                        // Update the fetched WorkRequest with data from the response
                        WorkRequestResponse.WorkRequestData responseData = masterWorkRequest.getData();
                        updatedWorkRequest.setWRNumber(responseData.getWRNumber());
                        updatedWorkRequest.setAssetGroupId(responseData.getAssetGroupId());
                        updatedWorkRequest.setAssetNumber(responseData.getAssetNumber());
                        updatedWorkRequest.setOrganizationId(responseData.getOrganizationId());
                        updatedWorkRequest.setWorkRequestPriorityId(responseData.getWorkRequestPriorityId());
                        updatedWorkRequest.setOwningDepartmentId(responseData.getOwningDepartmentId());
                        updatedWorkRequest.setExpectedStartDate(responseData.getExpectedStartDate());
                        updatedWorkRequest.setExpectedResolutionDate(responseData.getExpectedResolutionDate());
                        updatedWorkRequest.setDescription(responseData.getDescription());
                        updatedWorkRequest.setWorkRequestTypeId(responseData.getWorkRequestTypeId());
                        updatedWorkRequest.setCreatedFor(responseData.getCreatedFor());
                        updatedWorkRequest.setUserId(responseData.getUserId());
                        updatedWorkRequest.setPhoneNumber(responseData.getPhoneNumber());
                        updatedWorkRequest.setEmail(responseData.getEmail());


                        */
/*updatedWorkRequest.setWRStatus(responseData.getWRStatus());
                        updatedWorkRequest.setRequested(responseData.getRequested());
                        updatedWorkRequest.setAdditionalDescription(responseData.getAdditionalDescription());
                        updatedWorkRequest.setCreatedBy(responseData.getCreatedBy());
                        updatedWorkRequest.setCreatedById(responseData.getCreatedById());
                        updatedWorkRequest.setPhoneNumber(responseData.getPhoneNumber());
                        updatedWorkRequest.setPriority(responseData.getPriority());
                        updatedWorkRequest.setEmail(responseData.getEmail());
                        updatedWorkRequest.setStartDate(responseData.getStartDate());
                        updatedWorkRequest.setEndDate(responseData.getEndDate());
                        updatedWorkRequest.setWorkRequestType(responseData.getWorkRequestType());
                        updatedWorkRequest.setAssetNumber(responseData.getAssetNumber());
                        updatedWorkRequest.setAssetId(responseData.getAssetId());
                        updatedWorkRequest.setAssetDescription(responseData.getAssetDescription());
                        updatedWorkRequest.setDepartment(responseData.getDepartment());
                        updatedWorkRequest.setDepartmentId(responseData.getDepartmentId());
                        updatedWorkRequest.setOrganizationId(responseData.getOrganizationId());
                        updatedWorkRequest.setOrganizationCode(responseData.getOrganizationCode());
                        updatedWorkRequest.setActive(responseData.isActive());*//*

                        updatedWorkRequest.setCreatedOn(LocalDateTime.now());

                        // Save the updatedWorkRequest to the local database
                        workRequestRepository.save(updatedWorkRequest);

                        // Return success response with the updated WorkRequest
                        return ResponseEntity.ok(new ResponseModel<>(true, "Updated Successfully", updatedWorkRequest));
                    } else {
                        // Handle case where existing WorkRequest is not found
                        return ResponseEntity.ok(new ResponseModel<>(false, "Work request not found", null));
                    }
                } else {
                    // Handle case where response data or masterWorkRequest is null
                    return ResponseEntity.ok(new ResponseModel<>(false, "Failed to update work request in Oracle", null));
                }
            } else {
                // Handle non-OK status code from Oracle service
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(new ResponseModel<>(false, "Failed to connect to the server.", null));
            }
        } catch (HttpStatusCodeException ex) {
            // Handle HTTP status code exceptions
            return ResponseEntity.status(ex.getStatusCode())
                    .body(new ResponseModel<>(false, "HTTP Error: " + ex.getStatusCode().toString(), null));
        } catch (Exception e) {
            // Handle other unexpected exceptions
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseModel<>(false, "Unexpected error occurred.", null));
        }
    }
*/




/*
    public ResponseEntity<ResponseModel<WorkRequest>> addWorkRequest(@Valid @RequestBody AddWorkRequest1 data) {
        try {
            String url = "http://10.36.113.75:9054/soa-infra/resources/PM/XXHIL_EAM_MAXBYTE_WR_CREATE_UPD/WORK_REQUEST_CREATE_SERVICE/WORK_REQUEST_CREATE_RP";

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            System.out.println("Content-Type set to: " + headers.getContentType());
            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

            String username = data.getUsername();
            String password = data.getPassword();

            String authHeader = "Basic " + Base64.getEncoder().encodeToString((username + ":" + password).getBytes(StandardCharsets.UTF_8));
            headers.set(HttpHeaders.AUTHORIZATION, authHeader);
            System.out.println("AuthHeader:"+authHeader);

            HttpEntity<AddWorkRequest1> entity = new HttpEntity<>(data, headers);
            System.out.println("entity"+entity);

            ResponseEntity<String> responseEntity = restTemplate.postForEntity(url, entity, String.class);
            System.out.println("responseEntity="+responseEntity);

            if (responseEntity.getStatusCode() == HttpStatus.OK) {
                String response = responseEntity.getBody();

                if (!response.isEmpty()) {
                    ObjectMapper objectMapper = new ObjectMapper();
                    objectMapper.registerModule(new JavaTimeModule());

                    WorkRequestRequest masterWorkRequest = objectMapper.readValue(response, WorkRequestRequest.class);

                    // Check if the request was successful
                    if (masterWorkRequest != null) {

                            WorkRequest newWorkRequest = new WorkRequest();
                            newWorkRequest.setWRNumber(masterWorkRequest.getP_WORK_REQUEST_NUMBER().getWorkRequestNumber());

                            newWorkRequest.setAssetGroupId(data.getASSET_GROUP_ID());
                            newWorkRequest.setAssetNumber(data.getASSET_NUMBER());
                            newWorkRequest.setCreatedFor(data.getCREATED_FOR());
                            newWorkRequest.setOrganizationId(data.getORGANIZATION_ID());
                            newWorkRequest.setWorkRequestPriorityId(data.getWORK_REQUEST_PRIORITY_ID());
                            newWorkRequest.setOwningDepartmentId(data.getOWNING_DEPARTMENT_ID());
                            newWorkRequest.setExpectedStartDate(data.getEXPECTED_START_DATE());
                            newWorkRequest.setExpectedResolutionDate(data.getEXPECTED_RESOLUTION_DATE());
                            newWorkRequest.setDescription(data.getDESCRIPTION());
                            newWorkRequest.setWorkRequestTypeId(data.getWORK_REQUEST_TYPE_ID());
                            newWorkRequest.setUserId(data.getUSER_ID());
                            newWorkRequest.setPhoneNumber(data.getPHONE_NUMBER());
                            newWorkRequest.setEmail(data.getE_MAIL());
                            newWorkRequest.setWorkCreatedBy(data.getWORK_CREATEDBY());
                            newWorkRequest.setWorkAttachment(data.getWORK_ATTACHMENT());

                            newWorkRequest.setCreatedOn(LocalDateTime.now());
                            workRequestRepository.save(newWorkRequest);
                            return ResponseEntity.ok(new ResponseModel<>(true, "Work request added successfully", newWorkRequest));
                        }

                } else {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                            .body(new ResponseModel<>(false, "Login failed: Empty response from the server.", null));
                }
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(new ResponseModel<>(false, "Failed to connect to the server.", null));
            }
        } catch (HttpStatusCodeException ex) {
            return ResponseEntity.status(ex.getStatusCode())
                    .body(new ResponseModel<>(false, "HTTP Error: " + ex.getStatusCode().toString(), null));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseModel<>(false, "Error processing the response.", null));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseModel<>(false, "Unexpected error occurred.", null));
        }
    }
*/


/*
    public ResponseEntity<ResponseModel<WorkRequest>> addWorkRequest(@Valid @RequestBody AddWorkRequest1 data) {
        try {
//            String url = "http://10.36.113.75:9054/soa-infra/resources/PM/XXHIL_EAM_MAXBYTE_WR_CREATE_UPD/WORK_REQUEST_CREATE_SERVICE/WORK_REQUEST_CREATE_RP";
            String url = "http://ocitestekaayansoa.adityabirla.com:80/soa-infra/resources/PM/XXHIL_EAM_MAXBYTE_WR_CREATE_UPD/WORK_REQUEST_CREATE_SERVICE/WORK_REQUEST_CREATE_RP";

            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

//            String authHeader = "Basic " + Base64.getEncoder().encodeToString((data.getUsername() + ":" + data.getPassword()).getBytes(StandardCharsets.UTF_8));
//            headers.set(HttpHeaders.AUTHORIZATION, authHeader);

            HttpEntity<AddWorkRequest1> entity = new HttpEntity<>(data, headers);
            System.out.println("EntityDetails:"+entity);
//            ResponseEntity<String> responseEntity = restTemplate.postForEntity(url, entity, String.class);
            ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
            System.out.println("ResponseEntity:"+responseEntity);
            // Handle response
            if (responseEntity.getStatusCode() == HttpStatus.OK) {
                String response = responseEntity.getBody();

                if (!response.isEmpty()) {
                    ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

                    // Deserialize JSON response into WorkRequestRequest object
                    WorkRequestRequest masterWorkRequest = objectMapper.readValue(response, WorkRequestRequest.class);

                    // Check if the request was successful
                    if (masterWorkRequest != null) {
                        // Process response and save to database
                        WorkRequest newWorkRequest = new WorkRequest();
                        newWorkRequest.setWRNumber(masterWorkRequest.getP_WORK_REQUEST_NUMBER().getWorkRequestNumber());

                        newWorkRequest.setP_ASSET_GROUP_ID(data.getP_ASSET_GROUP_ID());
                        newWorkRequest.setP_ASSET_NUMBER(data.getP_ASSET_NUMBER());
                        newWorkRequest.setP_CREATED_FOR(data.getP_CREATED_FOR());
                        newWorkRequest.setP_ORGANIZATION_ID(data.getP_ORGANIZATION_ID());
                        newWorkRequest.setP_WORK_REQUEST_PRIORITY_ID(data.getP_WORK_REQUEST_PRIORITY_ID());
                        newWorkRequest.setP_OWNING_DEPARTMENT_ID(data.getP_OWNING_DEPARTMENT_ID());
                        newWorkRequest.setP_EXPECTED_START_DATE(data.getP_EXPECTED_START_DATE());
                        newWorkRequest.setP_EXPECTED_RESOLUTION_DATE(data.getP_EXPECTED_RESOLUTION_DATE());
                        newWorkRequest.setP_DESCRIPTION(data.getP_DESCRIPTION());
                        newWorkRequest.setP_WORK_REQUEST_TYPE_ID(data.getP_WORK_REQUEST_TYPE_ID());
                        newWorkRequest.setP_USER_ID(data.getP_USER_ID());
                        newWorkRequest.setP_PHONE_NUMBER(data.getP_PHONE_NUMBER());
                        newWorkRequest.setP_E_MAIL(data.getP_E_MAIL());
                        newWorkRequest.setP_WORK_CREATEDBY(data.getP_WORK_CREATEDBY());
                        newWorkRequest.setP_WORK_ATTACHMENT(data.getP_WORK_ATTACHMENT());

                        newWorkRequest.setCreatedOn(LocalDateTime.now());
                        workRequestRepository.save(newWorkRequest);
                        return ResponseEntity.ok(new ResponseModel<>(true, "Work request added successfully", newWorkRequest));
                    } else {
                        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                .body(new ResponseModel<>(false, "Failed to process the response.", null));
                    }
                } else {
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                            .body(new ResponseModel<>(false, "Empty response from the server.", null));
                }
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(new ResponseModel<>(false, "Failed to connect to the server.", null));
            }
        } catch (HttpStatusCodeException ex) {
            return ResponseEntity.status(ex.getStatusCode())
                    .body(new ResponseModel<>(false, "HTTP Error: " + ex.getStatusCode().toString(), null));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseModel<>(false, "Error processing the response.", null));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseModel<>(false, "Unexpected error occurred.", null));
        }
    }
*/

//    @PostMapping("/addWorkRequest")
//    public ResponseEntity<ResponseModel<String>> addWorkRequest(@RequestBody AddWorkRequest1 data) {
//        try {
////            String url = "http://10.36.113.75:9054/soa-infra/resources/PM/XXHIL_EAM_MAXBYTE_WR_CREATE_UPD/WORK_REQUEST_CREATE_SERVICE/WORK_REQUEST_CREATE_RP";
//            String url = "http://ekaayansoa.adityabirla.com/soa-infra/resources/PM/XXHIL_EAM_MAXBYTE_WR_CREATE_UPD/WORK_REQUEST_CREATE_SERVICE/WORK_REQUEST_CREATE_RP";
//
//
//            System.out.println(data);
//            System.out.println(data.getP_ASSET_NUMBER());
//            System.out.println(data.getP_ASSET_GROUP_ID());
//            System.out.println(data.getP_ASSET_GROUP_ID());
//            RestTemplate restTemplate = new RestTemplate();
//            HttpHeaders headers = new HttpHeaders();
//            headers.setContentType(MediaType.APPLICATION_JSON);
//            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
//
////            String authHeader = "Basic " + Base64.getEncoder().encodeToString((data.getUsername() + ":" + data.getPassword()).getBytes(StandardCharsets.UTF_8));
////            headers.set(HttpHeaders.AUTHORIZATION, authHeader);
//
//            MultiValueMap<String, String> body = new LinkedMultiValueMap<String, String>();
//            body.add("P_ASSET_GROUP_ID", data.getP_ASSET_GROUP_ID());
//            body.add("P_ASSET_NUMBER", data.getP_ASSET_NUMBER());
//            body.add("P_CREATED_FOR", data.getP_CREATED_FOR());
//            body.add("P_DESCRIPTION", data.getP_DESCRIPTION());
//            body.add("P_EXPECTED_RESOLUTION_DATE", data.getP_EXPECTED_RESOLUTION_DATE());
//            body.add("P_EXPECTED_START_DATE", data.getP_EXPECTED_START_DATE());
//            body.add("P_E_MAIL", data.getP_E_MAIL());
//            body.add("P_ORGANIZATION_ID", data.getP_ORGANIZATION_ID());
//            body.add("P_OWNING_DEPARTMENT_ID", data.getP_OWNING_DEPARTMENT_ID());
//            body.add("P_PHONE_NUMBER", data.getP_PHONE_NUMBER());
//            body.add("P_USER_ID", data.getP_USER_ID());
//            body.add("P_WORK_ATTACHMENT", data.getP_WORK_ATTACHMENT());
//            body.add("P_WORK_CREATEDBY", data.getP_WORK_CREATEDBY());
//            body.add("P_WORK_REQUEST_PRIORITY_ID", data.getP_WORK_REQUEST_PRIORITY_ID());
//            body.add("P_WORK_REQUEST_TYPE_ID", data.getP_WORK_REQUEST_TYPE_ID());
//
//            HttpEntity<MultiValueMap> entity = new HttpEntity<>(body, headers);
//            System.out.println("EntityDetails:"+entity);
////            ResponseEntity<String> responseEntity = restTemplate.postForEntity(url, entity, String.class);
//            ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
//            System.out.println("ResponseEntity:"+responseEntity);
//            // Handle response
//            if (responseEntity.getStatusCode() == HttpStatus.OK) {
//                String response = responseEntity.getBody();
//
//                System.out.println(response);
//
//                if (!response.isEmpty()) {
//                    ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
//
//                    // Deserialize JSON response into WorkRequestRequest object
//                    EAMResponse masterWorkRequest = objectMapper.readValue(response, EAMResponse.class);
//
//                    //System.out.println(masterWorkRequest);
//
//                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                            .body(new ResponseModel<>(false, "Failed to process the response1.", null));
//
//                    // Check if the request was successful
//                    /*if (masterWorkRequest != null) {
//                        return ResponseEntity.ok(new ResponseModel<>(true, "Work request added successfully", *//*masterWorkRequest.getP_WORK_REQUEST_NUMBER().getWorkRequestNumber()*//*"test"));
//                    } else {
//                        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                                .body(new ResponseModel<>(false, "Failed to process the response.", null));
//                    }*/
//                } else {
//                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                            .body(new ResponseModel<>(false, "Empty response from the server.", null));
//                }
//            } else {
//                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                        .body(new ResponseModel<>(false, "Failed to connect to the server.", null));
//            }
//        } catch (HttpStatusCodeException ex) {
//            return ResponseEntity.status(ex.getStatusCode())
//                    .body(new ResponseModel<>(false, "HTTP Error: " + ex.getStatusCode().toString(), null));
//        } catch (Exception e) {
//            e.printStackTrace();
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body(new ResponseModel<>(false, "Unexpected error occurred.", null));
//        }
//    }

    ////////////////////// old code   >>>>>>>>>>>>>>>>>>

//    public ResponseEntity<ResponseModel<String>> addWorkRequest(@RequestBody AddWorkRequest data) {
//        try {
//            String url = "http://10.36.113.75:9054/soa-infra/resources/PM/XXHIL_EAM_MAXBYTE_WR_CREATE_UPD/WORK_REQUEST_CREATE_SERVICE/WORK_REQUEST_CREATE_RP";
////            String url = "http://ekaayansoa.adityabirla.com/soa-infra/resources/PM/XXHIL_EAM_MAXBYTE_WR_CREATE_UPD/WORK_REQUEST_CREATE_SERVICE/WORK_REQUEST_CREATE_RP";
//            //String url = "http://ocitestekaayansoa.adityabirla.com:80/soa-infra/resources/PM/XXHIL_EAM_MAXBYTE_WR_CREATE_UPD/WORK_REQUEST_CREATE_SERVICE/WORK_REQUEST_CREATE_RP";
//
////            System.out.println(data);
////            System.out.println(data.getP_ASSET_NUMBER());
////            System.out.println(data.getP_ASSET_GROUP_ID());
////            System.out.println(data.getP_ASSET_GROUP_ID());
//            RestTemplate restTemplate = new RestTemplate();
//            HttpHeaders headers = new HttpHeaders();
//            headers.setContentType(MediaType.APPLICATION_JSON);
//            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
//
////            String authHeader = "Basic " + Base64.getEncoder().encodeToString((data.getUsername() + ":" + data.getPassword()).getBytes(StandardCharsets.UTF_8));
////            headers.set(HttpHeaders.AUTHORIZATION, authHeader);
//
//            MultiValueMap<String, String> body = new LinkedMultiValueMap<String, String>();
//            body.add("P_ASSET_GROUP_ID", data.getP_ASSET_GROUP_ID());
//            body.add("P_ASSET_NUMBER", data.getP_ASSET_NUMBER());
//            body.add("P_CREATED_FOR", data.getP_CREATED_FOR());
//            body.add("P_DESCRIPTION", data.getP_DESCRIPTION());
//            body.add("P_EXPECTED_RESOLUTION_DATE", data.getP_EXPECTED_RESOLUTION_DATE());
//            body.add("P_EXPECTED_START_DATE", data.getP_EXPECTED_START_DATE());
//            body.add("P_E_MAIL", data.getP_E_MAIL());
//            body.add("P_ORGANIZATION_ID", data.getP_ORGANIZATION_ID());
//            body.add("P_OWNING_DEPARTMENT_ID", data.getP_OWNING_DEPARTMENT_ID());
//            body.add("P_PHONE_NUMBER", data.getP_PHONE_NUMBER());
//            body.add("P_USER_ID", data.getP_USER_ID());
//            body.add("P_WORK_ATTACHMENT", data.getP_WORK_ATTACHMENT());
//            body.add("P_WORK_CREATEDBY", data.getP_WORK_CREATEDBY());
//            body.add("P_WORK_REQUEST_PRIORITY_ID", data.getP_WORK_REQUEST_PRIORITY_ID());
//            body.add("P_WORK_REQUEST_TYPE_ID", data.getP_WORK_REQUEST_TYPE_ID());
//
//            HttpEntity<MultiValueMap> entity = new HttpEntity<>(body, headers);
//            // System.out.println("EntityDetails:"+entity);
////            ResponseEntity<String> responseEntity = restTemplate.postForEntity(url, entity, String.class);
//            ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
//            // System.out.println("ResponseEntity:"+responseEntity);
//            // Handle response
//            if (responseEntity.getStatusCode() == HttpStatus.OK) {
//                String response = responseEntity.getBody();
//
//                System.out.println(response);
//
//                if (!response.isEmpty()) {
//                    ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
//
//                    JsonNode jsonNode = objectMapper.readTree(response);
//
//                    String responseStatus = jsonNode.get("P_RETURN_STATUS").asText();
//
//                    if (responseStatus != null) {
//                        if (responseStatus.equals("S")) {
//                            String requestNumber = jsonNode.get("P_WORK_REQUEST_NUMBER").asText();
//
//                            //WorkRequest masterWorkRequest = objectMapper.readValue(response, WorkRequest.class);
//
////                            WorkRequest newWorkRequest = new WorkRequest();
////                            newWorkRequest.setWRNumber(requestNumber);
////
////                            newWorkRequest.setP_ASSET_GROUP_ID(data.getP_ASSET_GROUP_ID());
////                            newWorkRequest.setP_ASSET_NUMBER(data.getP_ASSET_NUMBER());
////                            newWorkRequest.setP_CREATED_FOR(data.getP_CREATED_FOR());
////                            newWorkRequest.setP_ORGANIZATION_ID(data.getP_ORGANIZATION_ID());
////                            newWorkRequest.setP_WORK_REQUEST_PRIORITY_ID(data.getP_WORK_REQUEST_PRIORITY_ID());
////                            newWorkRequest.setP_OWNING_DEPARTMENT_ID(data.getP_OWNING_DEPARTMENT_ID());
////                            newWorkRequest.setP_EXPECTED_START_DATE(data.getP_EXPECTED_START_DATE());
////                            newWorkRequest.setP_EXPECTED_RESOLUTION_DATE(data.getP_EXPECTED_RESOLUTION_DATE());
////                            newWorkRequest.setP_DESCRIPTION(data.getP_DESCRIPTION());
////                            newWorkRequest.setP_WORK_REQUEST_TYPE_ID(data.getP_WORK_REQUEST_TYPE_ID());
////                            newWorkRequest.setP_USER_ID(data.getP_USER_ID());
////                            newWorkRequest.setP_PHONE_NUMBER(data.getP_PHONE_NUMBER());
////                            newWorkRequest.setP_E_MAIL(data.getP_E_MAIL());
////                            newWorkRequest.setP_WORK_CREATEDBY(data.getP_WORK_CREATEDBY());
////                            newWorkRequest.setP_WORK_ATTACHMENT(data.getP_WORK_ATTACHMENT());
////
////                            newWorkRequest.setCreatedOn(LocalDateTime.now());
////                            workRequestRepository.save(newWorkRequest);
//
////            MultiValueMap<String, String> body = new LinkedMultiValueMap<String, String>();
////            body.add("P_ASSET_GROUP_ID", String.valueOf(data.getAssetGroupId()));
////            body.add("P_ASSET_NUMBER", data.getAssetNumber());
////            body.add("P_CREATED_FOR", String.valueOf(data.getCreatedBy()));
////            body.add("P_DESCRIPTION", data.getDescription());
////            body.add("P_EXPECTED_RESOLUTION_DATE", String.valueOf(data.getExpectedResolutionDate()));
////            body.add("P_EXPECTED_START_DATE", String.valueOf(data.getExpectedStartDate()));
////           // body.add("P_E_MAIL", data.getP_E_MAIL());
////            body.add("P_ORGANIZATION_ID", String.valueOf(data.getOrganizationId()));
////            body.add("P_OWNING_DEPARTMENT_ID", String.valueOf(data.getWorkRequestOwningDeptId()));
////          //  body.add("P_PHONE_NUMBER", data.getP_PHONE_NUMBER());
//////            body.add("P_USER_ID", data.getP_USER_ID());
//////            body.add("P_WORK_ATTACHMENT", data.getP_WORK_ATTACHMENT());
////            body.add("P_WORK_CREATEDBY", String.valueOf(data.getWorkRequestCreatedBy()));
////            body.add("P_WORK_REQUEST_PRIORITY_ID", String.valueOf(data.getWorkRequestPriorityId()));
////            body.add("P_WORK_REQUEST_TYPE_ID", String.valueOf(data.getWorkRequestTypeId()));
////
////            HttpEntity<MultiValueMap> entity = new HttpEntity<>(body, headers);
////            // System.out.println("EntityDetails:"+entity);
//////            ResponseEntity<String> responseEntity = restTemplate.postForEntity(url, entity, String.class);
////            ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
////            // System.out.println("ResponseEntity:"+responseEntity);
////            // Handle response
////            if (responseEntity.getStatusCode() == HttpStatus.OK) {
////                String response = responseEntity.getBody();
////
////                System.out.println(response);
////
////                if (!response.isEmpty()) {
////                    ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
////
////                    JsonNode jsonNode = objectMapper.readTree(response);
////
////                    String responseStatus = jsonNode.get("P_RETURN_STATUS").asText();
////
////                    if (responseStatus != null) {
////                        if (responseStatus.equals("S")) {
////                            String requestNumber = jsonNode.get("P_WORK_REQUEST_NUMBER").asText();
////
////                            //WorkRequest masterWorkRequest = objectMapper.readValue(response, WorkRequest.class);
////
////                            WorkRequest newWorkRequest = new WorkRequest();
////                            newWorkRequest.setWorkRequestId(Integer.valueOf(requestNumber));
////
////                            newWorkRequest.setAssetGroupId(data.getAssetGroupId()));
////                            newWorkRequest.setAssetNumber(data.getAssetNumber());
////                            newWorkRequest.setCreatedBy(data.getCreatedBy());
////                            newWorkRequest.setOrganizationId(data.getOrganizationId());
////                            newWorkRequest.setWorkRequestId(data.getWorkRequestPriorityId());
////                            newWorkRequest.setWorkRequestOwningDeptId(data.getWorkRequestOwningDeptId());
////                            newWorkRequest.setExpectedStartDate(data.getExpectedStartDate());
////                            newWorkRequest.setExpectedResolutionDate(data.getExpectedResolutionDate());
////                            newWorkRequest.setDescription(data.getDescription());
////                            newWorkRequest.setWorkRequestTypeId(data.getWorkRequestId());
//////                            newWorkRequest.setP_USER_ID(data.getP_USER_ID());
//////                            newWorkRequest.setP_PHONE_NUMBER(data.getP_PHONE_NUMBER());
//////                            newWorkRequest.setP_E_MAIL(data.getP_E_MAIL());
////                            newWorkRequest.setWorkRequestCreatedBy(data.getWorkRequestCreatedBy());
//////                            newWorkRequest.setP_WORK_ATTACHMENT(data.getP_WORK_ATTACHMENT());
////
//////                            newWorkRequest.setCreatedOn(LocalDateTime.now());
////                            workRequestRepository.save(newWorkRequest);
//
//                            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                                    .body(new ResponseModel<>(true, "Successfully Created!.", requestNumber));
//                        } else {
//
//                            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                                    .body(new ResponseModel<>(false, "Failed to process the response.", null));
//
//                        }
//                    }
//
//                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                            .body(new ResponseModel<>(false, "Failed to process the response1.", null));
//
//                } else {
//                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                            .body(new ResponseModel<>(false, "Empty response from the server.", null));
//                }
//            } else {
//                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                        .body(new ResponseModel<>(false, "Failed to connect to the server.", null));
//            }
//        } catch (HttpStatusCodeException ex) {
//            return ResponseEntity.status(ex.getStatusCode())
//                    .body(new ResponseModel<>(false, "HTTP Error: " + ex.getStatusCode().toString(), null));
//        } catch (Exception e) {
//            e.printStackTrace();
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body(new ResponseModel<>(false, "Unexpected error occurred.", null));
//        }
//    }
    // Run every 5 minutes
//    public void addMasterAssetGroupDataAutomaticallys(){
//        List<MasterWorkRequest> masterWorkRequests = masterWorkRequestRepository.findAll();
//
//        for(MasterWorkRequest masterWorkRequest :masterWorkRequests){
//
//            Optional<WorkRequest> optionalWorkRequest = workRequestRepository.findByRowId(masterWorkRequest.getRowId());
//
//            WorkRequest workRequest;
//            if (optionalWorkRequest.isPresent()) {
//                workRequest = optionalWorkRequest.get();
//                workRequest.setRowId(masterWorkRequest.getRowId());
//                workRequest.setAssetGroupId(masterWorkRequest.getAssetGroupId()));
//                workRequest.setAssetNumber(masterWorkRequest.getAssetNumber());
//                workRequest.setCreatedBy(masterWorkRequest.getCreatedBy());
//                workRequest.setDescription(masterWorkRequest.getDescription());
//                workRequest.setExpectedResolutionDate(masterWorkRequest.getExpectedResolutionDate());
//                workRequest.setExpectedStartDate(masterWorkRequest.getExpectedStartDate());
////                workRequest.setP_E_MAIL(masterWorkRequest.getMailId());
//                workRequest.setOrganizationId(masterWorkRequest.getOrganizationId());
//                workRequest.setWorkRequestOwningDeptId(masterWorkRequest.getWorkRequestOwningDeptId());
////                workRequest.setP_PHONE_NUMBER(masterWorkRequest.);
////                workRequest.setP_USER_ID(masterWorkRequest.);
////                workRequest.setP_WORK_ATTACHMENT(masterWorkRequest.get);
//                workRequest.setWorkRequestCreatedBy(masterWorkRequest.getWorkRequestCreatedBy());
//                workRequest.setWorkRequestPriorityId(masterWorkRequest.getWorkRequestPriorityId());
//                workRequest.setWorkRequestTypeId(masterWorkRequest.getWorkRequestTypeId());
//                workRequest.setWorkRequestAutoApprove(masterWorkRequest.getWorkRequestAutoApprove());
//                workRequest.setWorkRequestPriority(masterWorkRequest.getWorkRequestPriority());
//
//                System.out.println("Updated assetGroup with AssetGroupId = " + workRequest.getWorkRequestId());
//            } else {
//                workRequest = new WorkRequest();
//               workRequest.setRowId(masterWorkRequest.getRowId());
//                workRequest.setAssetGroupId(masterWorkRequest.getAssetGroupId()));
//                workRequest.setAssetNumber(masterWorkRequest.getAssetNumber());
//                workRequest.setCreatedBy(masterWorkRequest.getCreatedBy());
//                workRequest.setDescription(masterWorkRequest.getDescription());
//                workRequest.setExpectedResolutionDate(masterWorkRequest.getExpectedResolutionDate());
//                workRequest.setExpectedStartDate(masterWorkRequest.getExpectedStartDate());
////                workRequest.setP_E_MAIL(masterWorkRequest.getMailId());
//                workRequest.setOrganizationId(masterWorkRequest.getOrganizationId());
//                workRequest.setWorkRequestOwningDeptId(masterWorkRequest.getWorkRequestOwningDeptId());
////                workRequest.setP_PHONE_NUMBER(masterWorkRequest.);
////                workRequest.setP_USER_ID(masterWorkRequest.);
////                workRequest.setP_WORK_ATTACHMENT(masterWorkRequest.get);
//                workRequest.setWorkRequestCreatedBy(masterWorkRequest.getWorkRequestCreatedBy());
//                workRequest.setWorkRequestPriorityId(masterWorkRequest.getWorkRequestPriorityId());
//                workRequest.setWorkRequestTypeId(masterWorkRequest.getWorkRequestTypeId());
//                workRequest.setWorkRequestAutoApprove(masterWorkRequest.getWorkRequestAutoApprove());
//                workRequest.setWorkRequestPriority(masterWorkRequest.getWorkRequestPriority());
//              //  System.out.println("Inserted new assetGroup with assetGroupId = " + assetGroup1.getAssetGroupId());
//            }
//
//            workRequestRepository.save(workRequest);
//
//        }
//
//    }


    private void fetchAndSaveData() throws Exception {
        // Get the latest record's last update date from our OracleDB repository
        Optional<MasterWorkRequest> latestRecordOpt = masterWorkRequestRepository.findTopByOrderByLastUpdateDateDesc();
        LocalDateTime lastUpdateDateTime = latestRecordOpt.map(MasterWorkRequest::getLastUpdateDate).orElse(null);

        // Convert LocalDateTime to Timestamp to avoid precision issues
        Timestamp lastUpdateTimestamp = (lastUpdateDateTime != null) ? Timestamp.valueOf(lastUpdateDateTime) : null;

        // Query the external APPS.WIP_EAM_WORK_REQUESTS_V table for records updated after or at our latest update date
        String sql = "SELECT * FROM APPS.WIP_EAM_WORK_REQUESTS_V WHERE LAST_UPDATE_DATE >= ?";

        List<MasterWorkRequest> newRecords;

        if (lastUpdateTimestamp != null) {
            newRecords = jdbcTemplate.query(
                    sql,
                    new Object[]{lastUpdateTimestamp},
                    BeanPropertyRowMapper.newInstance(MasterWorkRequest.class)
            );
        } else {
            // If there's no last update timestamp, fetch all records
            newRecords = jdbcTemplate.query(
                    "SELECT * FROM APPS.WIP_EAM_WORK_REQUESTS_V",
                    BeanPropertyRowMapper.newInstance(MasterWorkRequest.class)
            );
        }

        // Save the fetched records to both local OracleDB and SAM DB
        if (newRecords.isEmpty()) {
            System.out.println("********************No new Work Requests found.");
        } else {
            System.out.println("********************New Work Requests found: " + newRecords.size());

            for (MasterWorkRequest masterWorkRequest : newRecords) {
                // Save to local OracleDB
                boolean existsInMaster = masterWorkRequestRepository.existsByWorkRequestNumber(masterWorkRequest.getWorkRequestNumber());
                if (!existsInMaster) {
                    masterWorkRequestRepository.save(masterWorkRequest);
                    System.out.println("Saved Work Request in Master DB: " + masterWorkRequest.getWorkRequestNumber());
                } else {
                    System.out.println("Skipped duplicate Work Request in Master DB: " + masterWorkRequest.getWorkRequestNumber());
                }

                EmployeeDetails employeeDetails = employeeDetailsRepository.findById(masterWorkRequest.getCreatedBy()).orElse(null);
                EmployeeDetails createdByName = employeeDetailsRepository.findById(masterWorkRequest.getWorkRequestCreatedBy()).orElse(null);

                Asset assetNumber = assetRepository.findByAssetNumber(masterWorkRequest.getAssetNumber());
                // Save to SAM DB
                boolean existsInSam = workRequestRepository.existsByWorkRequestNumber(masterWorkRequest.getWorkRequestNumber());
                if (!existsInSam) {
                    WorkRequest workRequest = new WorkRequest();

                    workRequest.setRowId(masterWorkRequest.getRowId());
                    workRequest.setWorkRequestId(masterWorkRequest.getWorkRequestId());
                    workRequest.setWorkRequestNumber(masterWorkRequest.getWorkRequestNumber());
                    workRequest.setDescription(masterWorkRequest.getDescription());
                    workRequest.setLastUpdateDate(masterWorkRequest.getLastUpdateDate());
                    workRequest.setLastUpdatedBy(masterWorkRequest.getLastUpdatedBy());
                    workRequest.setCreationDate(masterWorkRequest.getCreationDate()); // You may still want to store CreationDate if needed
                    workRequest.setCreatedBy(masterWorkRequest.getCreatedBy());
                    if (employeeDetails != null) {
                        workRequest.setCreatedByName(employeeDetails.getFullName()); // Assuming you want to use the employee's full name
                    } else {
                        workRequest.setCreatedByName(""); // Fallback value if employee details are not found
                    }

                    if (createdByName != null) {
                        workRequest.setWorkRequestCreatedByName(createdByName.getFullName()); // Assuming you want to use the employee's full name
                    } else {
                        workRequest.setWorkRequestCreatedByName(""); // Fallback value if employee details are not found
                    }
                    workRequest.setLastUpdateLogin(masterWorkRequest.getLastUpdateLogin());
                    workRequest.setAssetNumber(masterWorkRequest.getAssetNumber());
                    if (assetNumber != null && assetNumber.getAssetNumber().equals(masterWorkRequest.getAssetNumber())) {
                        workRequest.setAssetId(assetNumber.getAssetId()); // Set assetGroup from Asset to WorkRequest
                        workRequest.setAssetGroupId(assetNumber.getAssetGroupId()); // Set assetGroup from Asset to WorkRequest
                        workRequest.setAssetGroup(assetNumber.getAssetGroup()); // Set assetGroup from Asset to WorkRequest
                    }

                    workRequest.setOrganizationId(masterWorkRequest.getOrganizationId());
                    workRequest.setWorkRequestStatusId(masterWorkRequest.getWorkRequestStatusId());
                    workRequest.setWorkRequestStatus(masterWorkRequest.getWorkRequestStatus());
                    workRequest.setWorkRequestPriorityId(masterWorkRequest.getWorkRequestPriorityId());
                    workRequest.setWorkRequestPriority(masterWorkRequest.getWorkRequestPriority());
                    workRequest.setWorkRequestOwningDeptId(masterWorkRequest.getWorkRequestOwningDeptId());
                    workRequest.setWorkRequestOwningDept(masterWorkRequest.getWorkRequestOwningDept());
                    workRequest.setExpectedResolutionDate(masterWorkRequest.getExpectedResolutionDate());
                    workRequest.setWipEntityId(masterWorkRequest.getWipEntityId());
                    workRequest.setWipEntityName(masterWorkRequest.getWipEntityName());
                    workRequest.setAttributeCategory(masterWorkRequest.getAttributeCategory());
                    workRequest.setAttribute1(masterWorkRequest.getAttribute1());
                    workRequest.setAttribute2(masterWorkRequest.getAttribute2());
                    workRequest.setAttribute3(masterWorkRequest.getAttribute3());
                    workRequest.setAttribute4(masterWorkRequest.getAttribute4());
                    workRequest.setAttribute5(masterWorkRequest.getAttribute5());
                    workRequest.setAttribute6(masterWorkRequest.getAttribute6());
                    workRequest.setAttribute7(masterWorkRequest.getAttribute7());
                    workRequest.setAttribute8(masterWorkRequest.getAttribute8());
                    workRequest.setAttribute9(masterWorkRequest.getAttribute9());
                    workRequest.setAttribute10(masterWorkRequest.getAttribute10());
                    workRequest.setAttribute11(masterWorkRequest.getAttribute11());
                    workRequest.setAttribute12(masterWorkRequest.getAttribute12());
                    workRequest.setAttribute13(masterWorkRequest.getAttribute13());
                    workRequest.setAttribute14(masterWorkRequest.getAttribute14());
                    workRequest.setAttribute15(masterWorkRequest.getAttribute15());
                    workRequest.setWorkRequestAutoApprove(masterWorkRequest.getWorkRequestAutoApprove());
                    workRequest.setWorkRequestTypeId(masterWorkRequest.getWorkRequestTypeId());
                    workRequest.setWorkRequestType(masterWorkRequest.getWorkRequestType());
                    workRequest.setWorkRequestCreatedBy(masterWorkRequest.getWorkRequestCreatedBy());
                    workRequest.setAssetNumberDescription(masterWorkRequest.getAssetNumberDescription());
                    workRequest.setAssetLocationId(masterWorkRequest.getAssetLocationId());
                    workRequest.setAssetLocation(masterWorkRequest.getAssetLocation());
                    workRequest.setAssetCategoryId(masterWorkRequest.getAssetCategoryId());
                    workRequest.setExpectedStartDate(masterWorkRequest.getExpectedStartDate());
                    workRequest.setAssetCriticality(masterWorkRequest.getAssetCriticality());

                    // Save the new record in SAM database
                    workRequestRepository.save(workRequest);
                    System.out.println("Saved Work Request in SAM DB: " + workRequest.getWorkRequestNumber());
                } else {
                    System.out.println("Skipped duplicate Work Request in SAM DB: " + masterWorkRequest.getWorkRequestNumber());
                }
            }
        }
    }


    public ResponseEntity<ResponseModel<String>> addWorkRequest(@RequestBody AddWorkRequest1 data) {
        try {
            String url = "http://10.36.113.75:9054/soa-infra/resources/PM/XXHIL_EAM_MAXBYTE_WR_CREATE_UPD/WORK_REQUEST_CREATE_SERVICE/WORK_REQUEST_CREATE_RP";
            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

            MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
            body.add("P_ASSET_GROUP_ID", data.getP_ASSET_GROUP_ID());
            body.add("P_ASSET_NUMBER", data.getP_ASSET_NUMBER());
            body.add("P_CREATED_FOR", data.getP_CREATED_FOR());
            body.add("P_DESCRIPTION", data.getP_DESCRIPTION());
            body.add("P_EXPECTED_RESOLUTION_DATE", data.getP_EXPECTED_RESOLUTION_DATE());
            body.add("P_EXPECTED_START_DATE", data.getP_EXPECTED_START_DATE());
            body.add("P_E_MAIL", data.getP_E_MAIL());
            body.add("P_ORGANIZATION_ID", data.getP_ORGANIZATION_ID());
            body.add("P_OWNING_DEPARTMENT_ID", data.getP_OWNING_DEPARTMENT_ID());
            body.add("P_PHONE_NUMBER", data.getP_PHONE_NUMBER());
            body.add("P_USER_ID", data.getP_USER_ID());
            body.add("P_WORK_ATTACHMENT", data.getP_WORK_ATTACHMENT());
            body.add("P_WORK_CREATEDBY", data.getP_WORK_CREATEDBY());
            body.add("P_WORK_REQUEST_PRIORITY_ID", data.getP_WORK_REQUEST_PRIORITY_ID());
            body.add("P_WORK_REQUEST_TYPE_ID", data.getP_WORK_REQUEST_TYPE_ID());

            HttpEntity<MultiValueMap> entity = new HttpEntity<>(body, headers);
            ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
            System.out.println("Response Entity"+ responseEntity);

            if (responseEntity.getStatusCode() == HttpStatus.OK) {
                String response = responseEntity.getBody();

                if (!response.isEmpty()) {
                    ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
                    JsonNode jsonNode = objectMapper.readTree(response);
                    String responseStatus = jsonNode.get("P_RETURN_STATUS").asText();

                    if (responseStatus != null && responseStatus.equals("S")) {
                        String requestNumber = jsonNode.get("P_WORK_REQUEST_NUMBER").asText();
                        System.out.println(requestNumber);

                        // Execute the method to fetch and save data
                        fetchAndSaveData();

                        return ResponseEntity.status(HttpStatus.OK)
                                .body(new ResponseModel<>(true, "Successfully Created!.", requestNumber));
                    } else {
                        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                .body(new ResponseModel<>(false, "Failed to process the response.", null));
                    }
                } else {
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                            .body(new ResponseModel<>(false, "Empty response from the server.", null));
                }
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(new ResponseModel<>(false, "Failed to connect to the server.", null));
            }
        } catch (HttpStatusCodeException ex) {
            return ResponseEntity.status(ex.getStatusCode())
                    .body(new ResponseModel<>(false, "HTTP Error: " + ex.getStatusCode().toString(), null));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseModel<>(false, "Unexpected error occurred.", null));
        }
    }


        public ResponseEntity<ResponseModel<String>> updateWorkRequest(@RequestBody UpdateWorkRequest data) {
            try {
                String url = "http://10.36.113.75:9054/soa-infra/resources/PM/XXHIL_EAM_MAXBYTE_WR_CREATE_UPD/WORK_REQUEST_UPDATE_SERVICE/WORK_REQUEST_UPDATE_RP";
                RestTemplate restTemplate = new RestTemplate();
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

                MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
                body.add("P_ASSET_GROUP_ID", data.getP_ASSET_GROUP_ID());
                body.add("P_ASSET_NUMBER", data.getP_ASSET_NUMBER());
                body.add("P_CREATED_FOR", data.getP_CREATED_FOR());
                body.add("P_DESCRIPTION", data.getP_DESCRIPTION());
                body.add("P_EXPECTED_RESOLUTION_DATE", data.getP_EXPECTED_RESOLUTION_DATE());
                body.add("P_EXPECTED_START_DATE", data.getP_EXPECTED_START_DATE());
                body.add("P_E_MAIL", data.getP_E_MAIL());
                body.add("P_ORGANIZATION_ID", data.getP_ORGANIZATION_ID());
                body.add("P_OWNING_DEPARTMENT_ID", data.getP_OWNING_DEPARTMENT_ID());
                body.add("P_PHONE_NUMBER", data.getP_PHONE_NUMBER());
                body.add("P_USER_ID", data.getP_USER_ID());
                body.add("P_WORK_ATTACHMENT", data.getP_WORK_ATTACHMENT());
                //body.add("P_WORK_CREATEDBY", data.getP_WORK_CREATEDBY());
                body.add("P_WORK_REQUEST_PRIORITY_ID", data.getP_WORK_REQUEST_PRIORITY_ID());
                body.add("P_WORK_REQUEST_TYPE_ID", data.getP_WORK_REQUEST_TYPE_ID());
                body.add("P_WORK_REQUEST_ID",data.getP_WORK_REQUEST_ID());


                HttpEntity<MultiValueMap> entity = new HttpEntity<>(body, headers);
                System.out.println("Entity :" + entity);
                ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.PUT, entity, String.class);
                System.out.println("Response Entity"+ responseEntity);

                if (responseEntity.getStatusCode() == HttpStatus.OK) {
                    String response = responseEntity.getBody();

                    System.out.println("Response :"+response);

                    if (!response.isEmpty()) {
                        ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
                        JsonNode jsonNode = objectMapper.readTree(response);
                        String responseStatus = jsonNode.get("P_RETURN_STATUS").asText();

                        if (responseStatus != null && responseStatus.equals("S")) {
                            String requestNumber = jsonNode.get("P_WORK_REQUEST_NUMBER").asText();
                            System.out.println(requestNumber);

                            // Execute the method to fetch and save data
    //                        fetchAndSaveData();
                            updateAndSaveData();

                            return ResponseEntity.status(HttpStatus.OK)
                                    .body(new ResponseModel<>(true, "Successfully Updated!.", requestNumber));
                        } else {
                            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                    .body(new ResponseModel<>(false, "Failed to process the response.", null));
                        }
                    } else {
                        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                .body(new ResponseModel<>(false, "Empty response from the server.", null));
                    }
                } else {
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                            .body(new ResponseModel<>(false, "Failed to connect to the server.", null));
                }
            } catch (HttpStatusCodeException ex) {
                return ResponseEntity.status(ex.getStatusCode())
                        .body(new ResponseModel<>(false, "HTTP Error: " + ex.getStatusCode().toString(), null));
            } catch (Exception e) {
                e.printStackTrace();
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(new ResponseModel<>(false, "Unexpected error occurred.", null));
            }
        }

    private void updateAndSaveData() throws Exception {
        // Get the latest record's last update date from our OracleDB repository
        Optional<MasterWorkRequest> latestRecordOpt = masterWorkRequestRepository.findTopByOrderByLastUpdateDateDesc();
        LocalDateTime lastUpdateDateTime = latestRecordOpt.map(MasterWorkRequest::getLastUpdateDate).orElse(null);

        // Convert LocalDateTime to Timestamp to avoid precision issues
        Timestamp lastUpdateTimestamp = (lastUpdateDateTime != null) ? Timestamp.valueOf(lastUpdateDateTime) : null;

        // Query the external APPS.WIP_EAM_WORK_REQUESTS_V table for records updated after or at our latest update date
        String sql = "SELECT * FROM APPS.WIP_EAM_WORK_REQUESTS_V WHERE LAST_UPDATE_DATE >= ?";

        List<MasterWorkRequest> newRecords;

        if (lastUpdateTimestamp != null) {
            newRecords = jdbcTemplate.query(
                    sql,
                    new Object[]{lastUpdateTimestamp},
                    BeanPropertyRowMapper.newInstance(MasterWorkRequest.class)
            );
        } else {
            // If there's no last update timestamp, fetch all records
            newRecords = jdbcTemplate.query(
                    "SELECT * FROM APPS.WIP_EAM_WORK_REQUESTS_V",
                    BeanPropertyRowMapper.newInstance(MasterWorkRequest.class)
            );
        }

        // Save the fetched records to both local OracleDB and SAM DB
        if (newRecords.isEmpty()) {
            System.out.println("********************No new Work Requests found.");
        } else {
            System.out.println("********************New Work Requests found: " + newRecords.size());

            for (MasterWorkRequest masterWorkRequest : newRecords) {
                // Save to local OracleDB
                boolean existsInMaster = masterWorkRequestRepository.existsByWorkRequestNumber(masterWorkRequest.getWorkRequestNumber());
                if (!existsInMaster) {
                    masterWorkRequestRepository.save(masterWorkRequest);
                    System.out.println("Saved Work Request in Master DB: " + masterWorkRequest.getWorkRequestNumber());
                } else {
                    System.out.println("Skipped duplicate Work Request in Master DB: " + masterWorkRequest.getWorkRequestNumber());
                }

                EmployeeDetails employeeDetails = employeeDetailsRepository.findById(masterWorkRequest.getCreatedBy()).orElse(null);
                EmployeeDetails createdByName = employeeDetailsRepository.findById(masterWorkRequest.getWorkRequestCreatedBy()).orElse(null);

                WorkRequest workRequest;
                Asset assetNumber = assetRepository.findByAssetNumber(masterWorkRequest.getAssetNumber());

                String workRequestNumber = masterWorkRequest.getWorkRequestNumber();

                Optional<WorkRequest> optionalWorkRequest = workRequestRepository.findByWorkRequestNumber(workRequestNumber);

                System.out.println("NVVV"+ masterWorkRequest.getDescription());
                if (optionalWorkRequest.isPresent()) {
                    workRequest = optionalWorkRequest.get();
                    workRequest.setRowId(masterWorkRequest.getRowId());
                    workRequest.setWorkRequestId(masterWorkRequest.getWorkRequestId());
                    workRequest.setWorkRequestNumber(masterWorkRequest.getWorkRequestNumber());
                    workRequest.setDescription(masterWorkRequest.getDescription());
                    workRequest.setLastUpdateDate(masterWorkRequest.getLastUpdateDate());
                    workRequest.setLastUpdatedBy(masterWorkRequest.getLastUpdatedBy());
                    workRequest.setCreationDate(masterWorkRequest.getCreationDate()); // You may still want to store CreationDate if needed
                    workRequest.setCreatedBy(masterWorkRequest.getCreatedBy());
                    if (employeeDetails != null) {
                        workRequest.setCreatedByName(employeeDetails.getFullName()); // Assuming you want to use the employee's full name
                    } else {
                        workRequest.setCreatedByName(""); // Fallback value if employee details are not found
                    }

                    if (createdByName != null) {
                        workRequest.setWorkRequestCreatedByName(createdByName.getFullName()); // Assuming you want to use the employee's full name
                    } else {
                        workRequest.setWorkRequestCreatedByName(""); // Fallback value if employee details are not found
                    }

                    if (assetNumber != null && assetNumber.getAssetNumber().equals(masterWorkRequest.getAssetNumber())) {
                        workRequest.setAssetId(assetNumber.getAssetId()); // Set assetGroup from Asset to WorkRequest
                        workRequest.setAssetGroupId(assetNumber.getAssetGroupId()); // Set assetGroup from Asset to WorkRequest
                        workRequest.setAssetGroup(assetNumber.getAssetGroup()); // Set assetGroup from Asset to WorkRequest
                    }

                    workRequest.setLastUpdateLogin(masterWorkRequest.getLastUpdateLogin());
                    workRequest.setAssetNumber(masterWorkRequest.getAssetNumber());
                    workRequest.setOrganizationId(masterWorkRequest.getOrganizationId());
                    workRequest.setWorkRequestStatusId(masterWorkRequest.getWorkRequestStatusId());
                    workRequest.setWorkRequestStatus(masterWorkRequest.getWorkRequestStatus());
                    workRequest.setWorkRequestPriorityId(masterWorkRequest.getWorkRequestPriorityId());
                    workRequest.setWorkRequestPriority(masterWorkRequest.getWorkRequestPriority());
                    workRequest.setWorkRequestOwningDeptId(masterWorkRequest.getWorkRequestOwningDeptId());
                    workRequest.setWorkRequestOwningDept(masterWorkRequest.getWorkRequestOwningDept());
                    workRequest.setExpectedResolutionDate(masterWorkRequest.getExpectedResolutionDate());
                    workRequest.setWipEntityId(masterWorkRequest.getWipEntityId());
                    workRequest.setWipEntityName(masterWorkRequest.getWipEntityName());
                    workRequest.setAttributeCategory(masterWorkRequest.getAttributeCategory());
                    workRequest.setAttribute1(masterWorkRequest.getAttribute1());
                    workRequest.setAttribute2(masterWorkRequest.getAttribute2());
                    workRequest.setAttribute3(masterWorkRequest.getAttribute3());
                    workRequest.setAttribute4(masterWorkRequest.getAttribute4());
                    workRequest.setAttribute5(masterWorkRequest.getAttribute5());
                    workRequest.setAttribute6(masterWorkRequest.getAttribute6());
                    workRequest.setAttribute7(masterWorkRequest.getAttribute7());
                    workRequest.setAttribute8(masterWorkRequest.getAttribute8());
                    workRequest.setAttribute9(masterWorkRequest.getAttribute9());
                    workRequest.setAttribute10(masterWorkRequest.getAttribute10());
                    workRequest.setAttribute11(masterWorkRequest.getAttribute11());
                    workRequest.setAttribute12(masterWorkRequest.getAttribute12());
                    workRequest.setAttribute13(masterWorkRequest.getAttribute13());
                    workRequest.setAttribute14(masterWorkRequest.getAttribute14());
                    workRequest.setAttribute15(masterWorkRequest.getAttribute15());
                    workRequest.setWorkRequestAutoApprove(masterWorkRequest.getWorkRequestAutoApprove());
                    workRequest.setWorkRequestTypeId(masterWorkRequest.getWorkRequestTypeId());
                    workRequest.setWorkRequestType(masterWorkRequest.getWorkRequestType());
                    workRequest.setWorkRequestCreatedBy(masterWorkRequest.getWorkRequestCreatedBy());
                    workRequest.setAssetNumberDescription(masterWorkRequest.getAssetNumberDescription());
                    workRequest.setAssetLocationId(masterWorkRequest.getAssetLocationId());
                    workRequest.setAssetLocation(masterWorkRequest.getAssetLocation());
                    workRequest.setAssetCategoryId(masterWorkRequest.getAssetCategoryId());
                    workRequest.setExpectedStartDate(masterWorkRequest.getExpectedStartDate());
                    workRequest.setAssetCriticality(masterWorkRequest.getAssetCriticality());

                    // Save the new record in SAM database
                    workRequestRepository.save(workRequest);
                    System.out.println("Skipped duplicate Work Request in SAM DB: " + masterWorkRequest.getWorkRequestNumber());
                }
            }
        }
    }


}
