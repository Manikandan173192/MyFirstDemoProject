package com.maxbyte.sam.SecondaryDBFlow.WorkRequest.Controller;

import com.maxbyte.sam.SecondaryDBFlow.Configuration.Controller.CrudController;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Interface.ServiceInterface;
import com.maxbyte.sam.SecondaryDBFlow.Response.ResponseModel;
import com.maxbyte.sam.SecondaryDBFlow.WorkRequest.APIRequest.UpdateWorkRequest;
import com.maxbyte.sam.SecondaryDBFlow.WorkRequest.APIRequest.AddWorkRequest1;
import com.maxbyte.sam.SecondaryDBFlow.WorkRequest.Entity.WorkRequest;
import com.maxbyte.sam.SecondaryDBFlow.WorkRequest.Repository.WorkRequestRepository;
import com.maxbyte.sam.SecondaryDBFlow.WorkRequest.Service.WorkRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/workRequest")
public class WorkRequestController extends CrudController<WorkRequest,Integer> {

    @Autowired
    private WorkRequestService workRequestService;
    @Override
    public ServiceInterface service() {
        return workRequestService;
    }
   /* @Autowired
    private MasterWorkRequestService masterWorkRequestService;*/
    @Autowired
    private WorkRequestRepository workRequestRepository;
    @Autowired
    private RestTemplate restTemplate;
//    @Autowired
//    private WebClient webClient;

   /* @GetMapping("")
    public ResponseModel<List<WorkRequest>> list(@RequestParam(required = false)Integer WRNumber,
                          @RequestParam(required = false)  String assetNumber,
                          @RequestParam(required = false) String department,
                          @RequestParam(required = false) String organizationId,
                                                 @RequestParam(required = false, defaultValue = "0") String requestPage){
        //String sql = "select * from APPS.WIP_EAM_WORK_REQUESTS_v where CREATION_DATE between [[IP_StartDate]] and [[IP_EndDate]] AND ORGANIZATION_ID = [[IP_OrganisationCode]] ORDER BY CREATION_DATE DESC";
        return this.workRequestService.list(WRNumber, assetNumber,
                department,requestPage, organizationId);
    }*/


     @GetMapping("")
    public ResponseModel<List<WorkRequest>> list(@RequestParam(required = false)String WRNumber,
                          @RequestParam(required = false)  String assetNumber,
                          @RequestParam(required = false) String department,
                          @RequestParam(required = false) String organizationId,
                          @RequestParam(required = false)  String workRequestStatus,
                                                 @RequestParam(required = false, defaultValue = "0") String requestPage){
        return this.workRequestService.list(WRNumber, assetNumber, department, organizationId,workRequestStatus,requestPage);
    }

    @GetMapping("/findByDateTime")
    public ResponseModel<List<WorkRequest>> findWorkRequestBetweenDateTime(@RequestParam(required = false) LocalDateTime from,
                                                                           @RequestParam(required = false) LocalDateTime to,
                                                                           @RequestParam(required = false, defaultValue = "0") String requestPage,
                                                                           @RequestParam(required = false) String organizationId) {
        return this.workRequestService.findWorkRequestByDateTime(organizationId,from, to, requestPage);
    }

    @PostMapping("/addWorkRequest")
    public ResponseEntity<ResponseModel<String>> addWorkRequest(@RequestBody AddWorkRequest1 data) {
        return workRequestService.addWorkRequest(data);
    }

    @PutMapping("/updateWorkRequest")
    public ResponseEntity<ResponseModel<String>> updateWorkRequest(@RequestBody UpdateWorkRequest data) {
        return workRequestService.updateWorkRequest(data);
    }


   /* @PostMapping("/addWorkRequest")
    public ResponseEntity<ResponseModel<WorkRequest>> addWorkRequest(@Valid @RequestBody AddWorkRequest1 data) {
        return workRequestService.addWorkRequest(data);
    }*/


   /* @PostMapping("/updateWorkRequest/{wrNumber}")
    public ResponseEntity<ResponseModel<WorkRequest>> updateWorkRequestData(@PathVariable String wrNumber, @RequestBody AddWorkRequest1 data){
        return workRequestService.updateWorkRequest(wrNumber,data);
    }*/




 /* @PostMapping("/addWorkRequest")
    public ResponseEntity<ResponseModel<WorkRequest>> addWorkRequest(@Valid @RequestBody AddWorkRequest data) {
        try {
            String url = "http://192.168.5.131:8000/api/oracleWorkFlow/addMasterWorkRequests";

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
//            headers.set("Authorization", "Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJNYW5pIiwiaWF0IjoxNzEwODQ4MjkwLCJleHAiOjE3MTA5MzQ2OTB9.iIUX2yhTHSPHo0O4Vm6GJbsbOn7jlOOxp2a3JCYqljw");
            headers.set("Authorization",AUTH_TOKEN );

            // Create an HttpEntity with the request data and headers
            HttpEntity<AddWorkRequest> entity = new HttpEntity<>(data, headers);

            // Send the POST request to the remote API service
            ResponseEntity<String> responseEntity = restTemplate.postForEntity(url, entity, String.class);

            // Check if the response from the remote service is successful
            if (responseEntity.getStatusCode() == HttpStatus.OK) {
                String response = responseEntity.getBody();

                if (!response.isEmpty()) {
                    ObjectMapper objectMapper = new ObjectMapper();

                    // Deserialize the JSON response to MasterWorkRequest object
                    WorkRequestResponse masterWorkRequest = objectMapper.readValue(response, WorkRequestResponse.class);

                    // Check if the request was successful
                    if (masterWorkRequest != null) {
                        // Create a new WorkRequest object and populate it with data from the response
                        WorkRequest newWorkRequest = new WorkRequest();
                        newWorkRequest.setWRNumber(masterWorkRequest.getData().getWRNumber());
                        newWorkRequest.setWRStatus(masterWorkRequest.getData().getWRStatus());
                        newWorkRequest.setRequested(masterWorkRequest.getData().getRequested());
                        newWorkRequest.setAdditionalDescription(masterWorkRequest.getData().getAdditionalDescription());
                        newWorkRequest.setCreatedBy(masterWorkRequest.getData().getCreatedBy());
                        newWorkRequest.setCreatedById(masterWorkRequest.getData().getCreatedById());
                        newWorkRequest.setPhoneNumber(masterWorkRequest.getData().getPhoneNumber());
                        newWorkRequest.setPriority(masterWorkRequest.getData().getPriority());
                        newWorkRequest.setEmail(masterWorkRequest.getData().getEmail());
                        newWorkRequest.setStartDate(masterWorkRequest.getData().getStartDate());
                        newWorkRequest.setEndDate(masterWorkRequest.getData().getEndDate());
                        newWorkRequest.setWorkRequestType(masterWorkRequest.getData().getWorkRequestType());
                        newWorkRequest.setAssetNumber(masterWorkRequest.getData().getAssetNumber());
                        newWorkRequest.setAssetId(masterWorkRequest.getData().getAssetId());
                        newWorkRequest.setAssetDescription(masterWorkRequest.getData().getAssetDescription());
                        newWorkRequest.setDepartment(masterWorkRequest.getData().getDepartment());
                        newWorkRequest.setDepartmentId(masterWorkRequest.getData().getDepartmentId());
                        newWorkRequest.setOrganizationId(masterWorkRequest.getData().getOrganizationId());
                        newWorkRequest.setOrganizationCode(masterWorkRequest.getData().getOrganizationCode());
                        newWorkRequest.setActive(masterWorkRequest.getData().isActive());
                        newWorkRequest.setCreatedOn(new Date());

                        // Save the newWorkRequest to the local database
                        workRequestRepository.save(newWorkRequest);

                        // Return success response with the newly added WorkRequest
                        return ResponseEntity.ok(new ResponseModel<>(true, "Added Successfully", newWorkRequest));
                    } else {
                        // Handle case where response data is null
                        return ResponseEntity.ok(new ResponseModel<>(false, "Failed to add work request to Oracle", null));
                    }
                } else {
                    // Return unauthorized response if the response is empty
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                            .body(new ResponseModel<>(false, "Login failed: Empty response from the server.", null));
                }
            } else {
                // Handle non-OK status code from Oracle service
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(new ResponseModel<>(false, "Failed to connect to the server.", null));
            }
        } catch (HttpStatusCodeException ex) {
            // Handle HTTP status code exceptions
            return ResponseEntity.status(ex.getStatusCode())
                    .body(new ResponseModel<>(false, "HTTP Error: " + ex.getStatusCode().toString(), null));
        } catch (JsonProcessingException e) {
            // Handle JSON processing exceptions
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseModel<>(false, "Error processing the response.", null));
        } catch (Exception e) {
            // Handle other unexpected exceptions
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseModel<>(false, "Unexpected error occurred.", null));
        }
    }





  @PostMapping("/updateWorkRequest/{wrNumber}")
    public ResponseEntity<ResponseModel<WorkRequest>> updateWorkRequest(@PathVariable Integer wrNumber, @Valid @RequestBody AddWorkRequest data) {
        try {
            String url = "http://192.168.5.131:8000/api/oracleWorkFlow/updateMasterWorkRequest/" + wrNumber;

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", AUTH_TOKEN);

            // Create an HttpEntity with the request data and headers
            HttpEntity<AddWorkRequest> entity = new HttpEntity<>(data, headers);

            // Send the POST request to the remote API service
            var responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity, WorkRequestResponse.class);

            // Check if the response from the remote service is successful
            if (responseEntity.getStatusCode() == HttpStatus.OK) {
                WorkRequestResponse masterWorkRequest = responseEntity.getBody();

                // Check if the request was successful and data is not null
                if (masterWorkRequest != null && masterWorkRequest.getData() != null) {
                    // Fetch existing WorkRequest from the repository
                    WorkRequest updatedWorkRequest = workRequestRepository.findByWRNumber(wrNumber);
                    if (updatedWorkRequest != null) {
                        // Update the fetched WorkRequest with data from the response
                        WorkRequestResponse.WorkRequestData responseData = masterWorkRequest.getData();
                        updatedWorkRequest.setWRStatus(responseData.getWRStatus());
                        updatedWorkRequest.setRequested(responseData.getRequested());
                        updatedWorkRequest.setAdditionalDescription(responseData.getAdditionalDescription());
                        updatedWorkRequest.setCreatedBy(responseData.getCreatedBy());
                        updatedWorkRequest.setCreatedById(responseData.getCreatedById());
                        updatedWorkRequest.setPhoneNumber(responseData.getPhoneNumber());
                        updatedWorkRequest.setPriority(responseData.getPriority());
                        updatedWorkRequest.setEmail(responseData.getEmail());
                        updatedWorkRequest.setStartDate(responseData.getStartDate());
                        updatedWorkRequest.setEndDate(responseData.getEndDate());
                        updatedWorkRequest.setWorkRequestType(responseData.getWorkRequestType());
                        updatedWorkRequest.setAssetNumber(responseData.getAssetNumber());
                        updatedWorkRequest.setAssetId(responseData.getAssetId());
                        updatedWorkRequest.setAssetDescription(responseData.getAssetDescription());
                        updatedWorkRequest.setDepartment(responseData.getDepartment());
                        updatedWorkRequest.setDepartmentId(responseData.getDepartmentId());
                        updatedWorkRequest.setOrganizationId(responseData.getOrganizationId());
                        updatedWorkRequest.setOrganizationCode(responseData.getOrganizationCode());
                        updatedWorkRequest.setActive(responseData.isActive());
                        updatedWorkRequest.setCreatedOn(new Date());

                        // Save the updatedWorkRequest to the local database
                        workRequestRepository.save(updatedWorkRequest);

                        // Return success response with the updated WorkRequest
                        return ResponseEntity.ok(new ResponseModel<>(true, "Updated Successfully", updatedWorkRequest));
                    } else {
                        // Handle case where existing WorkRequest is not found
                        return ResponseEntity.ok(new ResponseModel<>(false, "Work request not found", null));
                    }
                } else {
                    // Handle case where response data or masterWorkRequest is null
                    return ResponseEntity.ok(new ResponseModel<>(false, "Failed to update work request in Oracle", null));
                }
            } else {
                // Handle non-OK status code from Oracle service
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(new ResponseModel<>(false, "Failed to connect to the server.", null));
            }
        } catch (HttpStatusCodeException ex) {
            // Handle HTTP status code exceptions
            return ResponseEntity.status(ex.getStatusCode())
                    .body(new ResponseModel<>(false, "HTTP Error: " + ex.getStatusCode().toString(), null));
        } catch (Exception e) {
            // Handle other unexpected exceptions
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseModel<>(false, "Unexpected error occurred.", null));
        }
    }*/



 /*   @PostMapping("/addWorkRequest")
    public ResponseEntity<ResponseModel<WorkRequest>> addWorkRequest(@Valid @RequestBody AddWorkRequest1 data) {
//        String url = "http://10.36.113.75:9054/soa-infra/resources/PM/XXHIL_EAM_MAXBYTE_WR_CREATE_UPD/WORK_REQUEST_CREATE_SERVICE/WORK_REQUEST_CREATE_RP";
        String url = "http://ekaayansoa.adityabirla.com/soa-infra/resources/PM/XXHIL_EAM_MAXBYTE_WR_CREATE_UPD/WORK_REQUEST_CREATE_SERVICE/WORK_REQUEST_CREATE_RP";

        WebClient.RequestHeadersSpec<?> requestHeadersSpec = webClient.post()
                .uri(url)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .headers(headers -> {
                    String authHeader = "Basic " + Base64.getEncoder().encodeToString((data.getUsername() + ":" + data.getPassword()).getBytes(StandardCharsets.UTF_8));
                    headers.set(HttpHeaders.AUTHORIZATION, authHeader);
                });

        WebClient.ResponseSpec responseSpec = requestHeadersSpec.retrieve();
        System.out.println("responseSpec:"+responseSpec);
        ResponseEntity<String> responseEntity = responseSpec.toEntity(String.class).block();
        System.out.println("responseEntity:"+responseEntity);

        if (responseEntity != null && responseEntity.getStatusCode() == HttpStatus.OK) {
            String response = responseEntity.getBody();

            if (response != null && !response.isEmpty()) {
                ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

                try {
                    WorkRequest masterWorkRequest = objectMapper.readValue(response, WorkRequest.class);
                    if (masterWorkRequest != null) {
                        WorkRequest newWorkRequest = new WorkRequest();
                        newWorkRequest.setWRNumber(masterWorkRequest.getP_WORK_REQUEST_NUMBER().getWorkRequestNumber());

                        newWorkRequest.setASSET_GROUP_ID(data.getASSET_GROUP_ID());
                        newWorkRequest.setASSET_NUMBER(data.getASSET_NUMBER());
                        newWorkRequest.setCREATED_FOR(data.getCREATED_FOR());
                        newWorkRequest.setORGANIZATION_ID(data.getORGANIZATION_ID());
                        newWorkRequest.setWORK_REQUEST_PRIORITY_ID(data.getWORK_REQUEST_PRIORITY_ID());
                        newWorkRequest.setOWNING_DEPARTMENT_ID(data.getOWNING_DEPARTMENT_ID());
                        newWorkRequest.setEXPECTED_START_DATE(data.getEXPECTED_START_DATE());
                        newWorkRequest.setEXPECTED_RESOLUTION_DATE(data.getEXPECTED_RESOLUTION_DATE());
                        newWorkRequest.setDESCRIPTION(data.getDESCRIPTION());
                        newWorkRequest.setWORK_REQUEST_TYPE_ID(data.getWORK_REQUEST_TYPE_ID());
                        newWorkRequest.setUSER_ID(data.getUSER_ID());
                        newWorkRequest.setPHONE_NUMBER(data.getPHONE_NUMBER());
                        newWorkRequest.setE_MAIL(data.getE_MAIL());
                        newWorkRequest.setWORK_CREATEDBY(data.getWORK_CREATEDBY());
                        newWorkRequest.setWORK_ATTACHMENT(data.getWORK_ATTACHMENT());

                        newWorkRequest.setCreatedOn(LocalDateTime.now());
                        workRequestRepository.save(newWorkRequest);
                        return ResponseEntity.ok(new ResponseModel<>(true, "Work request added successfully", newWorkRequest));
                    } else {
                        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                .body(new ResponseModel<>(false, "Failed to process the response.", null));
                    }
                } catch (JsonProcessingException e) {
                    e.printStackTrace();
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                            .body(new ResponseModel<>(false, "Error processing the response.", null));
                }
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(new ResponseModel<>(false, "Empty response from the server.", null));
            }
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseModel<>(false, "Failed to connect to the server.", null));
        }
    }
*/






}
