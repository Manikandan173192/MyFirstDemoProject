package com.maxbyte.sam.SecondaryDBFlow.Configuration.Service;

import com.maxbyte.sam.SecondaryDBFlow.AIM.Entity.Aim;
import com.maxbyte.sam.SecondaryDBFlow.AIM.Repository.AimRepository;
import com.maxbyte.sam.SecondaryDBFlow.CAPA.Entity.CAPA;
import com.maxbyte.sam.SecondaryDBFlow.CAPA.Repository.CAPARepository;
import com.maxbyte.sam.SecondaryDBFlow.CWF.Entity.CWF;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.Dashboard;
import com.maxbyte.sam.SecondaryDBFlow.CWF.Repository.CWFRepository;
import com.maxbyte.sam.SecondaryDBFlow.FMEA.Entity.FMEA;
import com.maxbyte.sam.SecondaryDBFlow.FMEA.Repository.FMEARepository;
import com.maxbyte.sam.SecondaryDBFlow.IB.Entity.IB;
import com.maxbyte.sam.SecondaryDBFlow.IB.Repository.IBEntityRepository;
import com.maxbyte.sam.SecondaryDBFlow.MOC.Entity.MOC;
import com.maxbyte.sam.SecondaryDBFlow.MOC.Repository.MOCRepository;
import com.maxbyte.sam.SecondaryDBFlow.RCA.Entity.RCA;
import com.maxbyte.sam.SecondaryDBFlow.RCA.Repository.RCARepository;
import com.maxbyte.sam.SecondaryDBFlow.Response.ResponseModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DashboardService {

    @Autowired
    private CWFRepository cwfRepository;
    @Autowired
    private RCARepository rcaRepository;
    @Autowired
    private AimRepository aimRepository;
    @Autowired
    private CAPARepository capaRepository;//4
    @Autowired
    private IBEntityRepository ibEntityRepository;//3
    @Autowired
    private MOCRepository mocRepository;//8 or 9
    @Autowired
    private FMEARepository fmeaRepository;



    public ResponseModel<List<Object>> getListCounts() {
        List<Object> countsList = new ArrayList<>();

//        List<CWF> cwfList = cwfRepository.findAll();
//        int cwfTotalCount = cwfList.size();
//        int cwfPendingCount = 0;
//        for (CWF cwf : cwfList) {
//            if (cwf.getStatus() == 2) {
//                cwfPendingCount++;
//            }
//        }
//        countsList.add(new Dashboard("CWF", cwfTotalCount, cwfPendingCount));
//
//        List<RCA> rcaList = rcaRepository.findAll();
//        int rcaTotalCount = rcaList.size();
//        int rcaPendingCount = 0;
//        for (RCA rca : rcaList) {
//            if (rca.getStatus() == 9) {
//                rcaPendingCount++;
//            }
//        }
//        countsList.add(new Dashboard("RCA", rcaTotalCount, rcaPendingCount));
//
//        List<Aim> aimList = aimRepository.findAll();
//        int aimTotalCount = aimList.size();
//        int aimPendingCount = 0;
//       /* for (Aim aim : aimList) {
//            if (aim.getStatus() == 9) {
//                aimPendingCount++;
//            }
//        }*/
//        countsList.add(new Dashboard("AIM", aimTotalCount, aimPendingCount));
//
//
//        List<CAPA> capaList = capaRepository.findAll();
//        int capaTotalCount = capaList.size();
//        int capaPendingCount = 0;
//        for (CAPA capa : capaList) {
//            if (capa.getStatus() == 4) {
//                capaPendingCount++;
//            }
//        }
//        countsList.add(new Dashboard("CAPA", capaTotalCount, capaPendingCount));
//
//
//        List<IB> ibList = ibEntityRepository.findAll();
//        int ibTotalCount = ibList.size();
//        int ibPendingCount = 0;
//        for (IB ib : ibList) {
//            if (ib.getStatus() == 3) {
//                ibPendingCount++;
//            }
//        }
//        countsList.add(new Dashboard("IB", ibTotalCount, ibPendingCount));
//
//        List<MOC> mocList = mocRepository.findAll();
//        int mocTotalCount = mocList.size();
//        int mocPendingCount = 0;
//        for (MOC moc : mocList) {
//            if (moc.getStatus() == 8 || moc.getStatus() == 9) {
//                mocPendingCount++;
//            }
//        }
//        countsList.add(new Dashboard("MOC", mocTotalCount, mocPendingCount));
//
//        List<FMEA> fmeaList = fmeaRepository.findAll();
//        int fmeaTotalCount = fmeaList.size();
//        int fmeaPendingCount = 0;
//        for (FMEA fmea : fmeaList) {
//            if (fmea.getStatus() == 2) {
//                fmeaPendingCount++;
//            }
//        }
//        countsList.add(new Dashboard("FMEA", fmeaTotalCount, fmeaPendingCount));


        //RCA Status
        List<RCA> rcaList = rcaRepository.findAll();
        List<RCA> openRCAs=rcaRepository.findOpenRCAs();
        List<RCA> inProgressRCAs = rcaRepository.findInProgressRCAs();
        List<RCA> completeRCAs = rcaRepository.findCompleteRCAs();
        List<RCA> pendingRCAs = rcaRepository.findPendingRCAs();
        List<RCA> revertBackRCAs = rcaRepository.findRevertBackRCAs();
        List<RCA> closedRCAs = rcaRepository.findClosedRCAs();

        int rcaTotalCount = rcaList.size();
        int openCount = openRCAs.size();
        int inProgressCount = inProgressRCAs.size();
        int completedCount = completeRCAs.size();
        int pendingCount = pendingRCAs.size();
        int revertBackCount = revertBackRCAs.size();
        int closedCount = closedRCAs.size();
        countsList.add(new Dashboard("RCA", rcaTotalCount, openCount,inProgressCount,completedCount,pendingCount,revertBackCount,closedCount));

        //CWF Module
        List<CWF> cwfList = cwfRepository.findAll();
        List<CWF> openCWF= cwfRepository.findOpenCWF();
        List<CWF> completeCWF = cwfRepository.findCompleteCWF();
        List<CWF> pendingCWF = cwfRepository.findPendingCWF();
        List<CWF> revertBackCWF = cwfRepository.findRevertBackCWF();
        List<CWF> closedCWF = cwfRepository.findClosedCWF();

        int cwfTotalCount = cwfList.size();
        int cwfOpenCount = openCWF.size();
        int cwfCompletedCount = completeCWF.size();
        int cwfPendingCount = pendingCWF.size();
        int cwfRevertBackCount = revertBackCWF.size();
        int cwfClosedCount = closedCWF.size();
        countsList.add(new Dashboard("CWF", cwfTotalCount, cwfOpenCount,null,cwfCompletedCount,cwfPendingCount,cwfRevertBackCount,cwfClosedCount));

        //AIM Module
        List<Aim> aimList = aimRepository.findAll();
        List<Aim> openAIM= aimRepository.findOpenAim();
        List<Aim> revertBackAIM = aimRepository.findRevertBackAim();
        List<Aim> closedAIM = aimRepository.findClosedAim();

        int aimTotalCount = aimList.size();
        int aimOpenCount = openAIM.size();
        int aimRevertBackCount = revertBackAIM.size();
        int aimClosedCount = closedAIM.size();
        countsList.add(new Dashboard("AIM", aimTotalCount, aimOpenCount,null,null,null,aimRevertBackCount,aimClosedCount));

        //IB Module
        List<IB> ibList = ibEntityRepository.findAll();
        List<IB> openIB = ibEntityRepository.findOpenIB();
        List<IB> inProgressIB = ibEntityRepository.findInProgressIB();
        List<IB> completeIB = ibEntityRepository.findCompleteIB();
        List<IB> pendingIB = ibEntityRepository.findPendingIB();
        List<IB> revertBackIB = ibEntityRepository.findRevertBackIB();
        List<IB> closedIB = ibEntityRepository.findClosedIB();

        int ibTotalCount = ibList.size();
        int openCountIB = openIB.size();
        int inProgressCountIB = inProgressIB.size();
        int completedCountIB = completeIB.size();
        int pendingCountIB = pendingIB.size();
        int revertBackCountIB = revertBackIB.size();
        int closedCountIB = closedIB.size();
        countsList.add(new Dashboard("IB", ibTotalCount, openCountIB,inProgressCountIB,completedCountIB,pendingCountIB,revertBackCountIB,closedCountIB));


        //FMEA Status

        List<FMEA> FMEAList = fmeaRepository.findAll();
        List<FMEA> openFMEAs = fmeaRepository.findOpenFMEAs();
        List<FMEA> inProgressFMEAs = fmeaRepository.findInProgressFMEAs();
        List<FMEA> completeFMEAs = fmeaRepository.findCompleteFMEAs();
        List<FMEA> revertBackFMEAs = fmeaRepository.findRevertBackFMEAs();
        List<FMEA> closedFMEAs = fmeaRepository.findClosedFMEAs();

        int fmeaTotalCount = FMEAList.size();
        int fmeaOpenCount = openFMEAs.size();
        int fmeaInProgressCount = inProgressFMEAs.size();
        int fmeaCompletedCount = completeFMEAs.size();
        int fmeaRevertBackCount = revertBackFMEAs.size();
        int fmeaClosedCount = closedFMEAs.size();
        countsList.add(new Dashboard("FMEA", fmeaTotalCount, fmeaOpenCount, fmeaInProgressCount, fmeaCompletedCount, null, fmeaRevertBackCount, fmeaClosedCount));

        // CAPA Status

        List<CAPA> capaList = capaRepository.findAll();
        List<CAPA> openCAPAs=capaRepository.findOpenCAPAs();
        List<CAPA> inProgressCAPAs = capaRepository.findInProgressCAPAs();
        List<CAPA> completeCAPAs = capaRepository.findCompleteCAPAs();
        List<CAPA> pendingCAPAs = capaRepository.findPendingCAPAs();
        List<CAPA> revertBackCAPAs = capaRepository.findRevertBackCAPAs();
        List<CAPA> closedCAPAs = capaRepository.findClosedCAPAs();

        int capaTotalCount = capaList.size();
        int capaOpenCount = openCAPAs.size();
        int capaInProgressCount = inProgressCAPAs.size();
        int capaCompletedCount = completeCAPAs.size();
        int capaPendingCount = pendingCAPAs.size();
        int capaRevertBackCount = revertBackCAPAs.size();
        int capaClosedCount = closedCAPAs.size();
        countsList.add(new Dashboard("CAPA", capaTotalCount, capaOpenCount,capaInProgressCount,capaCompletedCount,capaPendingCount,capaRevertBackCount,capaClosedCount));

        // MOC Status

        List<MOC> MOCList = mocRepository.findAll();
        List<MOC> openMOCs=mocRepository.findOpenMOCs();
        List<MOC> inProgressMOCs = mocRepository.findInProgressMOCs();
        List<MOC> completeMOCs = mocRepository.findCompleteMOCs();
        List<MOC> revertBackMOCs = mocRepository.findRevertBackMOCs();
        List<MOC> closedMOCs = mocRepository.findClosedMOCs();

        int mocTotalCount = MOCList.size();
        int mocOpenCount = openMOCs.size();
        int mocInProgressCount = inProgressMOCs.size();
        int mocCompletedCount = completeMOCs.size();
        int mocRevertBackCount = revertBackMOCs.size();
        int mocClosedCount = closedMOCs.size();
        countsList.add(new Dashboard("MOC", mocTotalCount, mocOpenCount,mocInProgressCount,mocCompletedCount,null,mocRevertBackCount,mocClosedCount));



        return new ResponseModel<>(true, "Success", countsList);
    }


}
