package com.maxbyte.sam.SecondaryDBFlow.Configuration.Service;

import com.maxbyte.sam.SecondaryDBFlow.Authentication.Entity.UserInfo;
import com.maxbyte.sam.SecondaryDBFlow.Authentication.Entity.UserType;
import com.maxbyte.sam.SecondaryDBFlow.Authentication.Repository.UserInfoRepository;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.Asset;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.AssetGroup;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.Role;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Specification.AssetSpecificationBuilder;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Specification.RoleSpecificationBuilder;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Specification.UserInfoSpecificationBuilder;
import com.maxbyte.sam.SecondaryDBFlow.Response.ResponseModel;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserDetailsService extends CrudService<UserInfo,Integer> {

    @Autowired
    private UserInfoRepository userDetailRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public CrudRepository repository() {
        return this.userDetailRepository;
    }

    @Override
    public void validateAdd(UserInfo data) {
        try{
        }
        catch(Error e){
            throw new Error(e);
        }

    }

    @Override
    public void validateEdit(UserInfo data) {
        try{
        }
        catch(Error e){
            throw new Error(e);
        }
    }

    @Override
    public void validateDelete(Integer id) {
        try{

        }
        catch(Error e){
            throw new Error(e);
        }
    }

    public ResponseModel<List<UserInfo>> list(Boolean isActive, String role,String organizationCode, String department, UserType userType) {
        try {
            UserInfoSpecificationBuilder builder = new UserInfoSpecificationBuilder();
            if(isActive!=null)builder.with("isActive","==",isActive);
            if(role!=null)builder.with("role","==",role);
            if(department!=null)builder.with("department",":",department);
            if(organizationCode!=null)builder.with("organizationCode","==",organizationCode);
            if(userType!=null)builder.with("userType",":",userType);
            List<UserInfo> results = userDetailRepository.findAll(builder.build());
            return new ResponseModel<>(true, "Records Found",results.reversed());

        }catch (Exception e){
            return new ResponseModel<>(false, "Records not found",null);
        }
    }

    public ResponseModel<String> resetPassword(String newPassword,String confirmedPassword, String userEmail) {
        try {

            if (!newPassword.equals(confirmedPassword)) {
                return new ResponseModel<>(false, "New password and confirmed password do not match.", null);
            }


            Optional<UserInfo> userData = userDetailRepository.findByUserEmail(userEmail);

            if (userData.isPresent()) {
                UserInfo user = userData.get();
                String encodedPassword = passwordEncoder.encode(newPassword);
                user.setUserPassword(encodedPassword);
                userDetailRepository.save(user);

                return new ResponseModel<>(true, "Password reset successful.", null);
            } else {
                return new ResponseModel<>(false, "Invalid or expired reset token.", null);
            }
        } catch (Exception e) {
            return new ResponseModel<>(false, "Failed to reset password.", null);
        }
    }

    /*public ResponseModel<List<UserInfo>> list(Boolean isActive) {
        try {
            UserInfoSpecificationBuilder builder = new UserInfoSpecificationBuilder();
            if(isActive!=null)builder.with("isActive",":",isActive);

            List<UserInfo> results = userDetailRepository.findAll(builder.build());
            return new ResponseModel<>(true, "Records Found",results);

        }catch (Exception e){
            return new ResponseModel<>(false, "Records not found",null);
        }
    }*/
    public ResponseModel<UserInfo> addUser(UserInfo userInfo) {
        try {
            userInfo.setUserPassword(passwordEncoder.encode(userInfo.getUserPassword()));
            userDetailRepository.save(userInfo);
            return new ResponseModel<>(true, "User Added Successfully",userInfo);
        }catch (Exception e){
            return new ResponseModel<>(false, "Failed to add",null);
        }
    }
//    public ResponseModel<UserInfo> getUser() {
//        try {
//            userInfo.setUserPassword(passwordEncoder.encode(userInfo.getUserPassword()));
//            userDetailRepository.save(userInfo);
//            return new ResponseModel<>(true, "User Added Successfully",userInfo);
//        }catch (Exception e){
//            return new ResponseModel<>(false, "Failed to add",null);
//        }
//    }

//    public ResponseModel<List<UserInfo>> list(String organizationCode, Boolean isActive) {
//        try {
//            List<AssetGroup> results = assetGroupRepository.findByOrganizationCodeAndIsActive(organizationCode, isActive);
//            return new ResponseModel<>(true, "Records Found", results);
//        } catch (Exception e) {
//            return new ResponseModel<>(false, "Records not found", null);
//        }
//    }
//    public ResponseModel<List<UserInfo>>getUsersByFilters(String department, String organizationCode, UserType userType) {
//        try {
//            List<UserInfo> details = userDetailRepository.findByFilters(department, organizationCode, userType);
//            return new ResponseModel<>(true, "Records Found", details);
//        } catch (Exception e) {
//            return new ResponseModel<>(false, "Records not found", null);
//        }
//    }


    //********************************  New code for Listing *************************
    public ResponseModel<List<UserInfo>> listUserDetails(String department, String organizationCode, UserType userType, String userName) {
        try {
            Pageable pageable = PageRequest.of(0, 50);
            Page<UserInfo> pageResults = userDetailRepository.findByFilters(department, organizationCode, userType,userName,pageable);
            List<UserInfo> results = pageResults.getContent();
            return new ResponseModel<>(true, "Records Found", results.reversed());
        } catch (Exception e) {
            return new ResponseModel<>(false, "Records not found", null);
        }
    }
}

