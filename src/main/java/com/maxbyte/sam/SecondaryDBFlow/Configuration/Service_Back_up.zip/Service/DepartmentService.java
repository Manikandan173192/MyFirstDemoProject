package com.maxbyte.sam.SecondaryDBFlow.Configuration.Service;


import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.Asset;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.AssetGroup;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.Department;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.Organization;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Repository.DepartmentRepository;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Specification.AssetGroupSpecificationBuilder;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Specification.AssetSpecificationBuilder;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Specification.DepartmentSpecificationBuilder;
import com.maxbyte.sam.SecondaryDBFlow.Response.ResponseModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentService extends CrudService<Department,Integer> {

    @Autowired
    private DepartmentRepository departmentRepository;
    @Override
    public CrudRepository repository() {
        return this.departmentRepository;
    }

    @Override
    public void validateAdd(Department data) {
        try{
        }
        catch(Error e){
            throw new Error(e);
        }

    }

    @Override
    public void validateEdit(Department data) {
        try{
        }
        catch(Error e){
            throw new Error(e);
        }
    }

    @Override
    public void validateDelete(Integer id) {
        try{

        }
        catch(Error e){
            throw new Error(e);
        }
    }

    public ResponseModel<List<Department>> list( Boolean isActive) {

        try {
            DepartmentSpecificationBuilder builder = new DepartmentSpecificationBuilder();
            if(isActive!=null)builder.with("isActive","==",isActive);

            List<Department> results = departmentRepository.findAll(builder.build());

            return new ResponseModel<>(true, "Records Found",results.reversed());

        }catch (Exception e){
            return new ResponseModel<>(false, "Records not found",null);
        }
    }
}