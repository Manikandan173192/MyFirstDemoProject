package com.maxbyte.sam.SecondaryDBFlow.Configuration.Repository;


import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.Asset;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.AssetGroup;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AssetRepository extends JpaRepository<Asset, Integer> , JpaSpecificationExecutor<Asset>{

    //List<Asset> findByAssetGroupAndOrganizationCodeAndIsActive(String assetGroup, String organizationCode,boolean isActive);
    @Query("SELECT a FROM Asset a WHERE (:assetGroup IS NULL OR a.assetGroup LIKE %:assetGroup%) AND (:organizationCode IS NULL OR a.organizationCode = :organizationCode) AND (:isActive IS NULL OR a.isActive = :isActive)")
    Page<Asset> findByAssetGroupAndOrganizationCodeAndIsActive(@Param("assetGroup") String assetGroup, @Param("organizationCode") String organizationCode, @Param("isActive") Boolean isActive, Pageable pageable);

}
