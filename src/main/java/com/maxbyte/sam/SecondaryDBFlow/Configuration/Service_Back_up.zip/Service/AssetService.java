package com.maxbyte.sam.SecondaryDBFlow.Configuration.Service;


import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.Asset;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Repository.AssetRepository;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Specification.AssetSpecificationBuilder;
import com.maxbyte.sam.SecondaryDBFlow.RCA.Entity.RCAStepTwo;
import com.maxbyte.sam.SecondaryDBFlow.Response.ResponseModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class AssetService extends CrudService<Asset,Integer> {

    @Autowired
    private AssetRepository assetRepository;
    @Override
    public CrudRepository repository() {
        return this.assetRepository;
    }

    @Override
    public void validateAdd(Asset data) {
        try{
        }
        catch(Error e){
            throw new Error(e);
        }

    }

    @Override
    public void validateEdit(Asset data) {
        try{
        }
        catch(Error e){
            throw new Error(e);
        }
    }

    @Override
    public void validateDelete(Integer id) {
        try{

        }
        catch(Error e){
            throw new Error(e);
        }
    }

//    public ResponseModel<List<Asset>> list(String assetGroup, String organizationCode, Boolean isActive) {
//
//        try {
//            AssetSpecificationBuilder builder = new AssetSpecificationBuilder();
//            if(assetGroup!=null)builder.with("assetGroup",":",assetGroup);
//            if(organizationCode!=null)builder.with("organizationCode","==",organizationCode);
//            if(isActive!=null)builder.with("isActive","==",isActive);
//
//            List<Asset> results = assetRepository.findAll(builder.build());
//
//            return new ResponseModel<>(true, "Records Found",results.reversed());
//
//        }catch (Exception e){
//            return new ResponseModel<>(false, "Records not found",null);
//        }
//
//    }
    public ResponseModel<List<Asset>> list(String assetGroup, String organizationCode, Boolean isActive) {
        try {

            Pageable pageable = PageRequest.of(0, 2);
            Page<Asset> pageResults = assetRepository.findByAssetGroupAndOrganizationCodeAndIsActive(assetGroup, organizationCode, isActive, pageable);
            List<Asset> results = pageResults.getContent();
            return new ResponseModel<>(true, "Records Found",results.reversed());
        } catch (Exception e) {
            return new ResponseModel<>(false, "Records not found", null);
        }
    }
}