package com.maxbyte.sam.SecondaryDBFlow.Configuration.service;


import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.Department;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Repository.DepartmentRepository;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Specification.DepartmentSpecificationBuilder;
import com.maxbyte.sam.SecondaryDBFlow.Response.ResponseModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DepartmentService extends CrudService<Department,Integer> {

    @Autowired
    private DepartmentRepository departmentRepository;
    @Override
    public CrudRepository repository() {
        return this.departmentRepository;
    }

    @Override
    public void validateAdd(Department data) {
        try{
            Optional<Department> existingDepartment = departmentRepository.findByDepartment(data.getDepartment());
            if (existingDepartment.isPresent()) {
                throw new IllegalArgumentException("Department already exists: " + data.getDepartment());
            }
        }
        catch(Error e){
            throw new Error(e);
        }

    }

    @Override
    public void validateEdit(Department data) {
        try{
        }
        catch(Error e){
            throw new Error(e);
        }
    }

    @Override
    public void validateDelete(Integer id) {
        try{

        }
        catch(Error e){
            throw new Error(e);
        }
    }

    public ResponseModel<List<Department>> list( Boolean isActive) {

        try {
            DepartmentSpecificationBuilder builder = new DepartmentSpecificationBuilder();
            if(isActive!=null)builder.with("isActive",":",isActive);

            List<Department> results = departmentRepository.findAll(builder.build());

            return new ResponseModel<>(true, "Records Found",results);

        }catch (Exception e){
            return new ResponseModel<>(false, "Records not found",null);
        }
    }
}