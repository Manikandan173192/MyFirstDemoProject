package com.maxbyte.sam.SecondaryDBFlow.CWF.Specification;

import com.maxbyte.sam.SecondaryDBFlow.CWF.Entity.WorkFlow;
import com.maxbyte.sam.SecondaryDBFlow.Helper.GenericSpecificationBuilder;

public class WorkFlowSpecificationBuilder  extends GenericSpecificationBuilder<WorkFlow> {


}