package com.maxbyte.sam.SecondaryDBFlow.AIM.Specification;

import com.maxbyte.sam.SecondaryDBFlow.AIM.Entity.Aim;
import com.maxbyte.sam.SecondaryDBFlow.Helper.GenericSpecificationBuilder;

public class AIMSpecificationBuilder extends GenericSpecificationBuilder<Aim> {
}

