package com.maxbyte.sam.SecondaryDBFlow.RCA.APIRequest;

import lombok.Data;

@Data
public class AssetModel {
    private String assetNumber;
    private String assetDescription;
    private String assetGroup;
}
