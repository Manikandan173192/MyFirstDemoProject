package com.maxbyte.sam.SecondaryDBFlow.FMEA.Entity;

public enum TypeDS {
    FMEADS_PROCESS,
    FMEADS_FUNCTION,
    FMEADS_FAILURE_MODE,
    FMEA_EFFECT,
    FMEADS_CAUSE,
    FMEADS_ACTION,
    FMEADS_ACTION_TAKEN

}
