package com.maxbyte.sam.SecondaryDBFlow.CWF.Specification;

import com.maxbyte.sam.SecondaryDBFlow.CWF.Entity.CWF;
import com.maxbyte.sam.SecondaryDBFlow.Helper.GenericSpecificationBuilder;


public class CWFSpecificationBuilder extends GenericSpecificationBuilder<CWF> {


}

