package com.maxbyte.sam.SecondaryDBFlow.FMEA.Specification;

import com.maxbyte.sam.SecondaryDBFlow.FMEA.Entity.FMEA;
import com.maxbyte.sam.SecondaryDBFlow.Helper.GenericSpecificationBuilder;

public class FMEASpecificationBuilder extends GenericSpecificationBuilder<FMEA> {
}
