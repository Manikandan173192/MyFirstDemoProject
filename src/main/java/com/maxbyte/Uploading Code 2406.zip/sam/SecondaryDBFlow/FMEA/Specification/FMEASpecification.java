package com.maxbyte.sam.SecondaryDBFlow.FMEA.Specification;

import com.maxbyte.sam.SecondaryDBFlow.FMEA.Entity.FMEA;
import com.maxbyte.sam.SecondaryDBFlow.Helper.GenericSpecification;
import com.maxbyte.sam.SecondaryDBFlow.Helper.SearchCriteria;

public class FMEASpecification extends GenericSpecification<FMEA> {
    public FMEASpecification(SearchCriteria criteria) {
        super(criteria);
    }
}
