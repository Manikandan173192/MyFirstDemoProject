package com.maxbyte.sam.SecondaryDBFlow.Configuration.service;

import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.Organization;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Repository.OrganizationRepository;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Specification.OrganizationSpecificationBuilder;
import com.maxbyte.sam.SecondaryDBFlow.Response.ResponseModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrganizationService extends CrudService<Organization,Integer> {

    @Autowired
    private OrganizationRepository organizationRepository;
    @Override
    public CrudRepository repository() {
        return this.organizationRepository;
    }


    //bug fixed unique name
    @Override
    public void validateAdd(Organization data) {
        try{
            Optional<Organization> existingOrganization = organizationRepository.findByOrganizationCode(data.getOrganizationCode());
            if (existingOrganization.isPresent()) {
                throw new IllegalArgumentException("Organization code already exists: " + data.getOrganizationCode());
            }
        }
        catch(Error e){
            throw new Error(e);
        }

    }

    @Override
    public void validateEdit(Organization data) {
        try{
        }
        catch(Error e){
            throw new Error(e);
        }
    }

    @Override
    public void validateDelete(Integer id) {
        try{

        }
        catch(Error e){
            throw new Error(e);
        }
    }

    public ResponseModel<List<Organization>> list( Boolean isActive) {

        try {
            OrganizationSpecificationBuilder builder = new OrganizationSpecificationBuilder();
            if(isActive!=null)builder.with("isActive",":",isActive);

            List<Organization> results = organizationRepository.findAll(builder.build());
            return new ResponseModel<>(true, "Records Found",results);

        }catch (Exception e){
            return new ResponseModel<>(false, "Records not found",null);
        }
    }
}