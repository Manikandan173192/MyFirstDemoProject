package com.maxbyte.sam.SecondaryDBFlow.IB.Specification;

import com.maxbyte.sam.SecondaryDBFlow.Helper.GenericSpecificationBuilder;
import com.maxbyte.sam.SecondaryDBFlow.IB.Entity.IB;

public class IBSpecificationBuilder extends GenericSpecificationBuilder<IB> {
}
