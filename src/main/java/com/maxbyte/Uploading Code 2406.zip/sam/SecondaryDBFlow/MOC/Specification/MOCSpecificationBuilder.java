package com.maxbyte.sam.SecondaryDBFlow.MOC.Specification;

import com.maxbyte.sam.SecondaryDBFlow.Helper.GenericSpecificationBuilder;
import com.maxbyte.sam.SecondaryDBFlow.MOC.Entity.MOC;

public class MOCSpecificationBuilder extends GenericSpecificationBuilder<MOC> {
}

