package com.maxbyte.sam.SecondaryDBFlow.CAPA.Specification;

import com.maxbyte.sam.SecondaryDBFlow.CAPA.Entity.CAPA;
import com.maxbyte.sam.SecondaryDBFlow.Helper.GenericSpecificationBuilder;

public class CAPASpecificationBuilder extends GenericSpecificationBuilder<CAPA> {
}

