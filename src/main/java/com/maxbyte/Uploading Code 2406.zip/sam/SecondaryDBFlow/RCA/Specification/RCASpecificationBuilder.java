package com.maxbyte.sam.SecondaryDBFlow.RCA.Specification;

import com.maxbyte.sam.SecondaryDBFlow.Helper.GenericSpecificationBuilder;
import com.maxbyte.sam.SecondaryDBFlow.RCA.Entity.RCA;

public class RCASpecificationBuilder extends GenericSpecificationBuilder<RCA> {
}

