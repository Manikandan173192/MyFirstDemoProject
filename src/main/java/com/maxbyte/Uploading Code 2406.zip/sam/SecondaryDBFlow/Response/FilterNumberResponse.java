package com.maxbyte.sam.SecondaryDBFlow.Response;

import lombok.Data;

@Data
public class FilterNumberResponse {
    private String documentNumber;
    private String woNumber;
}
