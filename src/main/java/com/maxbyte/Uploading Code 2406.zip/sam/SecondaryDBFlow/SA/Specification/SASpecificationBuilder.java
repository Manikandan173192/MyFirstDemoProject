package com.maxbyte.sam.SecondaryDBFlow.SA.Specification;

import com.maxbyte.sam.SecondaryDBFlow.Helper.GenericSpecificationBuilder;
import com.maxbyte.sam.SecondaryDBFlow.SA.Entity.SA;

public class SASpecificationBuilder extends GenericSpecificationBuilder<SA> {

}
