package com.maxbyte.sam.SecondaryDBFlow.CWF.Repository;

import com.maxbyte.sam.SecondaryDBFlow.CWF.Entity.CWF;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface CWFRepository extends JpaRepository<CWF,Integer>, JpaSpecificationExecutor<CWF> {
    List<CWF> findByDocumentNumber(String documentNumber);
    List<CWF> findByOrganizationCode(String orgCode);
    Page<CWF> findByOrganizationCodeAndCreatedOnBetween(String orgCode, LocalDateTime startTime, LocalDateTime endTime, Pageable pageable);
    List<CWF> findByOrganizationCodeAndCreatedOnBetween(String orgCode, LocalDateTime startTime, LocalDateTime endTime);

    @Query("SELECT c FROM CWF c WHERE c.status = 0")
    List<CWF> findOpenCWF();

    @Query("SELECT c FROM CWF c WHERE c.status = 1")
    List<CWF> findCompleteCWF();
    @Query("SELECT c FROM CWF c WHERE c.status = 2")
    List<CWF> findPendingCWF();
    @Query("SELECT c FROM CWF c WHERE c.status = 3")
    List<CWF> findRevertBackCWF();
    @Query("SELECT c FROM CWF c WHERE c.status = 4")
    List<CWF> findClosedCWF();
    Page<CWF> findByCreatedOnBetween(LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);
    Page<CWF> findByDepartmentAndCreatedOnBetween(String department, LocalDateTime startTime, LocalDateTime endTime, Pageable pageable);
    Page<CWF> findByAreaAndCreatedOnBetween(String area, LocalDateTime startTime, LocalDateTime endTime, Pageable pageable);

    @Query("SELECT DISTINCT c.area FROM CWF c")
    List<String> findByArea();

}
