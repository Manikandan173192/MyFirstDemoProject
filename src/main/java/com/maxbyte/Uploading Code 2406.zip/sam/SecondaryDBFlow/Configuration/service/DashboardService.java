package com.maxbyte.sam.SecondaryDBFlow.Configuration.service;

import com.maxbyte.sam.SecondaryDBFlow.AIM.Entity.Aim;
import com.maxbyte.sam.SecondaryDBFlow.AIM.Repository.AimRepository;
import com.maxbyte.sam.SecondaryDBFlow.CAPA.Entity.CAPA;
import com.maxbyte.sam.SecondaryDBFlow.CAPA.Repository.CAPARepository;
import com.maxbyte.sam.SecondaryDBFlow.CWF.Entity.CWF;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.Dashboard;
import com.maxbyte.sam.SecondaryDBFlow.CWF.Repository.CWFRepository;
import com.maxbyte.sam.SecondaryDBFlow.FMEA.Entity.FMEA;
import com.maxbyte.sam.SecondaryDBFlow.FMEA.Repository.FMEARepository;
import com.maxbyte.sam.SecondaryDBFlow.IB.Entity.IB;
import com.maxbyte.sam.SecondaryDBFlow.IB.Repository.IBEntityRepository;
import com.maxbyte.sam.SecondaryDBFlow.MOC.Entity.MOC;
import com.maxbyte.sam.SecondaryDBFlow.MOC.Repository.MOCRepository;
import com.maxbyte.sam.SecondaryDBFlow.RCA.Entity.RCA;
import com.maxbyte.sam.SecondaryDBFlow.RCA.Repository.RCARepository;
import com.maxbyte.sam.SecondaryDBFlow.Response.ResponseModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DashboardService {

    @Autowired
    private CWFRepository cwfRepository;//2
    @Autowired
    private RCARepository rcaRepository;//9
    @Autowired
    private AimRepository aimRepository;//no pending
    @Autowired
    private CAPARepository capaRepository;//4
    @Autowired
    private IBEntityRepository ibEntityRepository;//3
    @Autowired
    private MOCRepository mocRepository;//8 or 9
    @Autowired
    private FMEARepository fmeaRepository;//2




    public ResponseModel<List<Object>> getListCounts() {
        List<Object> countsList = new ArrayList<>();



        //RCA Status
        List<RCA> rcaList = rcaRepository.findAll();
        List<RCA> openRCAs = rcaRepository.findOpenRCAs();
        List<RCA> inProgressRCAs = rcaRepository.findInProgressRCAs();
        List<RCA> completeRCAs = rcaRepository.findCompleteRCAs();
        List<RCA> pendingRCAs = rcaRepository.findPendingRCAs();
        List<RCA> revertBackRCAs = rcaRepository.findRevertBackRCAs();
        List<RCA> closedRCAs = rcaRepository.findClosedRCAs();

        int rcaTotalCount = rcaList.size();
        int openCount = openRCAs.size();
        int inProgressCount = inProgressRCAs.size();
        int completedCount = completeRCAs.size();
        int pendingCount = pendingRCAs.size();
        int revertBackCount = revertBackRCAs.size();
        int closedCount = closedRCAs.size();
        countsList.add(new Dashboard("RCAINProgress", rcaTotalCount, openCount, inProgressCount, completedCount, pendingCount, revertBackCount, closedCount));


        //FMEA Status

        List<FMEA> FMEAList = fmeaRepository.findAll();
        List<FMEA> openFMEAs = fmeaRepository.findOpenFMEAs();
        List<FMEA> inProgressFMEAs = fmeaRepository.findInProgressFMEAs();
        List<FMEA> completeFMEAs = fmeaRepository.findCompleteFMEAs();

        List<FMEA> revertBackFMEAs = fmeaRepository.findRevertBackFMEAs();
        List<FMEA> closedFMEAs = fmeaRepository.findClosedFMEAs();

        int fmeaTotalCount = FMEAList.size();
        int fmeaOpenCount = openFMEAs.size();
        int fmeaInProgressCount = inProgressFMEAs.size();
        int fmeaCompletedCount = completeFMEAs.size();
        int fmeaRevertBackCount = revertBackFMEAs.size();
        int fmeaClosedCount = closedFMEAs.size();
        countsList.add(new Dashboard("FMEA", fmeaTotalCount, fmeaOpenCount, fmeaInProgressCount, fmeaCompletedCount, null, fmeaRevertBackCount, fmeaClosedCount));


        return new ResponseModel<>(true, "Success", countsList);
    }
}
