package com.maxbyte.sam.SecondaryDBFlow.MOC.Repository;

import com.maxbyte.sam.SecondaryDBFlow.AIM.Entity.Aim;
import com.maxbyte.sam.SecondaryDBFlow.MOC.Entity.MOC;
import com.maxbyte.sam.SecondaryDBFlow.SA.Entity.SA;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface MOCRepository extends JpaRepository<MOC, Integer>, JpaSpecificationExecutor<MOC> {
    List<MOC> findByMocNumber(String mocNumber);
    List<MOC> findByCreatedOnBetween(LocalDateTime startTime, LocalDateTime endTime);
    List<MOC> findByOrganizationCodeAndCreatedOnBetween(String orgCode, LocalDateTime from, LocalDateTime to);
    Page<MOC> findByOrganizationCodeAndCreatedOnBetween(String orgCode, LocalDateTime from, LocalDateTime to, Pageable pageable);
    List<MOC> findByOrganizationCode(String organizationCode);
    //List<RCAStepOneTeams> findByStepOneId(Integer id);

    @Query("SELECT r FROM MOC r WHERE r.status = 0")
    List<MOC> findOpenMOCs();

    @Query("SELECT r FROM MOC r WHERE r.status BETWEEN 1 AND 6")
    List<MOC> findInProgressMOCs();

    @Query("SELECT r FROM MOC r WHERE r.status BETWEEN 7 AND 9")
    List<MOC> findCompleteMOCs();
    @Query("SELECT r FROM MOC r WHERE r.status = 10")
    List<MOC> findRevertBackMOCs();
    @Query("SELECT r FROM MOC r WHERE r.status = 11")
    List<MOC> findClosedMOCs();
    List<MOC> findByDepartmentAndCreatedOnBetween(String department, LocalDateTime startTime, LocalDateTime endTime);
    List<MOC> findByAreaAndCreatedOnBetween(String area, LocalDateTime startTime, LocalDateTime endTime);

    Page<MOC> findByCreatedOnBetween(LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);
    Page<MOC> findByAreaAndCreatedOnBetween(String area, LocalDateTime startTime, LocalDateTime endTime, Pageable pageable);
    Page<MOC> findByDepartmentAndCreatedOnBetween(String department, LocalDateTime localDateTime, LocalDateTime localDateTime1, Pageable pageable);

    @Query("SELECT DISTINCT m.area FROM MOC m")
    List<String> findByArea();

    Page<MOC> findByOrganizationCodeAndDepartmentAndAreaAndCreatedOnBetween(String organizationCode, String department, String area, LocalDateTime startDateTime, LocalDateTime endDateTime, PageRequest pageRequest);

    Page<MOC> findByOrganizationCodeAndDepartmentAndCreatedOnBetween(String organizationCode, String department, LocalDateTime startDateTime, LocalDateTime endDateTime, PageRequest pageRequest);

    Page<MOC> findByOrganizationCodeAndAreaAndCreatedOnBetween(String organizationCode, String area, LocalDateTime startDateTime, LocalDateTime endDateTime, PageRequest pageRequest);

    Page<MOC> findByDepartmentAndAreaAndCreatedOnBetween(String department, String area, LocalDateTime startDateTime, LocalDateTime endDateTime, PageRequest pageRequest);
}
