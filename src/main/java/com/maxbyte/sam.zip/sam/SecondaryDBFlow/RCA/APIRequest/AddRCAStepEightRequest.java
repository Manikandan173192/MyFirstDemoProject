package com.maxbyte.sam.SecondaryDBFlow.RCA.APIRequest;

import lombok.Data;

@Data
public class AddRCAStepEightRequest {
    private String rcaNumber;
    private String comments;
}
