package com.maxbyte.sam.SecondaryDBFlow.Response;

import lombok.Data;

@Data
public class ImageResponse {
    private String ImagePath;

}
