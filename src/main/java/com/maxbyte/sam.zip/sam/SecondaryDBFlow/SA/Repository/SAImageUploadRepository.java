package com.maxbyte.sam.SecondaryDBFlow.SA.Repository;

import com.maxbyte.sam.SecondaryDBFlow.SA.Entity.SAImageUpload;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SAImageUploadRepository extends JpaRepository<SAImageUpload, Integer> {
}
