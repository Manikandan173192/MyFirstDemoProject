package com.maxbyte.sam.SecondaryDBFlow.Configuration.service;


import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.Role;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Repository.RoleRepository;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Specification.RoleSpecificationBuilder;
import com.maxbyte.sam.SecondaryDBFlow.Response.ResponseModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RoleService extends CrudService<Role,Integer> {

    @Autowired
    private RoleRepository roleRepository;


    @Override
    public CrudRepository repository() {
        return this.roleRepository;
    }

    @Override
    public void validateAdd(Role data) {
        try{
            Optional<Role> existingRole = roleRepository.findByRoleName(data.getRoleName());
            if (existingRole.isPresent()) {
                throw new IllegalArgumentException("Role name already exists: " + data.getRoleName());
            }
        }
        catch(Error e){
            throw new Error(e);
        }

    }

    @Override
    public void validateEdit(Role data) {
        try{
        }
        catch(Error e){
            throw new Error(e);
        }
    }

    @Override
    public void validateDelete(Integer id) {
        try{

        }
        catch(Error e){
            throw new Error(e);
        }
    }

    public ResponseModel<List<Role>> list(Boolean isActive) {
        try {
            RoleSpecificationBuilder builder = new RoleSpecificationBuilder();
            if(isActive!=null)builder.with("isActive",":",isActive);

            List<Role> results = roleRepository.findAll(builder.build());
            return new ResponseModel<>(true, "Records Found",results.reversed());

        }catch (Exception e){
            return new ResponseModel<>(false, "Records not found",null);
        }
    }
}
