package com.maxbyte.sam.SecondaryDBFlow.Configuration.service;


import com.maxbyte.sam.SecondaryDBFlow.Authentication.Entity.UserInfo;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.Asset;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Repository.AssetRepository;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.Specification.AssetSpecificationBuilder;
import com.maxbyte.sam.SecondaryDBFlow.Response.ResponseModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AssetService extends CrudService<Asset,Integer> {

    @Autowired
    private AssetRepository assetRepository;

    @Value("${pagination.default-size}")
    private int defaultSize;
    @Override
    public CrudRepository repository() {
        return this.assetRepository;
    }

    @Override
    public void validateAdd(Asset data) {
        try{
            Optional<Asset> existingAsset = assetRepository.findByOrganizationCodeAndAssetGroupAndAssetNumber(
                    data.getOrganizationCode(), data.getAssetGroup(), data.getAssetNumber());

            if (existingAsset.isPresent()) {
                throw new IllegalArgumentException("Asset with the same number already exists in the specified organization and asset group.");
            }
        } catch (IllegalArgumentException e) {
            throw e;
        }
        catch(Error e){
            throw new Error(e);
        }

    }

    @Override
    public void validateEdit(Asset data) {
        try{
        }
        catch(Error e){
            throw new Error(e);
        }
    }

    @Override
    public void validateDelete(Integer id) {
        try{

        }
        catch(Error e){
            throw new Error(e);
        }
    }

    public ResponseModel<List<Asset>> list(String assetGroup, String assetDescription, String assetNumber, String organizationCode, Boolean isActive/*,String requestPage*/) {

        try {

            AssetSpecificationBuilder builder = new AssetSpecificationBuilder();
            if (assetGroup != null) builder.with("assetGroup", ":", assetGroup);
            if (assetDescription != null) builder.with("assetDescription", ":", assetDescription);
            if (assetNumber != null) builder.with("assetNumber", ":", assetNumber);
            if (organizationCode != null) builder.with("organizationCode", ":", organizationCode);
            if (isActive != null) builder.with("isActive", ":", isActive);

//            var pageRequestCount = 0;
//
//            if (requestPage.matches(".*\\d.*")) {
//                pageRequestCount = Integer.parseInt(requestPage);
//            } else {
//                pageRequestCount = 0;
//            }
//
//            // Create a PageRequest for pagination
//            PageRequest pageRequest = PageRequest.of(pageRequestCount, defaultSize, Sort.by("createdOn").descending());
//            //Page<Asset> results = assetRepository.findByAssetGroupAndAssetDescriptionAndAssetNumberAndOrganizationCodeAndIsActive(assetGroup, assetDescription, assetNumber, organizationCode, isActive, pageRequest);
            List<Asset> results = assetRepository.findAll(builder.build());
            List<Asset> userList = assetRepository.findAll();
            var totalCount = String.valueOf(userList.size());
            var filteredCount = String.valueOf(results.size());
            if (results.isEmpty()) {
                return new ResponseModel<>(false, "No records found", null);
            } else {
                return new ResponseModel<>(true, totalCount + " Records found & " + filteredCount + " Filtered", results.reversed());
            }
        }catch (Exception e){
            return new ResponseModel<>(false, "Records not found",null);
        }

    }

        //  ***********************  combination of both code  *******************

//    public ResponseModel<List<Asset>> list(String assetGroup, String organizationCode, Boolean isActive) {
//        try {
//            Pageable pageable = PageRequest.of(0, 2);
//            Page<Asset> pageResults;
//
//            // Check if any filtering criteria is provided
//            if (assetGroup != null || organizationCode != null || isActive != null) {
//                // Building specifications dynamically
//                AssetSpecificationBuilder builder = new AssetSpecificationBuilder();
//                if (assetGroup != null) builder.with("assetGroup", ":", assetGroup);
//                if (organizationCode != null) builder.with("organizationCode", ":", organizationCode);
//                if (isActive != null) builder.with("isActive", ":", isActive);
//
//                // Fetch results based on criteria
//                List<Asset> results = assetRepository.findAll(builder.build());
//                return new ResponseModel<>(true, "Records Found", results);
//            } else {
//                // Fetch first page of all assets if no criteria provided
//                pageResults = assetRepository.findAll(pageable);
//            }
//
//            List<Asset> results = pageResults.getContent();
//            return new ResponseModel<>(true, "Records Found", results);
//
//        } catch (Exception e) {
//            return new ResponseModel<>(false, "Error fetching records: " + e.getMessage(), null);
//        }
//    }

//    public ResponseModel<List<Asset>> list(String assetGroup, String assetDescription, String assetNumber, String organizationCode, Boolean isActive) {
//        try {
//
//            Pageable pageable = PageRequest.of(0, 5);
//            Page<Asset> pageResults = assetRepository.findByAssetGroupAndAssetDescriptionAndAssetNumberAndOrganizationCodeAndIsActive(assetGroup, assetDescription, assetNumber, organizationCode, isActive, pageable);
//            List<Asset> results = pageResults.getContent();
//            return new ResponseModel<>(true, "Records Found",results.reversed());
//        } catch (Exception e) {
//            return new ResponseModel<>(false, "Records not found", null);
//        }
//    }

}