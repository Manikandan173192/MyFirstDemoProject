/*
package com.maxbyte.sam.SecondaryDBFlow.MOC.APIRequest;

import lombok.Data;

@Data
public class MOCActionModelAsset {
    private String assetNumber;
    private String assetDescription;

}
*/
