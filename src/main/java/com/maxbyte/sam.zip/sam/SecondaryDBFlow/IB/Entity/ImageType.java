package com.maxbyte.sam.SecondaryDBFlow.IB.Entity;

public enum ImageType {
    Upload, Restore
}
