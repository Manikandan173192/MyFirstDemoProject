package com.maxbyte.sam.SecondaryDBFlow.SA.Repository;

import com.maxbyte.sam.SecondaryDBFlow.IB.Entity.IB;
import com.maxbyte.sam.SecondaryDBFlow.RCA.Entity.RCA;
import com.maxbyte.sam.SecondaryDBFlow.SA.Entity.SA;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
@Repository
public interface SARepository extends JpaRepository<SA, Integer> , JpaSpecificationExecutor<SA> {


    List<SA> findByAssetNumber(String assetNumber);

    List<SA> findByAssetNumberAndCheckListType(String assetNumber,String checkListType);


    @Modifying
    @Transactional
    List<SA>deleteByAssetNumber(String assetNumber);

    List<SA> findByOrganizationCodeAndCreatedOnBetween(String orgCode, LocalDateTime from, LocalDateTime to);
    Page<SA> findByOrganizationCodeAndCreatedOnBetween(String orgCode, LocalDateTime from, LocalDateTime to, Pageable pageable);
    List<SA> findByCreatedOnBetween(LocalDateTime startDate, LocalDateTime endDate);
    List<SA> findByDepartmentAndCreatedOnBetween(String department, LocalDateTime startTime, LocalDateTime endTime);
    List<SA> findByAreaAndCreatedOnBetween(String area, LocalDateTime startTime, LocalDateTime endTime);

    Page<SA> findByCreatedOnBetween(LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);
    Page<SA> findByAreaAndCreatedOnBetween(String area, LocalDateTime startTime, LocalDateTime endTime, Pageable pageable);
    Page<SA> findByDepartmentAndCreatedOnBetween(String department, LocalDateTime localDateTime, LocalDateTime localDateTime1, Pageable pageable);

    @Query("SELECT DISTINCT s.area FROM SA s")
    List<String> findByArea();

//    @Query("SELECT r FROM SA r WHERE r.status = 0")
//    List<SA> findOpenSAs();
//
//    @Query("SELECT r FROM SA r WHERE r.status= 1")
//    List<SA> findApproverPendingSAs();
//
//    @Query("SELECT r FROM SA r WHERE r.status = 2")
//    List<SA> findApprovedSAs();
}
