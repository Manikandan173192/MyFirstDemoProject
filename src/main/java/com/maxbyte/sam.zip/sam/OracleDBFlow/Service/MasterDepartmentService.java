package com.maxbyte.sam.OracleDBFlow.Service;

import com.maxbyte.sam.OracleDBFlow.Repository.MasterDepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class MasterDepartmentService {

    @Autowired
    MasterDepartmentRepository departmentService;

    public ResponseEntity<String> getDepartment(){
        var departmentList = departmentService.findAll();
        System.out.println(departmentList);
        return new ResponseEntity<>("Success", HttpStatus.OK);
    }

}
