package com.maxbyte.sam.OracleDBFlow.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class MasterUserInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String UNIT;
    private String PLANT_CODE;
    private String ORGANIZATION_CODE;
    private String EMP_CODE;
    private String TITLE_CODE;
    private String FIRST_NAME;
    private String MIDDLE_NAME;
    private String LAST_NAME;
    private String CONTRACTOR_FIRM_NAME;
}
