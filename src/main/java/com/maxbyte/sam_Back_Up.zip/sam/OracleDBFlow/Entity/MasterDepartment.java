package com.maxbyte.sam.OracleDBFlow.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class MasterDepartment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer DEPARTMENT_ID;
    private Integer ORGANIZATION_ID;
    private String ORGANIZATION_CODE;
    private String DEPARTMENT_CODE;
    private String DESCRIPTION;
    private Integer LOCATION_ID;
    private String LOCATION_CODE;
    private String LOCATION_DESCRIPTION;
    private String MAINT_COST_CATEGORY_VALUE;
}
