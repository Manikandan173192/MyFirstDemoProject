package com.maxbyte.sam.OracleDBFlow.Controller;

import com.maxbyte.sam.OracleDBFlow.Service.MasterDepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/api/department/")
public class MasterDepartmentController {

    @Autowired
    MasterDepartmentService departmentService;

    @GetMapping("getSourceDepartment")
    public ResponseEntity<String> getDept(){
        return departmentService.getDepartment();
    }

}
