package com.maxbyte.sam.SecondaryDBFlow.Configuration.Repository;

import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.AssetGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AssetGroupRepository extends JpaRepository<AssetGroup, Integer> , JpaSpecificationExecutor<AssetGroup> {
    Optional<AssetGroup> findByAssetGroupAndOrganizationCode(String assetGroup, String organizationCode);

}
