package com.maxbyte.sam.SecondaryDBFlow.Configuration.Specification;


import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.Role;
import com.maxbyte.sam.SecondaryDBFlow.Helper.GenericSpecificationBuilder;

public class RoleSpecificationBuilder extends GenericSpecificationBuilder<Role> {
}
