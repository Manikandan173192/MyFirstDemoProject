package com.maxbyte.sam.SecondaryDBFlow.Configuration.Specification;

import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.CheckListType;
import com.maxbyte.sam.SecondaryDBFlow.Helper.GenericSpecificationBuilder;

public class CheckListTypeSpecificationBuilder extends GenericSpecificationBuilder<CheckListType> {
}
