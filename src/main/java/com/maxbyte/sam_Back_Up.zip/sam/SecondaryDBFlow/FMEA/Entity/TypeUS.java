package com.maxbyte.sam.SecondaryDBFlow.FMEA.Entity;

import lombok.Data;


public enum TypeUS {

    FMEA_US_Function,
    FMEA_US_FailureMode,
    FMEA_US_Cause,
    FMEA_US_Cause1,
    FMEA_US_Cause2,
    FMEA_US_Cause3,
    FMEA_US_Cause4,
    FMEA_US_Effect,
    FMEA_US_Effect1,
    FMEA_US_Effect2,
    FMEA_US_Effect3,
    FMEA_US_Effect4,
    FMEA_US_Action,
    FMEA_US_Action1,
    FMEA_US_Action2,
    FMEA_US_Action3,
    FMEA_US_Action4,
}
