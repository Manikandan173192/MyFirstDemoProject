package com.maxbyte.sam.SecondaryDBFlow.RCA.Service;


import com.maxbyte.sam.SecondaryDBFlow.CAPA.APIRequest.ValidateRequest;
import com.maxbyte.sam.SecondaryDBFlow.Configuration.service.CrudService;
import com.maxbyte.sam.SecondaryDBFlow.RCA.APIRequest.*;
import com.maxbyte.sam.SecondaryDBFlow.RCA.Entity.*;
import com.maxbyte.sam.SecondaryDBFlow.RCA.Repository.*;
import com.maxbyte.sam.SecondaryDBFlow.RCA.Specification.RCASpecificationBuilder;
import com.maxbyte.sam.SecondaryDBFlow.Response.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.CrudRepository;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.*;

@Service
@EnableScheduling
public class RCAService extends CrudService<RCA,Integer> {

    @Autowired
    private RCARepository rcaRepository;

    @Autowired
    private RCAStepOneRepository rcaStepOneRepository;
    @Autowired
    private RCAStepOneMembersRepository rcaStepOneMembersRepository;
    @Autowired
    private RCAStepTwoRepository rcaStepTwoRepository;
    @Autowired
    private RCAIsNotQuestionRepository rcaIsNotQuestionRepository;

    @Autowired
    private RCAStepThreeRepository rcaStepThreeRepository;
    @Autowired
    private RCAStepThreeQuestionsRepository rcaStepThreeQuestionsRepository;
    @Autowired
    private RCAStepFourRepository rcaStepFourRepository;
    @Autowired
    private RCAStepFourCARepository rcaStepFourCARepository;

    @Autowired
    private RCAStepFiveRepository rcaStepFiveRepository;
    @Autowired
    private RCAStepFiveDCARepository rcaStepFiveDCARepository;

    @Autowired
    private RCAStepSixRepository rcaStepSixRepository;
    @Autowired
    private RCAStepSixCauseRepository rcaStepSixCauseRepository;
    @Autowired
    private RCAStepSevenRepository rcaStepSevenRepository;
    @Autowired
    private RCAStepSevenCARepository rcaStepSevenCARepository;
    @Autowired
    private RCAStepSevenPARepository rcaStepSevenPARepository;
    @Value("${pagination.default-page}")
    private int defaultPage;

    @Value("${pagination.default-size}")
    private int defaultSize;

    @Autowired
    private Environment environment;

    @Override
    public CrudRepository repository() {
        return this.rcaRepository;
    }

    @Override
    public void validateAdd(RCA data) {
        try{
        }
        catch(Error e){
            throw new Error(e);
        }

    }

    @Override
    public void validateEdit(RCA data) {
        try{
        }
        catch(Error e){
            throw new Error(e);
        }
    }

    @Override
    public void validateDelete(Integer id) {
        try{

        }
        catch(Error e){
            throw new Error(e);
        }
    }

    public ResponseModel<List<RCA>> findRCAByDateTime(String orgCode, LocalDateTime from, LocalDateTime to) {
        try {
            var dateTimeFilterList = rcaRepository.findByOrganizationCodeAndCreatedOnBetween(orgCode, from, to);
            return new ResponseModel<>(true, "Records found",dateTimeFilterList);

        }catch (Exception e){
            return new ResponseModel<>(false, "Records not found",null);
        }
    }


    public ResponseModel<List<RCA>> list(Boolean isActive, String organizationCode, String assetNumber, String assetDescription,
                                         String department, String documentNumber, String woNumber, String requestPage) {
        try {
            RCASpecificationBuilder builder = new RCASpecificationBuilder();
            if(isActive!=null)builder.with("isActive",":",isActive);
            if(organizationCode!=null)builder.with("organizationCode","==",organizationCode);
            if(assetNumber!=null)builder.with("assetNumber","==",assetNumber);
            if(assetDescription!=null)builder.with("assetDescription","==",assetDescription);
            if(department!=null)builder.with("department","==",department);
            if(documentNumber!=null)builder.with("rcaNumber","==",documentNumber);
            if(woNumber!=null)builder.with("woNumber","==",woNumber);

            var pageRequestCount = 0;

            if(requestPage.matches(".*\\d.*")){
                pageRequestCount = Integer.parseInt(requestPage);
            }else{
                pageRequestCount = 0;
            }

            // Create a PageRequest for pagination
            PageRequest pageRequest = PageRequest.of(pageRequestCount, defaultSize, Sort.by("createdOn").descending());
            Page<RCA> results = rcaRepository.findAll(builder.build(), pageRequest);
            List<RCA> rcaList = rcaRepository.findAll();
            var totalCount = String.valueOf(rcaList.size());
            var filteredCount = String.valueOf(results.getContent().size());
            if (results.isEmpty()) {
                return new ResponseModel<>(false, "No records found", null);
            } else {
                return new ResponseModel<>(true, totalCount+" Records found & "+filteredCount+ " Filtered", results.getContent());
            }

        }catch (Exception e){
            return new ResponseModel<>(false, "Records not found",null);
        }
    }

    public ResponseModel<String> addRCA(AddRCARequest rcaRequest){
        try {
            List<RCA> rcaList = rcaRepository.findAll();
            var rcaData = new RCA();
            LocalDateTime instance = LocalDateTime.now();

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ddMMyyyy");

            String formattedStartDate = formatter.format(instance);


            if(!rcaList.isEmpty()){
                int id = rcaList.getLast().getRcaId()+1;
                rcaData.setRcaNumber("RCA_"+
                        rcaRequest.getOrganizationCode()+ "_"+
                        rcaRequest.getDepartment()+"_" +
                        formattedStartDate+"_"+
                        id);
            }else {
                rcaData.setRcaNumber("RCA_"+
                        rcaRequest.getOrganizationCode()+ "_"+
                        rcaRequest.getDepartment()+"_" +
                        formattedStartDate+"_"+
                        1);
            }

            rcaData.setOrganizationCode(rcaRequest.getOrganizationCode());
            rcaData.setAssetGroupId(rcaRequest.getAssetGroupId());
            rcaData.setAssetGroup(rcaRequest.getAssetGroup());
            rcaData.setAssetId(rcaRequest.getAssetId());
            rcaData.setAssetNumber(rcaRequest.getAssetNumber());
            rcaData.setAssetDescription(rcaRequest.getAssetDescription());
            rcaData.setDepartment(rcaRequest.getDepartment());
            rcaData.setDepartmentId(rcaRequest.getDepartmentId());
            rcaData.setArea(rcaRequest.getArea());
            rcaData.setRcaType(rcaRequest.getRcaType());
            rcaData.setCreatedById(rcaRequest.getCreatedById());
            rcaData.setCreatedBy(rcaRequest.getCreatedBy());
            rcaData.setApprover1Id(rcaRequest.getApprover1Id());
            rcaData.setApprover1Name(rcaRequest.getApprover1Name());
            rcaData.setApprover2Id(rcaRequest.getApprover2Id());
            rcaData.setApprover2Name(rcaRequest.getApprover2Name());
            rcaData.setApprover3Id(rcaRequest.getApprover3Id());
            rcaData.setApprover3Name(rcaRequest.getApprover3Name());
            rcaData.setIssueDescription(rcaRequest.getIssueDescription());
            rcaData.setStatus(0);
            rcaData.setActive(true);
            rcaData.setWoNumber("");
            rcaData.setCreatedOn(LocalDateTime.now());

            rcaRepository.save(rcaData);
            return new ResponseModel<>(true, "RCA Created Successfully",rcaData.getRcaNumber());

        }catch (Exception e){
            return new ResponseModel<>(false, "Failed to add",null);
        }
    }

    public ResponseModel<List<FilterNumberResponse>> getFilterNumber(String organizationCode){
        try {
            List<RCA> rcaList = rcaRepository.findByOrganizationCode(organizationCode);
            List<FilterNumberResponse> filterList = new ArrayList<>();
            for(RCA item: rcaList){
                FilterNumberResponse filterResponse = new FilterNumberResponse();
                filterResponse.setWoNumber(item.getWoNumber());
                filterResponse.setDocumentNumber(item.getRcaNumber());
                filterList.add(filterResponse);
            }

            return new ResponseModel<List<FilterNumberResponse>>(true, "Records Found",filterList.reversed());

        }catch (Exception e){
            return new ResponseModel<>(false, "Records Not Found",null);
        }
    }

    public ResponseModel<ImageResponse> saveImageToStorage(String uploadDirectory, MultipartFile imageFile) throws IOException {
        String uniqueFileName = UUID.randomUUID().toString() + "_" + imageFile.getOriginalFilename();
        Path uploadPath = Path.of(uploadDirectory);
        Path filePath = uploadPath.resolve(uniqueFileName);

        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }
        Files.copy(imageFile.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

        var imagePath = new ImageResponse();
        imagePath.setImagePath((uploadDirectory+"/"+uniqueFileName).replace("target/classes/static",""));
        return new ResponseModel<>(true, "Image Updated Successfully",imagePath);
    }

    @Scheduled(cron = "0 0 0 * * *")  // first 0 Seconds, 0 minute, 0 hours, 0 days, 0 months, 0 week days
    public ResponseModel<String> deleteAllImagesInFolder() {
        List<RCAStepThreeQuestions> rcaStepThreeList = rcaStepThreeQuestionsRepository.findAll();
        System.out.println("Five minutes call");
        List<String> images = new ArrayList<>();
        for (RCAStepThreeQuestions stepThree : rcaStepThreeList) {
            images.add(stepThree.getAttachedImage());
        }

        String folderPath = environment.getProperty("image.uploadDirectory") + "/RCA";
        File folder = new File(folderPath);
        if (!folder.exists() || !folder.isDirectory()) {
            return new ResponseModel<>(false, "Folder not found or is not a directory");
        }

        File[] files = folder.listFiles();
        if (files != null && files.length > 0) {
            boolean filesDeleted = false;
            for (File file : files) {
                if (file.isFile()) {
                    String fileName = file.getName();               //  periyasamy
                    System.out.println(fileName);
                    boolean shouldDelete = true;
                    for (String imagePath : images) {
                        if (imagePath != null && imagePath.equals(fileName)) {
                            shouldDelete = false;
                            break;
                        }
                    }
                    if (shouldDelete) {
                        if (file.delete()) {
                            filesDeleted = true;
                        }
                    }
                }
                System.out.println("Files after Deleted " + file);
            }
            if (filesDeleted) {
                return new ResponseModel<>(true, "Images deleted successfully");
            } else {
                return new ResponseModel<>(false, "No images found to delete");
            }
        } else {
            return new ResponseModel<>(false, "No files found in the directory");
        }
    }


    //RCA Step One
    public ResponseModel<String> addRCAStepOne(AddRCAStepOneRequest stepOneRequest){
        try {

            List<RCAStepOne> stepOneList = rcaStepOneRepository.findByRcaNumber(stepOneRequest.getRcaNumber());
            var apiAction = 0;
            if(!stepOneList.isEmpty()){
                //Update step one RCA
                stepOneList.getFirst().setRcaNumber(stepOneRequest.getRcaNumber());
                stepOneList.getFirst().setProblemDescription(stepOneRequest.getProblemDescription());
                rcaStepOneRepository.save(stepOneList.getFirst());

                //Delete existing team members for the particular RCA no
                var addedTeamList = rcaStepOneMembersRepository.findByRcaNumber(stepOneList.getFirst().getRcaNumber());
                if(!addedTeamList.isEmpty()){
                    for(RCAStepOneTeams items: addedTeamList){
                        if(items.getRcaNumber().equals(stepOneList.getFirst().getRcaNumber())){
                            rcaStepOneMembersRepository.deleteByTeamId(items.getTeamId());
                        }
                    }
                }

                for(RCAStepOneTeams item:stepOneRequest.getTeamsList()){
                    var rcaTeamsData = new RCAStepOneTeams();
                    rcaTeamsData.setTeamMemberName(item.getTeamMemberName());
                    rcaTeamsData.setTeamMemberDepartment(item.getTeamMemberDepartment());
                    rcaTeamsData.setTeamMemberResponsibility(item.getTeamMemberResponsibility());
                    rcaTeamsData.setTeamMemberType(item.getTeamMemberType());
                    rcaTeamsData.setRcaNumber(stepOneList.getFirst().getRcaNumber());
                    rcaStepOneMembersRepository.save(rcaTeamsData);
                }
                apiAction = 2;
            }else{

                //Add step one RCA
                var rcaData = new RCAStepOne();
                rcaData.setRcaNumber(stepOneRequest.getRcaNumber());
                rcaData.setProblemDescription(stepOneRequest.getProblemDescription());

                rcaStepOneRepository.save(rcaData);

                List<RCAStepOne> RCAStepOneList = rcaStepOneRepository.findByRcaNumber(stepOneRequest.getRcaNumber());

                for(RCAStepOneTeams item:stepOneRequest.getTeamsList()){
                    var rcaTeamsData = new RCAStepOneTeams();
                    rcaTeamsData.setTeamMemberName(item.getTeamMemberName());
                    rcaTeamsData.setTeamMemberDepartment(item.getTeamMemberDepartment());
                    rcaTeamsData.setTeamMemberResponsibility(item.getTeamMemberResponsibility());
                    rcaTeamsData.setTeamMemberType(item.getTeamMemberType());
                    rcaTeamsData.setRcaNumber(RCAStepOneList.getLast().getRcaNumber());

                    rcaStepOneMembersRepository.save(rcaTeamsData);
                }
                apiAction = 1;
            }

            List<RCA> rcaList = rcaRepository.findByRcaNumber(stepOneRequest.getRcaNumber());
            if(!rcaList.isEmpty()){
                //Update RCA step one status
                if(rcaList.getFirst().getStatus()==0) {
                    rcaList.getFirst().setStatus(1);
                }
                rcaRepository.save(rcaList.getFirst());
            }
            return new ResponseModel<>(true, apiAction ==1?"Team Members & Problem Description Created Successfully":"Team Members & Problem Description Updated Successfully",null);

        }catch (Exception e){
            return new ResponseModel<>(false, "Failed to add",null);
        }
    }

    public ResponseModel<RCAStepOne> getRCAStepOne(String rcaNo){
        try {
            List<RCAStepOne> stepOneList = rcaStepOneRepository.findByRcaNumber(rcaNo);

            return new ResponseModel<>(true, "Records found",stepOneList.getFirst());

        }catch (Exception e){
            return new ResponseModel<>(false, "Records not found",null);
        }
    }

    //RCA Step Two
    public ResponseModel<String> addRCAStepTwo(AddRCAStepTwoRequest stepTwoRequest){
        try {

            List<RCAStepTwo> stepTwoList = rcaStepTwoRepository.findByRcaNumber(stepTwoRequest.getRcaNumber());
            var apiAction = 0;
            if(!stepTwoList.isEmpty()){
                //Update RCA step two
                stepTwoList.getFirst().setRcaNumber(stepTwoRequest.getRcaNumber());
                stepTwoList.getFirst().setContainmentAction(stepTwoRequest.getContainmentAction());
                rcaStepTwoRepository.save(stepTwoList.getFirst());
                apiAction = 2;
            }else{
                //Add RCA step two
                var rcaData = new RCAStepTwo();
                rcaData.setRcaNumber(stepTwoRequest.getRcaNumber());
                rcaData.setContainmentAction(stepTwoRequest.getContainmentAction());
                rcaStepTwoRepository.save(rcaData);
                apiAction = 1;
            }


            List<RCA> rcaList = rcaRepository.findByRcaNumber(stepTwoRequest.getRcaNumber());
            if(!rcaList.isEmpty()){
                //Update RCA step two status
                if(rcaList.getFirst().getStatus()==1) {
                    rcaList.getFirst().setStatus(2);
                }
                rcaRepository.save(rcaList.getFirst());
            }

            return new ResponseModel<>(true, apiAction == 1?"Containment Action Created Successfully":"Containment Action Updated Successfully",null);

        }catch (Exception e){
            return new ResponseModel<>(false, "Failed to add",null);
        }
    }

    public ResponseModel<RCAStepTwo> getRCAStepTwo(String rcaNo){
        try {
            List<RCAStepTwo> stepTwoList = rcaStepTwoRepository.findByRcaNumber(rcaNo);
            return new ResponseModel<>(true, "Records Found",stepTwoList.getFirst());

        }catch (Exception e){
            return new ResponseModel<>(false, "Records Not Found",null);
        }
    }

    public ResponseModel<String> addRCAIsNotQuestions(AddIsNotQuestions isNotQuestions){
        try {
            //Add RCA step three questions
            var rcaData = new RCAIsNotQuestions();
            rcaData.setQuestionCategory(isNotQuestions.getQuestionCategory());
            rcaData.setQuestionType(isNotQuestions.getQuestionType());
            rcaData.setQuestion(isNotQuestions.getQuestion());

            rcaIsNotQuestionRepository.save(rcaData);

            return new ResponseModel<>(true, "Questions Added Successfully",null);

        }catch (Exception e){
            return new ResponseModel<>(false, "Failed to add",null);
        }
    }
    public ResponseModel<List<RCAIsNotQuestions>> getRCAIsNotQuestions(){
        try {

             var questionData = rcaIsNotQuestionRepository.findAll();

            return new ResponseModel<>(true, "Records Found",questionData);

        }catch (Exception e){
            return new ResponseModel<>(false, "Records not Found",null);
        }
    }

    public ResponseModel<String> updateRCAIsNotQuestions(Integer id, AddIsNotQuestions isNotQuestions){
        try {

             var questionData = rcaIsNotQuestionRepository.findByQuestionId(id);
            //Update RCA step three questions
            if(!questionData.isEmpty()){
                questionData.getFirst().setQuestionCategory(isNotQuestions.getQuestionCategory());
                questionData.getFirst().setQuestionType(isNotQuestions.getQuestionType());
                questionData.getFirst().setQuestion(isNotQuestions.getQuestion());
                rcaIsNotQuestionRepository.save(questionData.getFirst());
            }

            return new ResponseModel<>(true, "Questions Updated Successfully",null);

        }catch (Exception e){
            return new ResponseModel<>(false, "Failed to add",null);
        }
    }
    public ResponseModel<String> deleteRCAIsNotQuestions(Integer id){
        try {

             var questionData = rcaIsNotQuestionRepository.findByQuestionId(id);
            //Update RCA step three questions
            if(!questionData.isEmpty()){
                rcaIsNotQuestionRepository.delete(questionData.getFirst());
            }

            return new ResponseModel<>(true, "Questions Deleted Successfully",null);

        }catch (Exception e){
            return new ResponseModel<>(false, "Failed to add",null);
        }
    }

    //RCA Step Three
    public ResponseModel<String> addRCAStepThree(AddRCAStepThreeRequest stepThreeRequest) {
        try {

            List<RCAStepThree> stepThreeList = rcaStepThreeRepository.findByRcaNumber(stepThreeRequest.getRcaNumber());
            var apiAction = 0;

            if(!stepThreeList.isEmpty()){
                //Update step RCA
                stepThreeList.getFirst().setRcaNumber(stepThreeRequest.getRcaNumber());
                stepThreeList.getFirst().setQuestionsList(stepThreeRequest.getQuestionsList());

                rcaStepThreeRepository.save(stepThreeList.getFirst());

                //Delete existing Questions for the particular RCA no
                var addedQuestionsList = rcaStepThreeQuestionsRepository.findByRcaNumber(stepThreeList.getFirst().getRcaNumber());
                if(!addedQuestionsList.isEmpty()){
                    for(RCAStepThreeQuestions items: addedQuestionsList){
                        if(items.getRcaNumber().equals(stepThreeList.getFirst().getRcaNumber())){
                            rcaStepThreeQuestionsRepository.deleteByQuestionId(items.getQuestionId());
                        }
                    }
                }

                for(RCAStepThreeQuestions item:stepThreeRequest.getQuestionsList()){
                    var rcaTeamsData = new RCAStepThreeQuestions();
                    rcaTeamsData.setQuestionCategory(item.getQuestionCategory());
                    rcaTeamsData.setQuestionType(item.getQuestionType());
                    rcaTeamsData.setQuestion(item.getQuestion());
                    rcaTeamsData.setAnswer(item.getAnswer());
                    rcaTeamsData.setAttachedImage(item.getAttachedImage());
                    rcaTeamsData.setUrl(item.getUrl());
                    rcaTeamsData.setRcaNumber(stepThreeList.getFirst().getRcaNumber());
                    rcaStepThreeQuestionsRepository.save(rcaTeamsData);
                }
                apiAction = 2;

            }else{

                //Add step  RCA
                var rcaData = new RCAStepThree();
                rcaData.setRcaNumber(stepThreeRequest.getRcaNumber());
                rcaData.setQuestionsList(stepThreeRequest.getQuestionsList());
                rcaStepThreeRepository.save(rcaData);

                List<RCAStepThree> RCAStepThreeList = rcaStepThreeRepository.findByRcaNumber(stepThreeRequest.getRcaNumber());

                for(RCAStepThreeQuestions item:stepThreeRequest.getQuestionsList()){
                    var rcaQuestionsData = new RCAStepThreeQuestions();
                    rcaQuestionsData.setQuestionCategory(item.getQuestionCategory());
                    rcaQuestionsData.setQuestionType(item.getQuestionType());
                    rcaQuestionsData.setQuestion(item.getQuestion());
                    rcaQuestionsData.setAnswer(item.getAnswer());
                    rcaQuestionsData.setAttachedImage(item.getAttachedImage());
                    rcaQuestionsData.setUrl(item.getUrl());
                    rcaQuestionsData.setRcaNumber(RCAStepThreeList.getFirst().getRcaNumber());
                    rcaStepThreeQuestionsRepository.save(rcaQuestionsData);
                }
                apiAction = 1;
            }

            List<RCA> rcaList = rcaRepository.findByRcaNumber(stepThreeRequest.getRcaNumber());
            if(!rcaList.isEmpty()){
                //Update RCA step status
                if(rcaList.getFirst().getStatus()==2) {
                    rcaList.getFirst().setStatus(3);
                }
                rcaRepository.save(rcaList.getFirst());
            }
            return new ResponseModel<>(true, apiAction==1?"IS & IS-NOT Created Successfully":"IS & IS-NOT Updated Successfully",null);

        }catch (Exception e){
            return new ResponseModel<>(false, "Failed to add",null);
        }
    }

    public ResponseModel<List<RCAStepThreeQuestions>> getRCAStepThree(String rcaNo){
        try {
            List<RCAStepThree> stepThreeList = rcaStepThreeRepository.findByRcaNumber(rcaNo);
            return new ResponseModel<>(true, "Records Found",stepThreeList.getFirst().getQuestionsList().reversed());

        }catch (Exception e){
            return new ResponseModel<>(false, "Records Not Found",null);
        }
    }

    public ResponseModel<String> addRCAStepFour(AddRCAStepFourRequest stepFourRequest) {
        try {
            List<RCAStepFour> stepFourList = rcaStepFourRepository.findByRcaNumber(stepFourRequest.getRcaNumber());
            var apiAction = 0;
            if (!stepFourList.isEmpty()) {
                stepFourList.getFirst().setRcaNumber(stepFourRequest.getRcaNumber());
                rcaStepFourRepository.save(stepFourList.getFirst());

                var addedTableList = rcaStepFourCARepository.findByRcaNumber(stepFourList.getFirst().getRcaNumber());
                if (!addedTableList.isEmpty()) {
                    for (RCAStepFourCA items : addedTableList) {
                        if (items.getRcaNumber().equals(stepFourList.getFirst().getRcaNumber())) {
                            rcaStepFourCARepository.deleteByRcaStepFourTableId(items.getRcaStepFourTableId());
                        }
                    }
                }
                for (RCAStepFourCA items : stepFourRequest.getStepFourTables()) {
                    var rcaTableData = new RCAStepFourCA();
                    rcaTableData.setChange(items.getChange());
                    rcaTableData.setDifference(items.getDifference());
                    rcaTableData.setTargetDate(items.getTargetDate());
                    rcaTableData.setApplicable(items.isApplicable());
                    rcaTableData.setRcaNumber(stepFourList.getFirst().getRcaNumber());

                    rcaStepFourCARepository.save(rcaTableData);
                }
                apiAction = 2;
            } else {
                //Add step RCA
                var rcaData = new RCAStepFour();
                rcaData.setRcaNumber(stepFourRequest.getRcaNumber());
                rcaData.setTableList(stepFourRequest.getStepFourTables());
                rcaStepFourRepository.save(rcaData);

                List<RCAStepFour> RCAStepFourList = rcaStepFourRepository.findAll();

                for (RCAStepFourCA item : stepFourRequest.getStepFourTables()) {
                    var rcaTeamsData = new RCAStepFourCA();
                    rcaTeamsData.setChange(item.getChange());
                    rcaTeamsData.setDifference(item.getDifference());
                    rcaTeamsData.setTargetDate(item.getTargetDate());
                    rcaTeamsData.setApplicable(item.isApplicable());
                    rcaTeamsData.setRcaNumber(RCAStepFourList.getLast().getRcaNumber());

                    rcaStepFourCARepository.save(rcaTeamsData);
                }
                apiAction = 1;
                List<RCA> rcaList = rcaRepository.findByRcaNumber(stepFourRequest.getRcaNumber());
                if (!rcaList.isEmpty()) {
                    //Update RCA step four status
                    if (rcaList.getFirst().getStatus() == 3) {
                        rcaList.getFirst().setStatus(4);
                    }
                    rcaRepository.save(rcaList.getFirst());
                }
            }
            return new ResponseModel<>(true, apiAction == 1 ? "Comparative Analysis is Created Successfully" : "Comparative Analysis is Updated Successfully", null);

        } catch (Exception e) {
            return new ResponseModel<>(false, "Failed to add", null);
        }
    }

    public ResponseModel<List<RCAStepFourCA>> getRCAStepFour(String rcaNo) {
        try {
            List<RCAStepFour> stepFourList = rcaStepFourRepository.findByRcaNumber(rcaNo);

            return new ResponseModel<>(true, "Records found", stepFourList.getFirst().getTableList().reversed());

        } catch (Exception e) {
            return new ResponseModel<>(false, "Records not found", null);
        }
    }

    //RCA Step Five
    public ResponseModel<String> addRCAStepFive(AddRCAStepFiveRequest stepFiveRequest){
        try {

            List<RCAStepFive> stepFiveList = rcaStepFiveRepository.findByRcaNumber(stepFiveRequest.getRcaNumber());
            var apiAction = 0;
            if(!stepFiveList.isEmpty()){
                //Update step one RCA
                stepFiveList.getFirst().setRcaNumber(stepFiveRequest.getRcaNumber());
                stepFiveList.getFirst().setProblemDescription(stepFiveRequest.getProblemDescription());
                rcaStepFiveRepository.save(stepFiveList.getFirst());

                //Delete existing team members for the particular RCA no
                var addedTeamList = rcaStepFiveDCARepository.findByRcaNumber(stepFiveList.getFirst().getRcaNumber());
                System.out.println(addedTeamList.size());
                if(!addedTeamList.isEmpty()){
                    for(RCAStepFiveDCA items: addedTeamList){

                        if(items.getRcaNumber().equals(stepFiveList.getFirst().getRcaNumber())){
                            rcaStepFiveDCARepository.deleteByDcaId(items.getDcaId());
                            System.out.println(items.getDcaId());
                        }
                    }
                }

                for(RCAStepFiveDCA item:stepFiveRequest.getDcaList()){
                    var rcaTeamsData = new RCAStepFiveDCA();
                    rcaTeamsData.setDcaType(item.getDcaType());
                    rcaTeamsData.setDcaHighlight(item.isDcaHighlight());
                    rcaTeamsData.setDcaReason(item.getDcaReason());
                    rcaTeamsData.setRcaNumber(stepFiveList.getFirst().getRcaNumber());
                    rcaStepFiveDCARepository.save(rcaTeamsData);
                }
                apiAction = 2;
            }else{

                //Add step one RCA
                var rcaData = new RCAStepFive();
                rcaData.setRcaNumber(stepFiveRequest.getRcaNumber());
                rcaData.setProblemDescription(stepFiveRequest.getProblemDescription());

                rcaStepFiveRepository.save(rcaData);

                List<RCAStepFive> RCAStepFiveList = rcaStepFiveRepository.findByRcaNumber(stepFiveRequest.getRcaNumber());

                for(RCAStepFiveDCA item:stepFiveRequest.getDcaList()){
                    var rcaTeamsData = new RCAStepFiveDCA();
                    rcaTeamsData.setDcaType(item.getDcaType());
                    rcaTeamsData.setDcaHighlight(item.isDcaHighlight());
                    rcaTeamsData.setDcaReason(item.getDcaReason());
                    rcaTeamsData.setRcaNumber(RCAStepFiveList.getLast().getRcaNumber());

                    rcaStepFiveDCARepository.save(rcaTeamsData);
                }
                apiAction = 1;
            }

            List<RCA> rcaList = rcaRepository.findByRcaNumber(stepFiveRequest.getRcaNumber());
            if(!rcaList.isEmpty()){
                //Update RCA step one status
                if(rcaList.getFirst().getStatus()==4) {
                    rcaList.getFirst().setStatus(5);
                }
                rcaRepository.save(rcaList.getFirst());
            }
            return new ResponseModel<>(true, apiAction ==1?"Direct Cause Analysis Created Successfully":"Direct Cause Analysis Updated Successfully",null);

        }catch (Exception e){
            return new ResponseModel<>(false, "Failed to add",null);
        }
    }

    public ResponseModel<RCAStepFive> getRCAStepFive(String rcaNo){
        try {
            List<RCAStepFive> stepFiveList = rcaStepFiveRepository.findByRcaNumber(rcaNo);
            return new ResponseModel<>(true, "Records Found",stepFiveList.getFirst());

        }catch (Exception e){
            return new ResponseModel<>(false, "Records Not Found",null);
        }
    }

    public ResponseModel<String> addRCAStepSix(AddRCAStepSixRequest stepSixRequest) {
        try {
            List<RCAStepSix> stepSixList = rcaStepSixRepository.findByRcaNumber(stepSixRequest.getRcaNumber());

            var apiAction = 0;
            if (!stepSixList.isEmpty()) {
                stepSixList.getFirst().setRcaNumber(stepSixRequest.getRcaNumber());
                stepSixList.getFirst().setRootCause(stepSixRequest.getRootCause());
                rcaStepSixRepository.save(stepSixList.getFirst());

                var addedTableList = rcaStepSixCauseRepository.findByRcaNumber(stepSixList.getFirst().getRcaNumber());
                if (!addedTableList.isEmpty()) {
                    for (RCAStepSixCause items : addedTableList) {
                        if (items.getRcaNumber().equals(stepSixList.getFirst().getRcaNumber())) {
                            rcaStepSixCauseRepository.deleteByRcaStepSixCauseId(items.getRcaStepSixCauseId());
                        }
                    }
                }
                for (RCAStepSixCause items : stepSixRequest.getCauseList()) {
                    var rcaCauseData = new RCAStepSixCause();
                    rcaCauseData.setCauseType(items.getCauseType());
                    rcaCauseData.setWhy1(items.getWhy1());
                    rcaCauseData.setWhy2(items.getWhy2());
                    rcaCauseData.setWhy3(items.getWhy3());
                    rcaCauseData.setWhy4(items.getWhy4());
                    rcaCauseData.setWhy5(items.getWhy5());
                    rcaCauseData.setComment(items.getComment());
                    rcaCauseData.setIsRca(items.getIsRca());
                    rcaCauseData.setRcaNumber(stepSixList.getFirst().getRcaNumber());

                    rcaStepSixCauseRepository.save(rcaCauseData);
                }
                apiAction = 2;
            } else {
                //Add step six RCA
                var rcaData = new RCAStepSix();
                rcaData.setRcaNumber(stepSixRequest.getRcaNumber());
                rcaData.setRootCause(stepSixRequest.getRootCause());
                rcaStepSixRepository.save(rcaData);

                List<RCAStepSix> RCAStepSixList = rcaStepSixRepository.findAll();

                for (RCAStepSixCause item : stepSixRequest.getCauseList()) {
                    var rcaCauseData = new RCAStepSixCause();
                    rcaCauseData.setCauseType(item.getCauseType());
                    rcaCauseData.setWhy1(item.getWhy1());
                    rcaCauseData.setWhy2(item.getWhy2());
                    rcaCauseData.setWhy3(item.getWhy3());
                    rcaCauseData.setWhy4(item.getWhy4());
                    rcaCauseData.setWhy5(item.getWhy5());
                    rcaCauseData.setIsRca(item.getIsRca());
                    rcaCauseData.setRcaNumber(RCAStepSixList.getLast().getRcaNumber());

                    rcaStepSixCauseRepository.save(rcaCauseData);
                }
                apiAction = 1;
            }

            List<RCA> rcaList = rcaRepository.findByRcaNumber(stepSixRequest.getRcaNumber());
            if (!rcaList.isEmpty()) {
                //Update RCA step six status
                if (rcaList.getFirst().getStatus() == 5) {
                    rcaList.getFirst().setStatus(6);
                }
                rcaRepository.save(rcaList.getFirst());
            }
            return new ResponseModel<>(true, apiAction == 1 ? "Root Cause Analysis is Created Successfully" : "Root Cause Analysis is Updated Successfully", null);

        } catch (Exception e) {
            return new ResponseModel<>(false, "Failed to add", null);
        }
    }

    public ResponseModel<RCAStepSix> getRCAStepSix(String rcaNo) {
        try {
            List<RCAStepSix> stepSixList = rcaStepSixRepository.findByRcaNumber(rcaNo);

            return new ResponseModel<>(true, "Records found", stepSixList.getFirst());

        } catch (Exception e) {
            return new ResponseModel<>(false, "Records not found", null);
        }
    }

    //RCA Step Seven
    public ResponseModel<String> addRCAStepSevenCA(AddRCAStepSevenCARequest stepSevenRequest){
        try {

            List<RCAStepSeven> stepSevenList = rcaStepSevenRepository.findByRcaNumber(stepSevenRequest.getRcaNumber());
            var apiAction = 0;
            if(!stepSevenList.isEmpty()){
                //Update step Seven RCA
                //Delete existing team members for the particular RCA no
                var addedCAList = rcaStepSevenCARepository.findByRcaNumber(stepSevenList.getFirst().getRcaNumber());
                if(!addedCAList.isEmpty()){
                    for(RCAStepSevenCA items: addedCAList){
                        if(items.getRcaNumber().equals(stepSevenList.getFirst().getRcaNumber())){
                            rcaStepSevenCARepository.deleteByCaId(items.getCaId());
                        }
                    }
                }

                for(RCAStepSevenCA item:stepSevenRequest.getCaDetails()){
                    var caData = new RCAStepSevenCA();
                    caData.setAssetNumber(item.getAssetNumber());
                    caData.setAssetGroup(item.getAssetGroup());
                    caData.setDepartment(item.getDepartment());
                    caData.setAction(item.getAction());
                    caData.setStartDate(item.getStartDate());
                    caData.setEndDate(item.getEndDate());
                    caData.setTeamMembers(item.getTeamMembers());
                    caData.setRcaNumber(stepSevenList.getFirst().getRcaNumber());
                    rcaStepSevenCARepository.save(caData);
                }

                apiAction = 2;
            }else{

                //Add step Seven RCA
                var rcaData = new RCAStepSeven();
                rcaData.setRcaNumber(stepSevenRequest.getRcaNumber());
                rcaStepSevenRepository.save(rcaData);

                for(RCAStepSevenCA item:stepSevenRequest.getCaDetails()){
                    var caData = new RCAStepSevenCA();
                    caData.setAssetNumber(item.getAssetNumber());
                    caData.setAssetGroup(item.getAssetGroup());
                    caData.setDepartment(item.getDepartment());
                    caData.setAction(item.getAction());
                    caData.setStartDate(item.getStartDate());
                    caData.setEndDate(item.getEndDate());
                    caData.setTeamMembers(item.getTeamMembers());
                    caData.setRcaNumber(stepSevenList.getFirst().getRcaNumber());
                    rcaStepSevenCARepository.save(caData);
                }

                apiAction = 1;
            }

            /*List<RCA> rcaList = rcaRepository.findByRcaNumber(stepSevenRequest.getRcaNumber());
            if(!rcaList.isEmpty()){
                //Update RCA step one status
                if(rcaList.getFirst().getStatus()==6) {
                    rcaList.getFirst().setStatus(7);
                }
                rcaRepository.save(rcaList.getFirst());
            }*/
            return new ResponseModel<>(true, apiAction ==1?"Corrective Action Created Successfully":"Corrective Action Updated Successfully",null);

        }catch (Exception e){
            return new ResponseModel<>(false, "Failed to add",null);
        }
    }

    public ResponseModel<String> addRCAStepSevenPA(AddRCAStepSevenPARequest stepSevenRequest){
        try {

            List<RCAStepSeven> stepSevenList = rcaStepSevenRepository.findByRcaNumber(stepSevenRequest.getRcaNumber());
            var apiAction = 0;
            if(!stepSevenList.isEmpty()){
                //Update step Seven RCA
                //Delete existing team members for the particular RCA no
                var addedPAList = rcaStepSevenPARepository.findByRcaNumber(stepSevenList.getFirst().getRcaNumber());
                if(!addedPAList.isEmpty()){
                    for(RCAStepSevenPA items: addedPAList){
                        if(items.getRcaNumber().equals(stepSevenList.getFirst().getRcaNumber())){
                            rcaStepSevenPARepository.deleteByPaId(items.getPaId());
                        }
                    }
                }

                for(RCAStepSevenPA item:stepSevenRequest.getPaDetails()){
                    var paData = new RCAStepSevenPA();
                    paData.setAssetNumber(item.getAssetNumber());
                    paData.setAssetGroup(item.getAssetGroup());
                    paData.setDepartment(item.getDepartment());
                    paData.setAction(item.getAction());
                    paData.setStartDate(item.getStartDate());
                    paData.setEndDate(item.getEndDate());
                    paData.setTeamMembers(item.getTeamMembers());
                    paData.setRcaNumber(stepSevenList.getFirst().getRcaNumber());
                    rcaStepSevenPARepository.save(paData);
                }
                apiAction = 2;
            }else{

                //Add step Seven RCA
                var rcaData = new RCAStepSeven();
                rcaData.setRcaNumber(stepSevenRequest.getRcaNumber());
                rcaStepSevenRepository.save(rcaData);

                for(RCAStepSevenPA item:stepSevenRequest.getPaDetails()){
                    var paData = new RCAStepSevenPA();
                    paData.setAssetNumber(item.getAssetNumber());
                    paData.setAssetGroup(item.getAssetGroup());
                    paData.setDepartment(item.getDepartment());
                    paData.setAction(item.getAction());
                    paData.setStartDate(item.getStartDate());
                    paData.setEndDate(item.getEndDate());
                    paData.setTeamMembers(item.getTeamMembers());
                    paData.setRcaNumber(stepSevenList.getFirst().getRcaNumber());
                    rcaStepSevenPARepository.save(paData);
                }

                apiAction = 1;
            }

            List<RCA> rcaList = rcaRepository.findByRcaNumber(stepSevenRequest.getRcaNumber());
            if(!rcaList.isEmpty()){
                //Update RCA step one status
                if(rcaList.getFirst().getStatus()==6) {
                    rcaList.getFirst().setStatus(7);
                }
                rcaRepository.save(rcaList.getFirst());
            }
            return new ResponseModel<>(true, apiAction ==1?"Preventive Action Created Successfully":"Preventive Action Updated Successfully",null);

        }catch (Exception e){
            return new ResponseModel<>(false, "Failed to add",null);
        }
    }


    public ResponseModel<RCAStepSeven> getRCAStepSeven(String rcaNo){
        try {
            List<RCAStepSeven> stepSevenList = rcaStepSevenRepository.findByRcaNumber(rcaNo);
            return new ResponseModel<>(true, "Records Found",stepSevenList.getFirst());

        }catch (Exception e){
            return new ResponseModel<>(false, "Records Not Found",null);
        }
    }

    //RCA Step Three
    public ResponseModel<String> addRCAStepEight(AddRCAStepEightRequest stepEightRequest){
        try {

            List<RCA> rcaList = rcaRepository.findByRcaNumber(stepEightRequest.getRcaNumber());
            var apiAction = 0;
            if(!rcaList.isEmpty()){
                //Update step Eight RCA
                rcaList.getFirst().setRcaNumber(stepEightRequest.getRcaNumber());
                rcaList.getFirst().setShareComments(stepEightRequest.getComments());

                if(rcaList.getFirst().getStatus()==7) {
                    rcaList.getFirst().setStatus(8);
                }
                rcaRepository.save(rcaList.getFirst());

            }

            return new ResponseModel<>(true, "Sharing Added Successfully",null);

        }catch (Exception e){
            return new ResponseModel<>(false, "Failed to add",null);
        }
    }

    public ResponseModel<SharingResponse> getRCAStepEight(String rcaNo){
        try {
            List<RCA> rcaList = rcaRepository.findByRcaNumber(rcaNo);
            var sharingData = new SharingResponse();
            sharingData.setApprover1Id(rcaList.getFirst().getApprover1Id());
            sharingData.setApprover1Name(rcaList.getFirst().getApprover1Name());
            sharingData.setApprover1Status(rcaList.getFirst().getApprover1Status());
            sharingData.setApprover1Comments(rcaList.getFirst().getApprover1Comments());
            sharingData.setApprover1DateTime(rcaList.getFirst().getApprover1DateTime());

            sharingData.setApprover2Id(rcaList.getFirst().getApprover2Id());
            sharingData.setApprover2Name(rcaList.getFirst().getApprover2Name());
            sharingData.setApprover2Status(rcaList.getFirst().getApprover2Status());
            sharingData.setApprover2Comments(rcaList.getFirst().getApprover2Comments());
            sharingData.setApprover2DateTime(rcaList.getFirst().getApprover2DateTime());

            sharingData.setApprover3Id(rcaList.getFirst().getApprover3Id());
            sharingData.setApprover3Name(rcaList.getFirst().getApprover3Name());
            sharingData.setApprover3Status(rcaList.getFirst().getApprover3Status());
            sharingData.setApprover3Comments(rcaList.getFirst().getApprover3Comments());
            sharingData.setApprover3DateTime(rcaList.getFirst().getApprover3DateTime());
            sharingData.setShareComments(rcaList.getFirst().getShareComments());
            sharingData.setId(rcaList.getFirst().getRcaNumber());

            return new ResponseModel<>(true, "Records Found",sharingData);

        }catch (Exception e){
            return new ResponseModel<>(false, "Records Not Found",null);
        }
    }

    public ResponseModel<String> validateRCAStepEight(ValidateRequest validateRequest){
        try {

            List<RCA> rcaList = rcaRepository.findByRcaNumber(validateRequest.getId());
            //Update step Eight RCA

            rcaList.getFirst().setApprover1Id(validateRequest.getApprover1Id());
            rcaList.getFirst().setApprover1Name(validateRequest.getApprover1Name());
            rcaList.getFirst().setApprover1Status(validateRequest.getApprover1Status());
            rcaList.getFirst().setApprover1Comments(validateRequest.getApprover1Comments());
            if(validateRequest.getApprover1Status()!=0 && rcaList.getFirst().getApprover1DateTime()==null){
                rcaList.getFirst().setApprover1DateTime(LocalDateTime.now());
            }

            rcaList.getFirst().setApprover2Id(validateRequest.getApprover2Id());
            rcaList.getFirst().setApprover2Name(validateRequest.getApprover2Name());
            rcaList.getFirst().setApprover2Status(validateRequest.getApprover2Status());
            rcaList.getFirst().setApprover2Comments(validateRequest.getApprover2Comments());
            if(validateRequest.getApprover2Status()!=0 && rcaList.getFirst().getApprover2DateTime()==null){
                rcaList.getFirst().setApprover2DateTime(LocalDateTime.now());
            }

            rcaList.getFirst().setApprover3Id(validateRequest.getApprover3Id());
            rcaList.getFirst().setApprover3Name(validateRequest.getApprover3Name());
            rcaList.getFirst().setApprover3Status(validateRequest.getApprover3Status());
            rcaList.getFirst().setApprover3Comments(validateRequest.getApprover3Comments());
            if(validateRequest.getApprover3Status()!=0 && rcaList.getFirst().getApprover3DateTime()==null){
                rcaList.getFirst().setApprover3DateTime(LocalDateTime.now());
            }

            if(validateRequest.getApprover2Name().isEmpty() && validateRequest.getApprover2Status() == 0){
                if(rcaList.getFirst().getStatus()==8) {
                    if(validateRequest.getApprover1Status()!=0){
                        rcaList.getFirst().setStatus(validateRequest.getApprover1Status()==1?11:10);
                    }
                }
                rcaRepository.save(rcaList.getFirst());

            }else if(validateRequest.getApprover3Name().isEmpty() && validateRequest.getApprover3Status() == 0){
                if(rcaList.getFirst().getStatus()==9) {
                    if(validateRequest.getApprover2Status()!=0){
                        rcaList.getFirst().setStatus(validateRequest.getApprover2Status()==1?11:10);
                    }
                }else {
                    rcaList.getFirst().setStatus(9);
                }
                rcaRepository.save(rcaList.getFirst());
            }else if(!validateRequest.getApprover3Name().isEmpty() && validateRequest.getApprover3Status() != 0){
                if(rcaList.getFirst().getStatus()==9) {
                    if(validateRequest.getApprover3Status()!=0){
                        rcaList.getFirst().setStatus(validateRequest.getApprover3Status()==1?11:10);
                    }
                }
                rcaRepository.save(rcaList.getFirst());
            }else{

                if(validateRequest.getApprover1Status() == 2){
                    rcaList.getFirst().setStatus(10);
                }else if(validateRequest.getApprover2Status() == 2){
                    rcaList.getFirst().setStatus(10);
                }else {
                    rcaList.getFirst().setStatus(9);
                }

                rcaRepository.save(rcaList.getFirst());

            }

            return new ResponseModel<>(true, "Updated Successfully",null);

        }catch (Exception e){
            return new ResponseModel<>(false, "Failed to add",null);
        }
    }

    public ResponseModel<List<RCA>> reportLists(String department, String area, FilterType filterType, String organizationCode, String requestPage, LocalDate startDate, LocalDate endDate) {
        try {

            Page<RCA> results;
            var pageRequestCount = 0;

            if(requestPage.matches(".*\\d.*")){
                pageRequestCount = Integer.parseInt(requestPage);
            }else{
                pageRequestCount = 0;
            }

            PageRequest pageRequest = PageRequest.of(pageRequestCount, defaultSize, Sort.by("createdOn").descending());

            switch (filterType) {
                case DAILY:
                    results = organizationCode != null ?
                            rcaRepository.findByOrganizationCodeAndCreatedOnBetween(organizationCode, LocalDate.now().atStartOfDay(), LocalDate.now().atTime(23, 59, 59),pageRequest) :
                            (department != null ?
                                    rcaRepository.findByDepartmentAndCreatedOnBetween(department, LocalDate.now().atStartOfDay(), LocalDate.now().atTime(23, 59, 59),pageRequest) :
                                    (area != null ?
                                            rcaRepository.findByAreaAndCreatedOnBetween(area, LocalDate.now().atStartOfDay(), LocalDate.now().atTime(23, 59, 59),pageRequest) :
                                            rcaRepository.findByCreatedOnBetween(LocalDate.now().atStartOfDay(), LocalDate.now().atTime(23, 59, 59),pageRequest)));
                    break;
                case WEEKLY:
                    LocalDate startOfWeek = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
                    LocalDate endOfWeek = LocalDate.now().with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY));
                    results = organizationCode != null ?
                            rcaRepository.findByOrganizationCodeAndCreatedOnBetween(organizationCode, startOfWeek.atStartOfDay(), endOfWeek.atTime(23, 59, 59),pageRequest) :
                            (department != null ?
                                    rcaRepository.findByDepartmentAndCreatedOnBetween(department, startOfWeek.atStartOfDay(), endOfWeek.atTime(23, 59, 59),pageRequest) :
                                    (area != null ?
                                            rcaRepository.findByAreaAndCreatedOnBetween(area, startOfWeek.atStartOfDay(), endOfWeek.atTime(23, 59, 59),pageRequest) :
                                            rcaRepository.findByCreatedOnBetween(startOfWeek.atStartOfDay(), endOfWeek.atTime(23, 59, 59),pageRequest)));
                    break;
                case MONTHLY:
                    LocalDate startOfMonth = LocalDate.now().withDayOfMonth(1);
                    LocalDate endOfMonth = LocalDate.now().plusMonths(1).withDayOfMonth(1).minusDays(1);
                    results = organizationCode != null ?
                            rcaRepository.findByOrganizationCodeAndCreatedOnBetween(organizationCode, startOfMonth.atStartOfDay(), endOfMonth.atTime(23, 59, 59),pageRequest) :
                            (department != null ?
                                    rcaRepository.findByDepartmentAndCreatedOnBetween(department, startOfMonth.atStartOfDay(), endOfMonth.atTime(23, 59, 59),pageRequest) :
                                    (area != null ?
                                            rcaRepository.findByAreaAndCreatedOnBetween(area, startOfMonth.atStartOfDay(), endOfMonth.atTime(23, 59, 59),pageRequest) :
                                            rcaRepository.findByCreatedOnBetween(startOfMonth.atStartOfDay(), endOfMonth.atTime(23, 59, 59),pageRequest)));
                    break;
                case QUARTERLY:
                    LocalDate startOfQuarter = LocalDate.now().withMonth(((LocalDate.now().getMonthValue() - 1) / 3) * 3 + 1).withDayOfMonth(1);
                    LocalDate endOfQuarter = startOfQuarter.plusMonths(3).minusDays(1);


                    results = organizationCode != null ?
                            rcaRepository.findByOrganizationCodeAndCreatedOnBetween(organizationCode, startOfQuarter.atStartOfDay(), endOfQuarter.atTime(23, 59, 59),pageRequest) :
                            (department != null ?
                                    rcaRepository.findByDepartmentAndCreatedOnBetween(department, startOfQuarter.atStartOfDay(), endOfQuarter.atTime(23, 59, 59), pageRequest) :
                                    (area != null ?
                                            rcaRepository.findByAreaAndCreatedOnBetween(area, startOfQuarter.atStartOfDay(), endOfQuarter.atTime(23, 59, 59),pageRequest) :
                                            rcaRepository.findByCreatedOnBetween(startOfQuarter.atStartOfDay(), endOfQuarter.atTime(23, 59, 59),pageRequest)));
                    break;
                case YEARLY:
                    LocalDate startOfYear = LocalDate.now().withDayOfYear(1);
                    LocalDate endOfYear = startOfYear.plusYears(1).minusDays(1);
                    results = organizationCode != null ?
                            rcaRepository.findByOrganizationCodeAndCreatedOnBetween(organizationCode, startOfYear.atStartOfDay(), endOfYear.atTime(23, 59, 59),pageRequest) :
                            (department != null ?
                                    rcaRepository.findByDepartmentAndCreatedOnBetween(department, startOfYear.atStartOfDay(), endOfYear.atTime(23, 59, 59),pageRequest) :
                                    (area != null ?
                                            rcaRepository.findByAreaAndCreatedOnBetween(area, startOfYear.atStartOfDay(), endOfYear.atTime(23, 59, 59),pageRequest) :
                                            rcaRepository.findByCreatedOnBetween(startOfYear.atStartOfDay(), endOfYear.atTime(23, 59, 59),pageRequest)));
                    break;
                case CUSTOM:
                    results = organizationCode != null ?
                            rcaRepository.findByOrganizationCodeAndCreatedOnBetween(organizationCode, startDate.atStartOfDay(), endDate.atTime(23, 59, 59),pageRequest) :
                            (department != null ?
                                    rcaRepository.findByDepartmentAndCreatedOnBetween(department, startDate.atStartOfDay(), endDate.atTime(23, 59, 59),pageRequest) :
                                    (area != null ?
                                            rcaRepository.findByAreaAndCreatedOnBetween(area, startDate.atStartOfDay(), endDate.atTime(23, 59, 59),pageRequest) :
                                            rcaRepository.findByCreatedOnBetween(startDate.atStartOfDay(), endDate.atTime(23, 59, 59),pageRequest)));
                    break;

                default:

                    return new ResponseModel<>(false, "Invalid filter type", null);
            }

            List<RCA> rcaList = rcaRepository.findAll();
            var totalCount = String.valueOf(rcaList.size());
            var filteredCount = String.valueOf(results.getContent().size());
            if (results.isEmpty()) {
                return new ResponseModel<>(false, "No records found", null);
            } else {
                return new ResponseModel<>(true, totalCount+" Records found & "+filteredCount+ " Filtered", results.getContent());
            }

        } catch (Exception e) {
            return new ResponseModel<>(false, "Records not found1", null);
        }
    }

}

