package com.maxbyte.sam.SecondaryDBFlow.Response;

public enum FilterType {
    DAILY,
    WEEKLY,
    MONTHLY,
    QUARTERLY,
    YEARLY,
    CUSTOM
}
