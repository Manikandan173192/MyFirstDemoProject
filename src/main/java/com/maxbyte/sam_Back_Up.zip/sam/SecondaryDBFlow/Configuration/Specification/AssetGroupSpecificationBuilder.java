package com.maxbyte.sam.SecondaryDBFlow.Configuration.Specification;

import com.maxbyte.sam.SecondaryDBFlow.Configuration.Entity.AssetGroup;
import com.maxbyte.sam.SecondaryDBFlow.Helper.GenericSpecificationBuilder;

public class AssetGroupSpecificationBuilder extends GenericSpecificationBuilder<AssetGroup> {
}
