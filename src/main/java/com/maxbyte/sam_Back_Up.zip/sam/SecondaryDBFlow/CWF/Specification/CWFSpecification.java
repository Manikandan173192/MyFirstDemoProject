package com.maxbyte.sam.SecondaryDBFlow.CWF.Specification;

import com.maxbyte.sam.SecondaryDBFlow.CWF.Entity.CWF;
import com.maxbyte.sam.SecondaryDBFlow.Helper.GenericSpecification;
import com.maxbyte.sam.SecondaryDBFlow.Helper.SearchCriteria;

public class CWFSpecification extends GenericSpecification<CWF> {
    public CWFSpecification(SearchCriteria criteria) {
        super(criteria);
    }
}