package com.maxbyte.sam.SecondaryDBFlow.Authentication.Entity;

public enum UserType {
    Hindalco, NonHindalco
}
